# Persistence and Streaming

## Checkpointers and Threads

Persistence is enabled at compile time.

```python
from langgraph.checkpoint.memory import InMemorySaver


graph = builder.compile(checkpointer=InMemorySaver())
config = {"configurable": {"thread_id": "thread-1"}}

graph.invoke(
    {"messages": [{"role": "user", "content": "Hi"}]},
    config=config,
)
```

Use the same `thread_id` to continue the same state lineage.

Checkpointing supports continuity, pause/resume flows, replay debugging, fault tolerance, and state inspection. `InMemorySaver` is fine locally; production should use a persistent backend.

## Checkpointer vs Store

Use a checkpointer for per-thread state:

- current messages,
- task progress,
- intermediate node outputs,
- interrupt/resume state.

Use a store for cross-thread memory:

- user preferences,
- shared facts,
- durable app-level memories.

Start checkpoint-only unless cross-thread memory is clearly required.

## Streaming

Compiled graphs support `.stream()` and `.astream()`.

```python
for chunk in graph.stream(
    {"messages": [{"role": "user", "content": "Summarize this."}]},
    config={"configurable": {"thread_id": "thread-1"}},
    stream_mode="updates",
):
    print(chunk)
```

Common modes:

- `updates`: node-level state updates.
- `values`: full state snapshots.
- `messages`: model token/message streaming.
- `custom`: custom data emitted from nodes.
- `debug`: verbose runtime details.

When available, `version="v2"` gives typed stream parts:

```python
for part in graph.stream(
    {"topic": "LangGraph"},
    stream_mode=["updates", "custom"],
    version="v2",
):
    if part["type"] == "updates":
        print(part["data"])
```

## Custom Streaming from Nodes

```python
from langgraph.config import get_stream_writer


def retrieve(state: State) -> dict:
    writer = get_stream_writer()
    writer({"stage": "retrieving"})
    docs = search(state["question"])
    writer({"stage": "retrieved", "count": len(docs)})
    return {"retrieved_docs": docs}
```

Stream with `stream_mode="custom"` or include `custom` in a list of modes.

## Minimal Persistent Conversation

```python
config = {"configurable": {"thread_id": "user-123-session-1"}}

graph.invoke(
    {"messages": [{"role": "user", "content": "My name is Ada."}]},
    config=config,
)

graph.invoke(
    {"messages": [{"role": "user", "content": "What is my name?"}]},
    config=config,
)
```

The checkpointer ties both calls to the same thread.

## Source Links

- Persistence: https://docs.langchain.com/oss/python/langgraph/persistence
- Streaming: https://docs.langchain.com/oss/python/langgraph/streaming
- Graph API overview: https://docs.langchain.com/oss/python/langgraph/graph-api
