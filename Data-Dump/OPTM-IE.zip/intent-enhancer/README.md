# Intent Enhancer

Minimal CLI for regenerating `data/raw-intents/optimus-raw-intents-v2.csv` with LLM-generated NLU columns.

```mermaid
flowchart TD
    A[optimus-raw-intents.csv] --> B[Load source rows]
    B --> R{Existing run id?}
    R -- no --> C[First pass: async row-level NLU generation]
    R -- yes --> S[Resume from latest run artifact]
    C --> D[Checkpoint JSONL in runs directory]
    C --> E[Build v2 draft CSV]
    S --> E
    E --> F[Global critique iteration]
    F --> G{Converged or no updates?}
    G -- no --> H[Apply structured row updates]
    H --> F
    G -- yes or max iterations --> I[Validate output shape and NLU fields]
    I --> J[Write optimus-raw-intents-v2.csv]
    I --> K[Report duplicate nlu_intent groups]
```

## Run

```bash
uv run python scripts/intent-enhancer/enhance_intents.py
```

Resume or inspect a specific run:

```bash
uv run python scripts/intent-enhancer/enhance_intents.py --run-id <run_id>
uv run python scripts/intent-enhancer/enhance_intents.py --run-id <run_id> --inspect-run
```

## Defaults

- Input: `data/raw-intents/optimus-raw-intents.csv`
- Output: `data/raw-intents/optimus-raw-intents-v2.csv`
- Model: `gpt-5.2`
- Concurrency: `10`
- Critique iterations per invocation: `3`
- API key: loaded from `.env` via `OPENAI_API_KEY`
- Run ID: UUID by default

## Output Columns

The script preserves all original CSV columns and appends:

- `nlu_intent`
- `nlu_entities`
- `nlu_examples`
- `nlu_disambiguation_hint`
