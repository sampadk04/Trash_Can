from typing import Dict, List, Any
from symspellpy import SymSpell, Verbosity
import re
import json

from app.instrumentation.tracing.tracer import traced
class SpellCorrector:
    def __init__(
        self,
        symspell_dict_path: str,
        custom_map_path: str,
        # acronyms:None, # Add file path later,
        max_edit_distance: int = 1
    ):
        self.max_edit_distance = max_edit_distance

        # ---- Load Custom JSON Mapping (Highest Priority) ----
        with open(custom_map_path, "r", encoding="utf-8") as f:
            self.custom_map: Dict[str, str] = {
                k.lower(): v.lower() for k, v in json.load(f).items()
            }

        # ---- Acronym / Whitelist Guardrail ----
        # self.acronyms = set(a.lower() for a in acronyms)

        # ---- Initialize SymSpell ----
        self.symspell = SymSpell(
            max_dictionary_edit_distance=max_edit_distance,
            prefix_length=7
        )

        if not self.symspell.load_dictionary(
            symspell_dict_path,
            term_index=0,
            count_index=1
        ):
            raise ValueError("Failed to load SymSpell dictionary")

    # -------------------------------------------------------
    def _tokenize(self, text: str) -> List[str]:
        
        return re.findall(r"\b\w+\b", text.lower())

    # -------------------------------------------------------
    def correct_token(self, token: str) -> str:
        """
        Correct a single token using:
        1. Acronym guardrail
        2. Custom JSON mapping
        3. SymSpell (single-candidate only)
        """

        # ---- 1. Acronym / Whitelist Guardrail ----
        # if token in self.acronyms:
        #     return token

        # ---- 2. Custom JSON Mapping ----
        if token in self.custom_map:
            return self.custom_map[token]

        # ---- 3. SymSpell (Ultra Conservative) ----
        suggestions = self.symspell.lookup(
            token,
            Verbosity.CLOSEST,
            max_edit_distance=self.max_edit_distance,
            include_unknown=False
        )

        # Accept only ONE unambiguous candidate
        if len(suggestions) == 1:
            return suggestions[0].term

        return token

    # -------------------------------------------------------
    @traced()
    def correct_query(self, query: str) -> Dict:
        tokens = self._tokenize(query)

        corrected_tokens = []
        corrections = []

        for tok in tokens:
            corrected = self.correct_token(tok)
            corrected_tokens.append(corrected)

            if corrected != tok:
                corrections.append({
                    "from": tok,
                    "to": corrected
                })

        corrected_query = query
        for old, new in zip(tokens, corrected_tokens):
            corrected_query = re.sub(
                rf"\b{old}\b",
                new,
                corrected_query,
                flags=re.IGNORECASE
            )

        return {
            "original_query": query,
            "corrected_query": corrected_query,
            "corrections": corrections
        }
