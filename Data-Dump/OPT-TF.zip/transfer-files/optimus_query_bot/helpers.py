from collections import defaultdict
import re

from app.instrumentation.tracing.tracer import traced
import logging
logger = logging.getLogger(__name__)

def make_doc_id(doc):
    return f"{doc.get('title','')}|{doc.get('intent','')}"

def weighted_score_fusion(
    bm25_results: list,
    cosine_results: list,
    weights=(0.7, 0.3),
    top_n: int = 20,
):
    """
    Weighted score fusion with min-max normalization

    Unique key: title|intent
    """

    w_bm25, w_cos = weights


    fused = defaultdict(lambda: {
        "bm25": 0.0,
        "cosine": 0.0,
        "doc": None
    })

    bm25_scores = [float(d["__score"]) for d in bm25_results if "__score" in d]
    bm25_min = min(bm25_scores) if bm25_scores else 0.0
    bm25_max = max(bm25_scores) if bm25_scores else 1.0
    bm25_range = max(bm25_max - bm25_min, 1e-6)

    for doc in bm25_results:
        doc_id = make_doc_id(doc)
        score = float(doc["__score"])
        norm_score = (score - bm25_min) / bm25_range

        fused[doc_id]["bm25"] = norm_score
        fused[doc_id]["doc"] = doc

    # ---- Cosine normalization ----
    cosine_scores = [float(d["cosine_similarity"]) for d in cosine_results if "cosine_similarity" in d]
    cos_min = min(cosine_scores) if cosine_scores else 0.0
    cos_max = max(cosine_scores) if cosine_scores else 1.0
    cos_range = max(cos_max - cos_min, 1e-6)

    for doc in cosine_results:
        doc_id = make_doc_id(doc)
        score = float(doc["cosine_similarity"])
        norm_score = (score - cos_min) / cos_range

        fused[doc_id]["cosine"] = norm_score

        # Prefer cosine doc fields if present
        if fused[doc_id]["doc"] is None:
            fused[doc_id]["doc"] = doc

    # ---- Final weighted sum ----
    results = []
    for doc_id, vals in fused.items():
        final_score = (
            w_bm25 * vals["bm25"] +
            w_cos * vals["cosine"]
        )

        doc = dict(vals["doc"])
        doc["final_score"] = final_score
        doc["bm25_norm"] = vals["bm25"]
        doc["cosine_norm"] = vals["cosine"]

        results.append(doc)

    # ---- Sort and return ----
    results.sort(key=lambda x: x["final_score"], reverse=True)
    return results[:top_n]

@traced()
def weighted_score_fusion_new(
    bm25_results: list,
    cosine_results: list,
    weights=(0.7, 0.3),
    manual_weight_coeff: float = 0.05,  # VERY LOW influence
    top_n: int = 20,
):
    """
    Weighted score fusion with min-max normalization
    + weak manual weight signal (1–4)

    Unique key: title|intent
    """

    w_bm25, w_cos = weights

    fused = defaultdict(lambda: {
        "bm25": 0.0,
        "cosine": 0.0,
        "manual": 0.0,
        "doc": None
    })

    # ---- BM25 normalization ----
    bm25_scores = [float(d["__score"]) for d in bm25_results if "__score" in d]
    bm25_min = min(bm25_scores) if bm25_scores else 0.0
    bm25_max = max(bm25_scores) if bm25_scores else 1.0
    bm25_range = max(bm25_max - bm25_min, 1e-6)

    for doc in bm25_results:
        doc_id = make_doc_id(doc)
        score = float(doc["__score"])
        norm_score = (score - bm25_min) / bm25_range

        fused[doc_id]["bm25"] = norm_score
        fused[doc_id]["doc"] = doc

        # ---- Manual weight (1–4 → 0–1) ----
        manual_val = float(doc.get("intent_priority", 0))
        fused[doc_id]["manual"] = manual_val / 4.0

    # ---- Cosine normalization ----
    cosine_scores = [
        float(d["cosine_similarity"])
        for d in cosine_results
        if "cosine_similarity" in d
    ]
    cos_min = min(cosine_scores) if cosine_scores else 0.0
    cos_max = max(cosine_scores) if cosine_scores else 1.0
    cos_range = max(cos_max - cos_min, 1e-6)

    for doc in cosine_results:
        doc_id = make_doc_id(doc)
        score = float(doc["cosine_similarity"])
        norm_score = (score - cos_min) / cos_range

        fused[doc_id]["cosine"] = norm_score

        # Prefer cosine doc fields if BM25 missing
        if fused[doc_id]["doc"] is None:
            fused[doc_id]["doc"] = doc

        # Manual weight (safe overwrite if present)
        manual_val = float(doc.get("intent_priority", 0))
        if manual_val:
            fused[doc_id]["manual"] = manual_val / 4.0

    # ---- Final weighted sum ----
    results = []
    for doc_id, vals in fused.items():
        final_score = (
            w_bm25 * vals["bm25"]
            + w_cos * vals["cosine"]
            + manual_weight_coeff * vals["manual"]
        )

        doc = dict(vals["doc"])
        doc["final_score"] = final_score
        doc["bm25_norm"] = vals["bm25"]
        doc["cosine_norm"] = vals["cosine"]
        doc["manual_norm"] = vals["manual"]

        results.append(doc)

    # ---- Sort and return ----
    results.sort(key=lambda x: x["final_score"], reverse=True)
    return results[:top_n]

def remove_reasoning(text):
    cleaned_text = re.sub(r'<reasoning>.*?</reasoning>', '', text, flags=re.DOTALL)
    return cleaned_text.strip()

def rrf_fusion(
    bm25_results: list,
    cosine_results: list,
    weights=(1, 0.3),
    k: int = 60,
    top_n: int = 20,
):
    """
    Reciprocal Rank Fusion (RRF)

    Unique key: title|intent
    """

    w_bm25, w_cosine = weights
    fused_scores = defaultdict(float)
    doc_store = {}

    def make_doc_id(doc):
        return f"{doc.get('title','')}|{doc.get('intent','')}"

    # --- BM25 contribution ---
    for rank, doc in enumerate(bm25_results, start=1):
        doc_id = make_doc_id(doc)

        fused_scores[doc_id] += w_bm25 * (1 / (k + rank))
        doc_store[doc_id] = doc

    # --- Cosine contribution ---
    for rank, doc in enumerate(cosine_results, start=1):
        doc_id = make_doc_id(doc)

        fused_scores[doc_id] += w_cosine * (1 / (k + rank))

        if doc_id not in doc_store:
            doc_store[doc_id] = doc

    # --- Sort by fused score ---
    ranked = sorted(
        fused_scores.items(),
        key=lambda x: x[1],
        reverse=True
    )

    # --- Build final ranked list ---
    final_results = []
    for doc_id, score in ranked[:top_n]:
        doc = dict(doc_store[doc_id])
        doc["rrf_score"] = score
        final_results.append(doc)

    return final_results

@traced()
def get_hybrid_weights(query):
    word_count = len(query.split())
    
    if word_count <= 3:
        return 0.7, 0.3   # BM25, Cosine
    elif word_count <= 7:
        return 0.5, 0.5
    else:
        return 0.3, 0.7
