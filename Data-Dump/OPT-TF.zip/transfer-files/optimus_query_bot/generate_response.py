import os
import botocore
import re
from time import time
from app.services.optimus_query_bot.retrival import FAQRetrieval


class GenerateQueryResponse: 

    def process_query(): 
        return ""