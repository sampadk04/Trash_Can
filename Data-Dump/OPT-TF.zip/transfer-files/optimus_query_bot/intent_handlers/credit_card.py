from openai import AsyncOpenAI
from httpx import AsyncClient
from dotenv import load_dotenv

# from app.clients.llm_gw import get_llm_gw_client
from app.services.optimus_query_bot.llm_usage import log_usage
from typing import Optional, Dict, Any
import json
import time

load_dotenv()
openai_client = AsyncOpenAI(http_client=AsyncClient(verify=False))

async def gptcall(messages,FD_OUTPUT_SCHEMA):
    response = await openai_client.chat.completions.create(
        model="gpt-5.2",
        messages=messages,
        max_completion_tokens=1024,
        temperature=0.0,
        top_p=0.9,
        response_format=FD_OUTPUT_SCHEMA
    )
    
    response_dict = response.model_dump()
    return response_dict

# gptcall=LLMGatewayClient()

# client = get_llm_gw_client()

# async def gptcall(messages,FD_OUTPUT_SCHEMA): 
#     payload = {
#         "model": "gpt-5.4",
#         "max_completion_tokens": 1024,
#         "temperature": 0.0,
#         "top_p": 0.9,
#         "messages": messages,
#         "response_format": FD_OUTPUT_SCHEMA
#     }


#     response = await client.invoke_model(payload)
#     log_usage(response, "optimus_query_bot.credit_card.gptcall")
#     return response

async def get_help(user_query: str) -> Dict[str, Any]:
    """
    LLM-only responsibility:
    - Extract FD amount from user query
    - Ask user if amount is missing
    """

    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "get_help",
            "schema": {
                "type": "object",
                "properties": {
                    "bot_response": {"type": "string"},
                    "intent": {
                      "type": "string",
                      "enum": [ "change_amount" , "change_tenure" , "change_default" ,"abort", "other","none"],
                      "description": "classify the user query in one of those intents"
                    },
                },
                "required": ["bot_response", "intent"],
                "additionalProperties": False,
            },
        },
    }

    messages = [
        {
            "role": "system",
            "content": """ 
                ### ROLE
                You are a Credit Card Bill Payment Assistance Bot.

                ### CONTEXT
                The user is in a widget-driven credit card bill payment journey.
                They are expected to select options using buttons provided on screen.

                ### YOUR TASK
                Classify the user's message into ONE of the following intents and respond accordingly.

                ### INTENTS
                1. widget_issue
                   - User types instructions instead of selecting buttons
                   - User cannot find their credit card
                   - In this case guide user to 'abort' and try again or click the redirection provided.
                   - Examples:
                     - "select first card"
                     - "pay full amount"
                     - "my card is not showing"

                2. abort
                   - User wants to cancel or stop the journey
                   - Examples:
                     - "cancel"
                     - "stop payment"
                     - "exit"

                3. other
                   - Ambiguous, unrelated, or off-topic input
                   - Examples:
                     - "hi"
                     - "what is credit score"
                     - random text

                ### RESPONSE RULES
                - Do NOT assume or extract values from text
                - Do NOT mention system state or flags
                - Guide the user politely
                - Keep responses short and professional

                ### OUTPUT FORMAT
                Return ONLY valid JSON.

                {
                  "intent": "widget_issue | abort | other",
                  "bot_response": "string"
                }
                """,
        },
        {"role": "user", "content": user_query},
    ]

    raw_response = await gptcall(messages, out_schema)
    content = raw_response["choices"][0]["message"]["content"]

    return json.loads(content)



def initialize_cc_payment_state():
    return {
        "journey": "CC_PAYMENT",
        "bot_response": "",
        "fetch_card_details": "no",
        "card_details": None,
        "fetch_payment_amount": "no",
        "payment_amount": None,
        "fetch_account_details": "no",
        "account_details": None,
        "raise_final_confirmation": "no",
        "abort": "no",
        "off_topic_count": 0,
        "show_redirection": "no",
        "count":0,
        "widget_response":'no'
    }



class CreditCardHandler:
    def __init__(self):
        self.state = initialize_cc_payment_state()

    def _update_state_from_request(self, additional_data:dict, journey_state: dict):

        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

        if "card_details" in additional_data:
            self.state["card_details"] = additional_data.get("card_details")

        if "payment_amount" in additional_data:
            self.state["payment_amount"] = additional_data.get("payment_amount")

        if "account_details" in additional_data:
            self.state["account_details"] = additional_data.get("account_details")

        if "widget_response" in additional_data:
            self.state["widget_response"] = additional_data.get("widget_response")

    async def handle(self, user_query: str, journey_data, journey_state):
        # ---------------- INIT STATE ----------------

        self.state["fetch_card_details"] = "no"
        self.state["fetch_payment_amount"] = "no"
        self.state["fetch_account_details"] = "no"
        self.state["raise_final_confirmation"] = "no"
        self.state['count']+=1

        if self.state['count']==1 or self.state['widget_response']=='yes':

            self.state['widget_response']='no'

            # ---------------- CARD DETAILS ----------------
            if not self.state["card_details"]:
                self.state["fetch_card_details"] = "yes"
                self.state["bot_response"] = "Please select the credit card you want to pay for."
                return self.state

            # ---------------- PAYMENT AMOUNT ----------------
            if not self.state["payment_amount"]:
                self.state["fetch_payment_amount"] = "yes"
                self.state["bot_response"] = "Please select the payment amount."
                return self.state

            # ---------------- ACCOUNT DETAILS ----------------
            if not self.state["account_details"]:
                self.state["fetch_account_details"] = "yes"
                self.state["bot_response"] = "Please select the bank account for payment."
                return self.state

            # -------- FINAL CONFIRMATION --------
            self.state["raise_final_confirmation"] = "yes"
            self.state["bot_response"] = (
                f"Please review and confirm your credit card bill payment:\n"
                f"- Credit Card: {self.state['card_details']}\n"
                f"- Payment Amount: {self.state['payment_amount']}\n"
                f"- Bank Account: {self.state['account_details']}"
            )
            return self.state

        response = await get_help(user_query)
        intent = response["intent"]

        # -------- WIDGET ISSUE --------
        if intent == "widget_issue":
            self.state["bot_response"] = response["bot_response"]
            self.state["show_redirection"] = "yes"
            return self.state

        # -------- ABORT --------
        if intent == "abort":
            self.state["abort"] = "yes"
            self.state["bot_response"] = "Credit card bill payment journey has been terminated."
            return self.state

        # -------- OFF TOPIC / AMBIGUOUS --------
        if intent == "other":
            self.state["off_topic_count"] += 1

            if self.state["off_topic_count"] >= 2:
                self.state["abort"] = "yes"
                self.state["bot_response"] = (
                    "We are unable to proceed due to unrelated inputs. "
                    "Please start the credit card bill payment again."
                )
                return self.state

            self.state["bot_response"] = response["bot_response"]
            return self.state


    def get_intent_data(self):

        journey_id="PAY_CREDIT_CARD_BILL"
        if self.state.get("raise_final_confirmation").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.RAISE_FINAL_CONFIRMATION"
            }

        if self.state.get("fetch_account_details").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SHOW_ACCOUNTS"
            }

        if self.state.get("fetch_payment_amount").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SHOW_AMOUNT"
            }

        if self.state.get("fetch_card_details").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SHOW_CREDIT_CARDS"
            }

        if self.state.get("abort").lower().strip() == "yes":
            return {
                "intent_type": "",
                "intent": ""
            }
        return {
            "intent_type": "Clarification",
            "intent": journey_id
        }
