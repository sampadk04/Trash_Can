# LangGraph Graph API Core

LangGraph workflows are stateful graphs:

- `State`: shared snapshot.
- `Nodes`: functions that read state and return partial updates.
- `Edges`: fixed or conditional transitions.

## Basic Graph

```python
from typing_extensions import TypedDict
from langgraph.graph import END, START, StateGraph


class State(TypedDict):
    user_input: str
    answer: str


def answer(state: State) -> dict:
    return {"answer": f"Received: {state['user_input']}"}


builder = StateGraph(State)
builder.add_node("answer", answer)
builder.add_edge(START, "answer")
builder.add_edge("answer", END)

graph = builder.compile()
result = graph.invoke({"user_input": "hello"})
```

Nodes should return only changed fields and should not mutate input state in place.

## Reducers and Messages

Without a reducer, updates overwrite existing values. Use reducers to merge repeated or parallel writes.

```python
import operator
from typing import Annotated
from typing_extensions import TypedDict
from langchain.messages import AnyMessage
from langgraph.graph import MessagesState
from langgraph.graph.message import add_messages


class ListState(TypedDict):
    notes: Annotated[list[str], operator.add]


class ChatState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]


class ExtendedChatState(MessagesState):
    retrieved_docs: list[str]
```

Prefer `MessagesState` or `add_messages` for chat history because they handle message IDs.

## Input, Output, Internal State

```python
class InputState(TypedDict):
    question: str


class OutputState(TypedDict):
    answer: str


class InternalState(InputState, OutputState):
    search_query: str
    retrieved_docs: list[str]


builder = StateGraph(
    InternalState,
    input_schema=InputState,
    output_schema=OutputState,
)
```

Use one state schema first. Split schemas when the public graph interface should hide internal channels.

## Runtime Context

Use runtime context for run-scoped dependencies that should not be persisted.

```python
from dataclasses import dataclass
from langgraph.runtime import Runtime


@dataclass
class Context:
    tenant_id: str


def answer(state: State, runtime: Runtime[Context]) -> dict:
    return {"answer": f"{runtime.context.tenant_id}: {state['user_input']}"}


builder = StateGraph(State, context_schema=Context)
builder.add_node("answer", answer)
builder.add_edge(START, "answer")
builder.add_edge("answer", END)
graph = builder.compile()
graph.invoke({"user_input": "hi"}, context={"tenant_id": "acme"})
```

Keep API keys, clients, and request-scoped dependencies out of graph state.

## Edges and Command

```python
from typing import Literal
from langgraph.types import Command


def route(state: State) -> Literal["retrieve", "answer"]:
    return "retrieve" if state["user_input"].endswith("?") else "answer"


builder.add_conditional_edges("classify", route)


def classify(state: State) -> Command[Literal["retrieve", "answer"]]:
    if state["user_input"].endswith("?"):
        return Command(update={"search_query": state["user_input"]}, goto="retrieve")
    return Command(update={"answer": "No question detected."}, goto="answer")
```

Use conditional edges when routing is separate from node work. Use `Command` when a node should update state and choose the next node together.

## Source Links

- Graph API overview: https://docs.langchain.com/oss/python/langgraph/graph-api
- Use the Graph API: https://docs.langchain.com/oss/python/langgraph/use-graph-api
