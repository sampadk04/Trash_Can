from typing import Any

from app.services.optimus_query_bot.intent_handlers_lg.pay_credit_card_bill.graph import (
    build_graph,
    initialize_cc_payment_state,
)
from app.services.optimus_query_bot.intent_handlers_lg.shared.state import yes


class CreditCardGraphHandler:
    def __init__(self):
        self.state = initialize_cc_payment_state()
        self.graph = build_graph()

    def _update_state_from_request(self, additional_data: dict, journey_state: dict):
        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

        if "card_details" in additional_data:
            self.state["card_details"] = additional_data.get("card_details")
        if "payment_amount" in additional_data:
            self.state["payment_amount"] = additional_data.get("payment_amount")
        if "account_details" in additional_data:
            self.state["account_details"] = additional_data.get("account_details")
        if "widget_response" in additional_data:
            self.state["widget_response"] = additional_data.get("widget_response")

    async def handle(self, user_query: str, journey_data: dict[str, Any], journey_state: dict[str, Any]):
        graph_input = {**self.state, "user_query": user_query}
        result = await self.graph.ainvoke(graph_input)
        result.pop("user_query", None)
        self.state = result
        return self.state

    def get_intent_data(self):
        journey_id = "PAY_CREDIT_CARD_BILL"
        if yes(self.state.get("raise_final_confirmation")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.RAISE_FINAL_CONFIRMATION"}
        if yes(self.state.get("fetch_account_details")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.SHOW_ACCOUNTS"}
        if yes(self.state.get("fetch_payment_amount")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.SHOW_AMOUNT"}
        if yes(self.state.get("fetch_card_details")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.SHOW_CREDIT_CARDS"}
        if yes(self.state.get("abort")):
            return {"intent_type": "", "intent": ""}
        return {"intent_type": "Clarification", "intent": journey_id}
