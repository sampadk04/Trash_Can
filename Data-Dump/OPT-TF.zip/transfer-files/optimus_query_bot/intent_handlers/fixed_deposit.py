from openai import AsyncOpenAI
from httpx import AsyncClient
from dotenv import load_dotenv

# from app.clients.llm_gw import get_llm_gw_client
from app.services.optimus_query_bot.llm_usage import log_usage
from typing import Optional, Dict, Any
import time
import json
import logging
logger = logging.getLogger(__name__)

load_dotenv()
openai_client = AsyncOpenAI(http_client=AsyncClient(verify=False))

async def gptcall(messages,FD_OUTPUT_SCHEMA):
    response = await openai_client.chat.completions.create(
        model="gpt-5.2",
        messages=messages,
        max_completion_tokens=1024,
        temperature=0.0,
        top_p=0.9,
        response_format=FD_OUTPUT_SCHEMA
    )
    
    response_dict = response.model_dump()
    return response_dict

# async def gptcall(messages,FD_OUTPUT_SCHEMA): 
#     client = get_llm_gw_client()
#     payload = {
#         "model": "gpt-5.4",
#         "max_completion_tokens": 1024,
#         "temperature": 0.0,
#         "top_p": 0.9,
#         "messages": messages,
#         "response_format": FD_OUTPUT_SCHEMA
#     }
#     response = await client.invoke_model(payload)
#     log_usage(response, "optimus_query_bot.fixed_deposit.gptcall")
#     return response

# =============== Helper functions ==========================
async def update_amount(user_query: str) -> Dict[str, Any]:
    """
    LLM-only responsibility:
    - Extract FD amount from user query
    - Ask user if amount is missing
    """

    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "fd_amount_extraction",
            "schema": {
                "type": "object",
                "properties": {
                    "bot_response": {"type": "string"},
                    "fd_amount": {"type": ["number", "null"]},
                },
                "required": ["bot_response", "fd_amount"],
                "additionalProperties": False,
            },
        },
    }

    messages = [
        {
            "role": "system",
            "content": (
                "You are a banking assistant. Your task is ONLY to extract a deposit amount "
                "from the user query. If no amount is found, politely ask the user to specify it."
            ),
        },
        {"role": "user", "content": user_query},
    ]

    raw_response = await gptcall(messages, out_schema)
    content = raw_response["choices"][0]["message"]["content"]

    return json.loads(content)

def normalize_tenure(tenure_part: dict) -> int:
    if not tenure_part:
        return 0

    tenure_part = {k.lower(): v for k, v in tenure_part.items()}

    years  = tenure_part.get("years",  0) or 0   
    months = tenure_part.get("months", 0) or 0   
    days_  = tenure_part.get("days",   0) or 0  

    return (years * 365) + (months * 30) + days_

def select_fd_plan(days: int, plans: list):
    matching_plans = []

    for plan in plans:
        tenure = plan.get("tenure", {})
        min_days = normalize_tenure(tenure.get("min", {}))
        max_days = normalize_tenure(tenure.get("max", {}))

        if min_days <= days <= max_days:
            matching_plans.append((plan, min_days, max_days))

    if not matching_plans:
        return None

    matching_plans.sort(
        key=lambda x: (
            -x[0].get("rate_of_interest", 0),
            (x[2] - x[1])  # range width
        )
    )

    best_plan, min_days, _ = matching_plans[0]

    years = days // 365
    remaining_days = days % 365

    return {
        "interest_rate": best_plan.get("rate_of_interest"),
        "depositType": best_plan.get("deposit_type"),
        "isAutoRenewable": best_plan.get("is_renewable"),
        "interestPayoutMethod": best_plan.get("interest_payout_method"),
        "productCode": best_plan.get("product_code"),
        "subProductCode": best_plan.get("sub_product_code"),
        "tenure_info": {
            "Years": years,
            "Months": 0,
            "Days": remaining_days
        }
    }

def duration_to_days(duration):
    """
    Convert duration dict to total days.
    Assumptions:
    - 1 year = 365 days
    - 1 month = 30 days (adjust if needed)
    """
    years = 0
    months = 0
    days = 0

    for key, value in duration.items():
        v =  value or 0
        k = key.lower()
        if k == "years":
            years = v
        elif k == "months":
            months = v
        elif k == "days":
            days = v

    return years * 365 + months * 30 + days

def extract_interest_ranges(plans):
    interest_rates = []

    for plan in plans:
        tenure = plan.get("tenure", {})
        min_duration = tenure.get("min", {})
        max_duration = tenure.get("max", {})

        min_days = duration_to_days(min_duration)
        max_days = duration_to_days(max_duration)

        interest_rates.append({
            "tenure": plan.get("tenure_description", ""),
            "min_days": min_days,
            "max_days": max_days,
            "rate_percent": plan.get("rate_of_interest")
        })

    return {"interest_rates": interest_rates}

def validate_fd_amount(
    amount: int,
    current_balance: int,
    min_fd_limit: int = 1000,
    max_fd_limit: int = 30000000,
) -> Dict[str, Any]:
    """
    Validates FD amount against business rules.
    """

    if amount < min_fd_limit:
        return {
            "fd_amount": None,
            "bot_response": (
                f"The minimum amount required to book a Fixed Deposit is ₹{min_fd_limit:,}."
            ),
        }

    if amount > max_fd_limit:
        return {
            "fd_amount": None,
            "bot_response": (
                f"The maximum amount allowed for a Fixed Deposit is ₹{max_fd_limit:,}."
            ),
        }

    if amount > current_balance:
        return {
            "fd_amount": None,
            "bot_response": "You have insufficient funds to proceed with this deposit amount.",
        }

    return {
        "fd_amount": amount,
        "bot_response": "Amount noted. Let’s proceed with the next step.",
    }

async def update_tenure(user_query,rate_card,consumed_value,expected_slot):
    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "tenure_selection",
            "schema": {
                "type": "object",
                "properties": {
                    "bot_response": {
                        "type": "string",
                        "description": "Customer-facing message generated by the bot"
                    },
                    "tenure": {
                        "type": ["number", "null"],
                        "description": "FD tenure in days"
                    },
                    "show_interest_rate_chart": {
                        "type": "string",
                        "enum": ["true", "false"],
                        "description": "It shows interest rate table in UI"
                    },
                },
                "required": ["bot_response", "tenure", "show_interest_rate_chart"],
                "additionalProperties": False
            }
        }
    }
    
    messages = [
        {
            "role": "system",
            "content": """
    ### ROLE
    You are a precise and polite AI Banking Agent assisting with Fixed Deposit (FD) bookings.
    Your primary goal is to extract the user's desired tenure in days based strictly on the provided data.
    
    ---
    
    ### INPUT DATA
    
    You will receive:
    1. `rate_card`: Available tenures and their interest rates.
    2. `user_query`: The customer's latest message.
    3. `consumed_value`: Either `null` OR `{"amount": <value>}` — the numeric value already consumed by the Amount step from this same user message.
    4. `expected_slot`: The field the bot is currently collecting — `"amount"`, `"tenure"`, or `null`.
    
    ---
    
    ### STEP 0 — BARE NUMBER DISAMBIGUATION (Run this BEFORE all other steps)
    
    A "bare number" is a standalone numeric value with NO explicit tenure indicator.
    
    Explicit tenure indicators (always take precedence, skip Step 0 entirely):
    - Units: days, months, years, month, year, day
    - Interest rate: %, per annum, p.a.
    - Phrases: "for X", "X duration", "X period"
    
    If the user query contains an explicit tenure indicator → skip Step 0, go directly to Step 1.
    
    If the user query contains a bare number (no explicit indicator), apply this decision table:
    
    | consumed_value         | expected_slot | Decision                                      |
    |------------------------|---------------|-----------------------------------------------|
    | {"amount": <X>}        | any           | Bare number was already used for amount. Do NOT extract as tenure. Set tenure=null, ask for tenure. |
    | null                   | "tenure"      | Bot explicitly asked for tenure. Treat bare number as tenure in days. |
    | null                   | "amount"      | Bot was collecting amount, not tenure. Set tenure=null, ask for tenure. |
    | null                   | null          | Ambiguous. Set tenure=null, ask for tenure politely. |
    
    Key rule: if consumed_value contains the same number present in the user query →
    that number is already taken. Do not reuse it for tenure.
    
    ---
    
    ### STEP 1 — Unit Standardization
    Convert any time duration to total days:
    - 1 Month = 30 Days
    - 1 Year = 365 Days
    
    ---
    
    ### STEP 2 — Matching Logic
    
    **Scenario A: User provides specific tenure (explicit time unit present)**
    - Convert to days and return as `tenure`. Set `show_interest_rate_chart` = `"false"`.
    
    **Scenario B: User provides specific interest rate**
    - If rate found in `rate_card`: select the lowest tenure for that rate. Set `show_interest_rate_chart` = `"false"`.
    - If rate not found: set `show_interest_rate_chart` = `"true"`, ask user to choose from available schemes.
    
    **Scenario C: Tenure missing, ambiguous, or blocked by Step 0**
    - Set `tenure` = null.
    - Set `show_interest_rate_chart` = `"true"`.
    - Ask the user politely for tenure. Do NOT ask for both tenure and interest rate together.
    - Do NOT force the user to specify in days — accept any natural format.
    
    ---
    
    ### MANDATORY CONSTRAINTS
    
    - **NEVER** include rate_card data, tenure lists, or interest rate tables in `bot_response`.
    - **NEVER** type out values like "7 days: 3%, 365 days: 7%". Set `show_interest_rate_chart` = `"true"` instead.
    - Do NOT use words like "database", "table", "app", or "list". Use "available schemes" or "current options".
    - Tone: Professional, banking-grade, concise.
    - Output strictly valid JSON.
    
    ---
    
    ### QUICK REFERENCE — Step 0 Examples
    
    | user_query | consumed_value        | expected_slot | tenure output |
    |------------|-----------------------|---------------|---------------|
    | "1000"     | {"amount": 1000}      | "tenure"      | null — ask for tenure |
    | "1000"     | null                  | "tenure"      | 1000 days ✓  |
    | "1000"     | null                  | "amount"      | null — ask for tenure |
    | "6 months" | {"amount": 1000}      | "tenure"      | 180 days ✓ (explicit indicator, skip Step 0) |
    | "180 days" | null                  | "amount"      | 180 days ✓ (explicit indicator, skip Step 0) |
    | "500"      | {"amount": 500}       | "tenure"      | null — ask for tenure |
    | "500"      | null                  | null          | null — ask for tenure |
            """
        },
                
                {
                    "role": "user",
                    "content": f"user_query:{user_query},\n rate_card:{rate_card},\n consumed_value:{consumed_value},\n expected_slot:{expected_slot}"
                }
            ]
    raw_response=await gptcall(messages,out_schema)
    final_output = raw_response["choices"][0]["message"]["content"]
    response=json.loads(final_output)
    return response

def raise_final_confirmation(
    user_query: str,
    booking_amount: Optional[int],
    tenure: Optional[int],
    interest_rate: Optional[float],
    auto_renewal: str = "Yes",
    nominee_details: str = "existing_nominee",
    payout_option: str = "on_maturity",
) -> Dict[str, Any]:
    """
    Generates final FD booking summary and decides whether to raise confirmation.
    """

    # ---------------- Validation ----------------
    missing_fields = []

    if not booking_amount:
        missing_fields.append("deposit amount")
    if not tenure:
        missing_fields.append("tenure")
    if not interest_rate:
        missing_fields.append("interest rate")

    if missing_fields:
        return {
            "raise_final_confirmation": "no",
            "bot_response": (
                "To proceed with your Fixed Deposit booking, please provide the "
                + ", ".join(missing_fields)
                + "."
            ),
        }

    # ---------------- Summary Formatting ----------------
    bot_response = (
        "### 📄 Fixed Deposit Booking Summary\n\n"
        f"- **Deposit Amount:** ₹{booking_amount:,}\n"
        f"- **Tenure:** {tenure} days\n"
        f"- **Interest Rate:** {interest_rate}% p.a.\n"
        f"- **Payout Option:** {payout_option.replace('_', ' ').title()}\n"
        f"- **Auto Renewal:** {auto_renewal}\n"
        f"- **Nominee Details:** Your existing nominee details will be used.\n  "
        f"Please review the above details carefully and confirm to proceed."
    )

    return {
        "raise_final_confirmation": "yes",
        "bot_response": bot_response,
    }

async def intent_identification(user_query,state_dict,expected_slot):
    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "intent_identification",
            "schema": {
                "type": "object",
                "properties": {
                    "intent": {
                        "type": "string",
                        "enum": [
                            "change_amount", "change_tenure", "change_default",
                            "abort", "other", "none", "change_amount_and_tenure"
                        ],
                        "description": "Classify the user query into one of the allowed intents"
                    },
                    "reasoning": {
                        "type": "string",
                        "description": "One line explanation of why this intent was chosen. Mandatory."
                    }
                },
                "required": ["intent", "reasoning"],
                "additionalProperties": False
            }
        }
    }



    messages = [
        {
            "role": "system",
            "content": """
        ## 🎯 ROLE
        
        You are an **Intent Classification Engine** for a **Bank Fixed Deposit (FD) Booking Agent**.
        
        Your sole responsibility is to **accurately classify the user's intent** based on:
        - The **existing journey state** (previously confirmed values)
        - The **expected_slot** (what the bot is currently collecting)
        - The **latest user query**
        
        You must not perform calculations, give advice, or generate conversational responses.
        You only classify intent.
        
        ---
        
        ## 📥 INPUTS
        
        You will receive:
        
        1. **Existing State `{state_dict}`**
           Confirmed FD values so far (amount, tenure, interest rate, defaults like
           auto-renewal, nominee, payout option)
        
        2. **Expected Slot `{expected_slot}`**
           The field the bot is currently waiting to collect from the user.
           Possible values: `"amount"` | `"tenure"` | `"none"`
        
        3. **User Query**
           The most recent message from the user
        
        ---
        
        ## 📤 OUTPUT
        
        Return **exactly one intent** from:
        
        ["change_amount", "change_tenure", "change_default", "abort", "other", "none", "change_amount_and_tenure"]
        
        Also return a `reasoning` field: one line explaining your choice.
        
        ---
        
        ## 🧭 CORE DISAMBIGUATION RULE — READ THIS FIRST
        
        ### When the user provides a bare number or ambiguous phrase (no explicit unit or field label):
        User: "500" / "book it for 2000" / "make it 1500" / "go with 730"
        
        These are ambiguous. Use `expected_slot` to resolve:
        
        | expected_slot        | Bare number means  | Intent to return  |
        |----------------------|--------------------|-------------------|
        | `"tenure"`           | days               | `none`            |
        | `"amount"`           | ₹ amount           | `none`            |

        
        > `none` here means: "user is answering the active question, no intent change needed."
        > The FSM will extract the value itself — your job is only to classify intent.
        
        ### When the user provides an EXPLICIT signal, ALWAYS override expected_slot:
        
        Explicit amount signals → `change_amount` regardless of expected_slot:
        - Contains: ₹, lakh, lakhs, thousand, k (as suffix), crore
        - Example: "make it 50k", "₹2 lakhs", "1 lakh 50 thousand"
        
        Explicit tenure signals → `change_tenure` regardless of expected_slot:
        - Contains: days, months, years, year, month, day
        - Example: "6 months", "180 days", "1.5 years"
        
        Explicit both signals → `change_amount_and_tenure`
        - Example: "50k for 6 months", "1 lakh for 365 days"
        
        ---
        
        ## 🧭 INTENT DEFINITIONS
        
        ### 1️⃣ `change_amount`
        
        Return this intent ONLY if the user:
        - Explicitly mentions amount with a currency unit or word (₹, lakh, k, thousand, crore)
        - Asks to change, increase, or decrease the FD amount
        - Mentions a different amount than what is in current state
        
        ⚠️ Do NOT return this if:
        - User gives a bare number and `expected_slot = "tenure"` — that is a tenure value
        - User gives a bare number with no context and no explicit amount signal
        
        ---
        
        ### 2️⃣ `change_tenure`
        
        Return this intent ONLY if the user:
        - Explicitly mentions duration with a unit (days, months, years)
        - Asks about better interest rates, higher returns, or best FD plans
        - Mentions a different tenure than what is in current state
        
        ⚠️ Do NOT return this if:
        - User gives a bare number and `expected_slot = "amount"` — that is an amount value
        - User gives a bare number with no context and no explicit tenure signal
        
        ---
        
        ### 3️⃣ `change_amount_and_tenure`
        
        Return this ONLY if the user explicitly or strongly implies changing BOTH fields:
        - "50k for 6 months"
        - "reduce amount and extend tenure"
        - "1 lakh for 365 days"
        
        Both signals must be present. If only one is mentioned, use the single-change intent.
        
        ---
        
        ### 4️⃣ `change_default`
        
        Return this if the user wants to modify any FD configuration other than amount/tenure:
        - Auto-renewal, nominee, payout option, maturity instructions
        
        ---
        
        ### 5️⃣ `abort`
        
        Return this ONLY if the user clearly and explicitly exits the journey:
        - "Cancel", "Stop", "I don't want this", "Exit", "Not interested anymore"
        
        🚫 Do NOT infer abort from hesitation, silence, or unrelated questions.
        
        ---
        
        ### 6️⃣ `other`
        
        Return this if:
        - Query is about a non-FD banking service
        - Query is completely unrelated to the current FD booking journey
        
        ---
        
        ### 7️⃣ `none`
        
        Return this if:
        - User is directly answering the active expected_slot question (bare number, confirmation word)
        - Query is ambiguous but related to FD booking
        - User asks a general FD question without signaling a change
        
        📌 When in doubt between `none` and a change intent — prefer `none`.
        
        ---
        
        ## 🔁 EXPECTED SLOT DECISION TREE
        User message received
        │
        ▼
        Does message contain EXPLICIT field signal? (unit word, currency symbol)
        │
        YES  │  NO
        │       └──► Look at expected_slot
        │              │
        │         expected_slot = "tenure"
        │              └──► Bare number → intent = none  (FSM reads as days)
        │
        │         expected_slot = "amount"
        │              └──► Bare number → intent = none  (FSM reads as ₹)
        │
        │         expected_slot = "final_confirmation"
        │              └──► Yes/No/Confirm → intent = none
        │
        ▼
        Explicit signal found → classify normally, IGNORE expected_slot
        
        ---
        
        ## 🔀 CONFLICT HANDLING
        
        When `expected_slot` and explicit signal point to DIFFERENT fields:
        
        | Situation | Example | Return |
        |-----------|---------|--------|
        | expected_slot=tenure, user says "50k" | "book it for 50k" | `change_amount` |
        | expected_slot=amount, user says "180 days" | "make it 180 days" | `change_tenure` |
        | expected_slot=tenure, user says "50k for 6 months" | combined | `change_amount_and_tenure` |

        
        Explicit always wins over expected_slot. expected_slot only resolves ambiguity.
        
        ---
        
        ## 🚨 CRITICAL RULES (NON-NEGOTIABLE)
        
        - Return ONLY one intent from the allowed list
        - Always return a one-line `reasoning`
        - Do NOT explain beyond reasoning field
        - Do NOT ask follow-up questions
        - Do NOT infer beyond what is explicitly or strongly implied
        - Explicit unit/currency signals ALWAYS override expected_slot
        - expected_slot ONLY used when the message is ambiguous
        - Prioritize precision over coverage
        - When in doubt → return `none`
        """
                },
                {
                    "role": "user",
                    "content": f"user_query:{user_query},\n state_dict:{state_dict}, \n Expected Slot:{expected_slot} "
                }
            ]
    raw_response=await gptcall(messages,out_schema)
    final_output = raw_response["choices"][0]["message"]["content"]
    
    response=json.loads(final_output)
    return response

def get_rate_and_tenure(days: int, rate_chart: dict):
    """
    Args:
        days (int): Number of days for FD
        rate_chart (dict): Interest rate chart JSON

    Returns:
        tuple: (rate_percent, tenure) or (None, None)
    """
    for rate in rate_chart.get("interest_rates", []):
        if rate["min_days"] <= days <= rate["max_days"]:
            return rate["rate_percent"], rate["tenure"]

    return None, None

# ================================ orchastrator function =================================================

class FixedDepositHandler:
    def __init__(self):
        self.state = self.initialize_state()

    def _update_state_from_request(self, additional_data:dict, journey_state: dict):
        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

    def initialize_state(self) -> Dict[str, Any]:
        return {
            "journey": "OPEN_FD",
            "bot_response": "",
            "fd_amount": None,
            "tenure": None,
            "tenure_description": None,
            "interest_rate": None,
            "show_interest_rate_chart": "false",
            "raise_final_confirmation": "no",
            "abort": "no",
            "change_default": "no",
            "off_topic_count": 0,
            "tenure_info": {},
            "expected_slot":None
        }

    async def fd_orchestrator(
            self,
            user_query: str,
            state: Dict[str, Any],
            fd_rate: Dict[str, Any],
            current_balance: int,
    ) -> Dict[str, Any]:

        start_time = time.time()

        intent = (await intent_identification(user_query, state, state["expected_slot"]))["intent"]
        logger.info("Intent identified | intent=%s", intent)

        state["raise_final_confirmation"] = "no"
        state["show_interest_rate_chart"] = "false"

        # ---------------- Abort ----------------
        if intent == "abort":
            state.update({"abort": "yes", "bot_response": "We appreciate your time with us. Your FD booking journey has now ended. You are always welcome to visit again."})
            return state

        # ---------------- Change default ----------------
        if intent == "change_default":
            state.update(
                {
                    "change_default": "yes",
                    "bot_response": "Kindly proceed with the below redirection",
                }
            )
            return state

        # ---------------- Off-topic ----------------
        if intent == "other":
            state["off_topic_count"] += 1
            if state["off_topic_count"] > 1:
                return {
                    **state,
                    "abort": "yes",
                    "bot_response": "We appreciate your time with us. Your FD booking journey has now ended. You are always welcome to visit again.",
                }

            state["bot_response"] = (
                "We are in the middle of an FD booking journey. "
                "Let us know if you want to abort."
            )
            return state

        consumed_value=None
        if not state["fd_amount"] or intent in ["change_amount","change_amount_and_tenure"]:
            print("Entering amount phase")
            state["expected_slot"]=None
            extraction_response = await update_amount(user_query)
            state["bot_response"] = extraction_response["bot_response"]

            extracted_amount = extraction_response["fd_amount"]
            if not extracted_amount:
                state["expected_slot"]='amount'
                return state

            validation_response = validate_fd_amount(
                amount=extracted_amount,
                current_balance=current_balance,
            )

            state["bot_response"] = validation_response["bot_response"]

            if not validation_response["fd_amount"]:
                state["expected_slot"]='amount'
                return state

            state["fd_amount"] = validation_response["fd_amount"]
            consumed_value={'amount':state['fd_amount']}
            

        # ---------------- Tenure phase ----------------
        if not state["tenure"] or intent in ["change_tenure","change_amount_and_tenure"]:
            print("Entering tenure phase")
            formatted_fd_rate = extract_interest_ranges(fd_rate)
            response = await update_tenure(user_query, formatted_fd_rate ,consumed_value,state["expected_slot"])
            state.update(
                {
                    "bot_response": response["bot_response"],
                    "show_interest_rate_chart": response["show_interest_rate_chart"],
                }
            )

            if not response["tenure"]:
                state["expected_slot"]='tenure'
                state["tenure"]=None
                return state
            
            best_plan = select_fd_plan(response["tenure"], fd_rate)    

            if not best_plan:
                state.update(
                    {
                        "bot_response": (
                            "Sorry, we don’t have an FD plan available for the selected tenure. "
                            "Please choose a tenure from the options below."
                        ),
                        "show_interest_rate_chart": "true",
                        "expected_slot":"tenure",
                        "tenure": None
                    }
                )
                return state

            state = {
                **state,
                **best_plan
            }

            state["tenure"] = response["tenure"]
        
        state["expected_slot"]=None

        # ---------------- Final confirmation ----------------
        response = raise_final_confirmation(
            user_query,
            booking_amount=state["fd_amount"],
            tenure=state["tenure"],
            interest_rate=state["interest_rate"],
        )

        state.update(
            {
                "raise_final_confirmation": response["raise_final_confirmation"].lower(),
                "bot_response": response["bot_response"],
                "show_interest_rate_chart": "false",
            }
        )

        logger.info(
            "FD orchestrator completed | duration=%.2fs",
            time.time() - start_time,
        )

        return state

    async def handle(self, user_query, journey_data, journey_state):
        state = self.state

        current_balance = journey_data.get("primary_balance", 0)
        fixed_deposit_plans = journey_data.get("fixed_deposit_plans", [])

        updated_state = await self.fd_orchestrator(
            user_query=user_query,
            state=state,
            fd_rate=fixed_deposit_plans,
            current_balance=current_balance,
        )
        self.state=updated_state
        return updated_state

    def get_tenure_info(self, days):
        years = days // 365
        remaining_days = days % 365
        return {
            "years": years,
            "days": remaining_days
        }


    def get_intent_data(self):
        journey_id="OPEN_FD"
        if self.state.get("raise_final_confirmation").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.RAISE_FINAL_CONFIRMATION"
            }

        if self.state.get("change_default").lower().strip() == "yes":
            return {
                "intent_type": "Redirection",
                "intent": journey_id
            }
        
        if self.state.get("show_interest_rate_chart").lower().strip() == "true":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SHOW_PLANS"
            }

        if self.state.get("abort").lower().strip() == "yes":
            return {
                "intent_type": "",
                "intent": ""
            }
        return {
            "intent_type": "Clarification",
            "intent": journey_id
        }
