import json
from typing import Dict, Any, List
from app.instrumentation.tracing.tracer import traced
from app.clients.elasticache.elasticache_client import get_elasticache_client
from app.clients.kafka.producer import get_producer
from app.config import settings
from datetime import datetime
import logging
logger = logging.getLogger(__name__)

class StateManager:
    def __init__(self):
        self.ttl = 1800
        self.JSON_FIELDS = {
            "loans", "credit_card", "debit_card",
            "account", "deposits", "fixed_deposit_plans", "additional_data"
        }
        self.kafka_producer = get_producer()

    @traced()
    async def initialize_journey(self, payload: Dict[str, Any], ai_session_id: str) -> str:
        try:
            client = await get_elasticache_client(read_only=False)
            redis_key = f"session:{ai_session_id}"

            accounts            = payload.get("account") or []
            credit_cards        = payload.get("credit_card") or []
            loans               = payload.get("loans") or []
            deposits            = payload.get("deposits") or []
            fixed_deposit_plans = payload.get("fixed_deposit_plans") or []
            debit_card          = payload.get("debit_card") or []
            customer_profile    = payload.get("customer_profile", "")

            has_savings_account = any(acc.get("account_type") == "SAVINGS" for acc in accounts)
            has_credit_card     = len(credit_cards) > 0
            has_loan            = len(loans) > 0
            has_fasttag         = "FASTAG" in customer_profile.upper()
            has_fd              = (
                any(dep.get("deposit_type") == "FD" for dep in deposits)
                or len(fixed_deposit_plans) > 0
            )

            journey_data = {
                "ai_session_id":   ai_session_id,
                "session_id":      payload.get("session_id"),
                "intent_id":       "",
                "journey_name":    "",

                "customer_id":     payload.get("customer_id"),
                "primary_balance": str(payload.get("primary_balance")) if payload.get("primary_balance") is not None else None,
                "language":        payload.get("language"),
                "search_type":     payload.get("search_type"),
                "timestamp":       payload.get("timestamp"),
                "additional_data": json.dumps(payload.get("additional_data") or {}),

                "customer_profile":   customer_profile,
                "customer_type":      payload.get("customer_type"),
                "role":               payload.get("role"),
                "residential_status": payload.get("residential_status"),
                "loans":               json.dumps(loans),
                "credit_card":         json.dumps(credit_cards),
                "debit_card":          json.dumps(debit_card),
                "account":             json.dumps(accounts),
                "deposits":            json.dumps(deposits),
                "fixed_deposit_plans": json.dumps(fixed_deposit_plans),
                "has_savings_account": str(has_savings_account),
                "has_credit_card":     str(has_credit_card),
                "has_loan":            str(has_loan),
                "has_fasttag":         str(has_fasttag),
                "has_fd":              str(has_fd),
            }

            journey_data = {k: v for k, v in journey_data.items() if v is not None}

            await client.hset(redis_key, mapping=journey_data)
            await client.expire(redis_key, 86400)

            logger.info(f"Journey initialized: {ai_session_id}")
            return ai_session_id
        except Exception as e:
            logger.error(f"Error initializing journey: {str(e)}")
            raise

    @traced()
    async def get_journey_data(self, ai_session_id: str) -> Dict[str, Any]:
        try:
            client = await get_elasticache_client(read_only=True)
            redis_key = f"session:{ai_session_id}"
            data = await client.hgetall(redis_key)
            if not data:
                return {}

            decoded_data = {}
            for key, value in data.items():
                if key in self.JSON_FIELDS:
                    decoded_data[key] = json.loads(value)
                elif key == "primary_balance":
                    decoded_data[key] = float(value) if value not in ("", "None", "null") else None
                elif key.startswith("has_"):
                    decoded_data[key] = value.lower() == "true"
                else:
                    decoded_data[key] = value

            return decoded_data
        except Exception as e:
            logger.error(f"Error retrieving journey data: {str(e)}")
            raise    
    @traced()
    async def update_journey_field(self, ai_session_id: str, field: str, value: Any) -> None:
        try:
            client = await get_elasticache_client(read_only=False)
            redis_key = f"session:{ai_session_id}"
            if isinstance(value, (list, dict)):
                value = json.dumps(value)
            elif isinstance(value, bool):
                value = str(value)

            await client.hset(redis_key, field, value)
            # logger.info(f"Updated field '{field}' for session: {ai_session_id}")
        except Exception as e:
            logger.error(f"Error updating journey field: {str(e)}")
            raise

    @traced()
    async def delete_journey(self, ai_session_id: str) -> None:
        try:
            client = await get_elasticache_client(read_only=False)
            redis_key = f"session:{ai_session_id}"
            await client.delete(redis_key)
            logger.info(f"Journey deleted for session: {ai_session_id}")
        except Exception as e:
            logger.error(f"Error deleting journey: {str(e)}")
            raise

    @traced()
    async def add_conversation_turn(self, ai_session_id: str, intent_id: str, user_query: str, bot_response: str) -> None:
        try:
            client = await get_elasticache_client(read_only=False)
            history_key = f"intent:{intent_id}:history"
            conversation_entry = {"user_query": user_query, "bot_response": bot_response}
            await client.lpush(history_key, json.dumps(conversation_entry))
            await client.ltrim(history_key, 0, 4)
            await client.expire(history_key, 86400)
        except Exception as e:
            logger.error(f"Error adding conversation turn: {e}")
            raise

        try:
            payload = {
                "ai_session_id":   ai_session_id,
                "intent_id":       intent_id,
                "user_query":      user_query,
                "bot_response":    bot_response,
                "event_timestamp": int(datetime.utcnow().timestamp() * 1000)
            }
            await self.kafka_producer.send_message(
                topic=settings.KAFKA_TOPIC,
                value=json.dumps(payload).encode("utf-8")
            )
        except Exception as e:
            logger.error(f"Kafka error: {e}")

    @traced()
    async def get_conversation_history(self, intent_id: str, limit: int = 5) -> List[Dict[str, Any]]:
        try:
            client = await get_elasticache_client(read_only=True)
            history_key = f"intent:{intent_id}:history"
            history_data = await client.lrange(history_key, 0, limit - 1)
            return [json.loads(entry) for entry in history_data]
        except Exception as e:
            logger.error(f"Error retrieving conversation history: {str(e)}")
            raise

    @traced()
    async def get_journey_state(self, intent_id: str, journey_name: str) -> Dict[str, Any]:
        try:
            client = await get_elasticache_client(read_only=True)
            state_key = f"intent:{intent_id}:{journey_name}_state"
            data = await client.hgetall(state_key)
            if not data:
                return {}

            decoded_state = {}
            for key, value in data.items():
                if value == "null":
                    decoded_state[key] = None
                elif value.lstrip('-').isdigit():
                    decoded_state[key] = int(value)
                else:
                    try:
                        decoded_state[key] = float(value)
                    except ValueError:
                        decoded_state[key] = value

            return decoded_state
        except Exception as e:
            logger.error(f"Error retrieving journey state: {str(e)}")
            raise

    @traced()
    async def update_journey_state(self, intent_id: str, journey_name: str, state_dict: Dict[str, Any]) -> None:
        try:
            client = await get_elasticache_client(read_only=False)
            state_key = f"intent:{intent_id}:{journey_name}_state"
            redis_state = {
                k: "null" if v is None else str(v)
                for k, v in state_dict.items()
            }
            await client.hset(state_key, mapping=redis_state)
            await client.expire(state_key, self.ttl)
        except Exception as e:
            logger.error(f"Error updating journey state: {str(e)}")
            raise

    @traced()
    async def delete_journey_state(self, intent_id: str, journey_name: str) -> None:
        try:
            client = await get_elasticache_client(read_only=False)
            state_key = f"intent:{intent_id}:{journey_name}_state"
            await client.delete(state_key)
            logger.info(f"Journey state deleted for {journey_name} in intent: {intent_id}")
        except Exception as e:
            logger.error(f"Error deleting journey state: {str(e)}")
            raise

    @traced()
    async def clean_conversation_history(self, intent_id: str) -> None:
        try:
            client = await get_elasticache_client(read_only=False)
            history_key = f"intent:{intent_id}:history"
            await client.ltrim(history_key, -1, 0)
        except Exception as e:
            logger.error(f"Error cleaning conversation history: {str(e)}")
            raise