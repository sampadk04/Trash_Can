# Models, Messages, and Tools

Smallest LangChain primitives you need inside LangGraph nodes.

## Model Setup

```python
from langchain.chat_models import init_chat_model
from langchain_openai import ChatOpenAI


model = init_chat_model("openai:gpt-5-nano", temperature=0)
openai_model = ChatOpenAI(model="gpt-5-nano", temperature=0, timeout=30)

response = model.invoke("Write one sentence about LangGraph.")
print(response.content)
```

Core runnable methods:

- `invoke(input)` / `ainvoke(input)`: one call.
- `stream(input)` / `astream(input)`: incremental output.
- `batch(inputs, config={"max_concurrency": 4})`: many calls.

## Messages

```python
from langchain.messages import HumanMessage, SystemMessage


messages = [
    SystemMessage(content="You are concise."),
    HumanMessage(content="Explain LangGraph reducers."),
]

response = model.invoke(messages)
messages.append(response)
```

Equivalent dict/tuple inputs are accepted:

```python
model.invoke([
    {"role": "system", "content": "You are concise."},
    {"role": "user", "content": "Explain reducers."},
])

model.invoke([
    ("system", "You are concise."),
    ("human", "Explain reducers."),
])
```

Common message classes:

- `SystemMessage`: behavior/context.
- `HumanMessage`: user input.
- `AIMessage`: model output, including `.tool_calls`.
- `ToolMessage`: tool result paired with a tool call ID.

## Tools

```python
from typing import Literal
from pydantic import BaseModel, Field
from langchain.tools import tool


@tool
def get_account_status(account_id: str) -> str:
    """Return account status for an account ID."""
    return "active"


class SearchInput(BaseModel):
    query: str = Field(description="Search query")
    source: Literal["docs", "tickets"] = "docs"


@tool(args_schema=SearchInput)
def search_knowledge_base(query: str, source: str = "docs") -> str:
    """Search a knowledge base."""
    return f"Results for {query} in {source}"
```

Bind tools to a model:

```python
model_with_tools = model.bind_tools([get_account_status, search_knowledge_base])
ai_msg = model_with_tools.invoke("Check account A-123.")

for call in ai_msg.tool_calls:
    print(call["name"], call["args"], call["id"])
```

Execute tool calls inside a custom graph node:

```python
from langchain.messages import ToolMessage


tools = [get_account_status, search_knowledge_base]
tools_by_name = {tool.name: tool for tool in tools}


def call_tools(state: State) -> dict:
    outputs = []
    for call in state["messages"][-1].tool_calls:
        result = tools_by_name[call["name"]].invoke(call["args"])
        outputs.append(ToolMessage(content=str(result), tool_call_id=call["id"]))
    return {"messages": outputs}
```

## Source Links

- Models: https://docs.langchain.com/oss/python/langchain/models
- Messages: https://docs.langchain.com/oss/python/langchain/messages
- Tools: https://docs.langchain.com/oss/python/langchain/tools
