from typing import Any

from langgraph.graph import END, START, StateGraph

from app.services.optimus_query_bot.intent_handlers_lg.email_update.models import (
    EmailConfirmationOutput,
    EmailUpdateGraphState,
)
from app.services.optimus_query_bot.intent_handlers_lg.email_update.prompts import (
    EMAIL_CONFIRMATION_SYSTEM_PROMPT,
)
from app.services.optimus_query_bot.intent_handlers_lg.shared.llm import ainvoke_structured


def initialize_state() -> dict[str, Any]:
    return {
        "journey": "CHANGE_EMAIL",
        "bot_response": "",
        "change_email_eligibility": "no",
        "eligibility_checked": "no",
        "is_eligible": None,
        "email_mfa": "no",
        "get_new_email": "no",
        "new_email": None,
        "current_email": None,
        "service_request_no": None,
        "confirmation_raised": "no",
        "status": "none",
        "abort": "no",
        "off_topic_count": 0,
    }


async def get_confirmation(user_query: str) -> dict[str, Any]:
    response = await ainvoke_structured(
        [
            ("system", EMAIL_CONFIRMATION_SYSTEM_PROMPT),
            ("human", f"user_query:{user_query}"),
        ],
        EmailConfirmationOutput,
    )
    return response.model_dump()


async def email_update_orchestrator(state: EmailUpdateGraphState) -> dict[str, Any]:
    data = state.model_dump()

    data["change_email_eligibility"] = "no"
    data["get_new_email"] = "no"
    data["email_mfa"] = "no"

    if data["eligibility_checked"] == "no":
        data["change_email_eligibility"] = "yes"
        data["bot_response"] = "Checking whether your account is eligible for email address change."
        return data

    if data["is_eligible"] == "no":
        data["bot_response"] = "You are currently not eligible to change your registered email address."
        return data

    if data["is_eligible"] == "yes" and not data["new_email"]:
        data["get_new_email"] = "yes"
        data["bot_response"] = (
            f"You are eligible to change your email address."
            f"Your current email ID is **{data['current_email']}**\n"
            f"Please enter your new email address."
        )
        return data

    if data["new_email"] and data["confirmation_raised"] == "no":
        data.update(
            {
                "confirmation_raised": "yes",
                "bot_response": (
                    "Your email address will be updated across the following accounts:\n"
                    "- **Savings Account**\n"
                    "- **Credit Card**\n"
                    "- **Loan Account (if applicable)\n"
                    "Please confirm if you want to proceed."
                ),
            }
        )
        return data

    if data["new_email"] and data["confirmation_raised"] == "yes" and data["status"] == "none":
        confirmation_response = await get_confirmation(data["user_query"])

        if confirmation_response.get("confirmation") == "yes":
            data["email_mfa"] = "yes"
            data["bot_response"] = "Please complete the verification to proceed with changing your email address."
            return data

        if confirmation_response.get("confirmation") == "no":
            data.update(
                {
                    "abort": "yes",
                    "bot_response": (
                        "No problem. The email change request has been cancelled. "
                        "You can try again anytime."
                    ),
                }
            )
            return data

        data["bot_response"] = "Please confirm whether you want to proceed with changing your email address."
        return data

    if data["status"] == "success":
        data["abort"] = "yes"
        data["bot_response"] = (
            "Your email address has been changed successfully.\n"
            f"Service Request Number: **{data['service_request_no']}**\n"
        )
        return data

    if data["status"] == "failure":
        data["abort"] = "yes"
        data["bot_response"] = "We could not process your request please try again later"
        return data

    return data


def build_graph():
    builder = StateGraph(EmailUpdateGraphState)
    builder.add_node("orchestrate_email_update", email_update_orchestrator)
    builder.add_edge(START, "orchestrate_email_update")
    builder.add_edge("orchestrate_email_update", END)
    return builder.compile()
