# Branching and Parallelism

## Fixed Parallel Branching

Multiple outgoing edges from one step run independent work in the next super-step.

```python
from typing_extensions import TypedDict
from langgraph.graph import END, START, StateGraph


class State(TypedDict):
    topic: str
    joke: str
    story: str
    combined: str


def write_joke(state: State) -> dict:
    return {"joke": f"Joke about {state['topic']}"}


def write_story(state: State) -> dict:
    return {"story": f"Story about {state['topic']}"}


def combine(state: State) -> dict:
    return {"combined": "\n\n".join([state["story"], state["joke"]])}


builder = StateGraph(State)
builder.add_node("write_joke", write_joke)
builder.add_node("write_story", write_story)
builder.add_node("combine", combine)
builder.add_edge(START, "write_joke")
builder.add_edge(START, "write_story")
builder.add_edge("write_joke", "combine")
builder.add_edge("write_story", "combine")
builder.add_edge("combine", END)
graph = builder.compile()
```

Use this for a known number of independent tasks.

## Conditional Branching

```python
from typing import Literal


class RouteState(TypedDict):
    request: str
    route: Literal["retrieve", "answer", "human_review"] | None


def classify(state: RouteState) -> dict:
    text = state["request"].lower()
    if "urgent" in text:
        return {"route": "human_review"}
    if "docs" in text:
        return {"route": "retrieve"}
    return {"route": "answer"}


def route_after_classify(
    state: RouteState,
) -> Literal["retrieve", "answer", "human_review"]:
    return state["route"]


builder.add_conditional_edges("classify", route_after_classify)
```

Use an explicit mapping when return values differ from node names:

```python
builder.add_conditional_edges(
    "classify",
    route_after_classify,
    {"retrieve": "search_docs", "answer": "answer", "human_review": "review"},
)
```

LLM routers should use structured output:

```python
from pydantic import BaseModel


class Route(BaseModel):
    next_step: Literal["retrieve", "answer", "human_review"]


router = model.with_structured_output(Route)


def llm_classify(state: RouteState) -> dict:
    return {"route": router.invoke(state["request"]).next_step}
```

## Conditional Parallel Branching

```python
from collections.abc import Sequence


def route_research(state: RouteState) -> Sequence[str]:
    if state["route"] == "human_review":
        return ["retrieve_policy", "retrieve_history", "retrieve_examples"]
    return ["retrieve_policy"]
```

Use reducers for any state key written by multiple destination nodes.

## Dynamic Fan-Out with `Send`

Use `Send` when the number of workers is dynamic and each worker needs its own state payload.

```python
import operator
from typing import Annotated
from langgraph.types import Send


class ReportState(TypedDict):
    topic: str
    sections: list[str]
    section_notes: Annotated[list[str], operator.add]
    report: str


class WorkerState(TypedDict):
    topic: str
    section: str


def plan_sections(state: ReportState) -> dict:
    return {"sections": ["risks", "benefits", "implementation"]}


def route_workers(state: ReportState) -> list[Send]:
    return [
        Send("write_section_note", {"topic": state["topic"], "section": section})
        for section in state["sections"]
    ]


def write_section_note(state: WorkerState) -> dict:
    return {"section_notes": [f"{state['section']} notes for {state['topic']}"]}


def reduce_report(state: ReportState) -> dict:
    return {"report": "\n".join(state["section_notes"])}


builder = StateGraph(ReportState)
builder.add_node("plan_sections", plan_sections)
builder.add_node("write_section_note", write_section_note)
builder.add_node("reduce_report", reduce_report)
builder.add_edge(START, "plan_sections")
builder.add_conditional_edges("plan_sections", route_workers)
builder.add_edge("write_section_note", "reduce_report")
builder.add_edge("reduce_report", END)
graph = builder.compile()
```

## Pattern Map

- Prompt chaining: sequential nodes plus validation gates.
- Routing: structured output or code classification plus conditional edges.
- Parallelization: fixed fan-out plus aggregator.
- Orchestrator-worker: `Send` plus reducer channel.
- Evaluator-optimizer: loop from evaluator back to revise, with an iteration guard.

## Source Links

- Use the Graph API: https://docs.langchain.com/oss/python/langgraph/use-graph-api
- Workflows and agents: https://docs.langchain.com/oss/python/langgraph/workflows-agents
