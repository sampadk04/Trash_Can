# LangGraph Quickstart: Graph API Only

A minimal tool-calling loop built with explicit graph nodes and edges.

```python
from typing import Literal
from langchain.messages import HumanMessage, SystemMessage, ToolMessage
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import END, START, MessagesState, StateGraph


@tool
def add(a: int, b: int) -> int:
    """Add two integers."""
    return a + b


tools = [add]
tools_by_name = {tool.name: tool for tool in tools}
model = ChatOpenAI(model="gpt-5-nano", temperature=0).bind_tools(tools)


class State(MessagesState):
    llm_calls: int


def call_model(state: State) -> dict:
    response = model.invoke(
        [SystemMessage(content="Use tools for arithmetic.")] + state["messages"]
    )
    return {
        "messages": [response],
        "llm_calls": state.get("llm_calls", 0) + 1,
    }


def call_tools(state: State) -> dict:
    outputs = []
    for call in state["messages"][-1].tool_calls:
        result = tools_by_name[call["name"]].invoke(call["args"])
        outputs.append(ToolMessage(content=str(result), tool_call_id=call["id"]))
    return {"messages": outputs}


def should_continue(state: State) -> Literal["call_tools", "__end__"]:
    return "call_tools" if state["messages"][-1].tool_calls else END


builder = StateGraph(State)
builder.add_node("call_model", call_model)
builder.add_node("call_tools", call_tools)
builder.add_edge(START, "call_model")
builder.add_conditional_edges("call_model", should_continue)
builder.add_edge("call_tools", "call_model")
graph = builder.compile()

result = graph.invoke({
    "messages": [HumanMessage(content="Add 3 and 4.")]
})
print(result["messages"][-1].content)
```

Key shape:

- define state,
- define nodes that return partial updates,
- route with normal/conditional edges,
- call `.compile()`,
- invoke or stream the compiled graph.

## Source Links

- Official quickstart: https://docs.langchain.com/oss/python/langgraph/quickstart
- Graph API overview: https://docs.langchain.com/oss/python/langgraph/graph-api
