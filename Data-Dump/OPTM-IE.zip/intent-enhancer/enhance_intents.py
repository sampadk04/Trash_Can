import argparse
import asyncio
import csv
import json
import logging
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

import pandas as pd
from dotenv import load_dotenv
from openai import AsyncOpenAI
from pydantic import BaseModel, Field, field_validator
from rich.console import Console
from rich.logging import RichHandler
from rich.table import Table
from tqdm import tqdm


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_INPUT = ROOT / "data" / "raw-intents" / "optimus-raw-intents.csv"
DEFAULT_OUTPUT = ROOT / "data" / "raw-intents" / "optimus-raw-intents-v2.csv"
RUNS_DIR = Path(__file__).resolve().parent / "runs"
NLU_COLUMNS = [
    "nlu_intent",
    "nlu_entities",
    "nlu_examples",
    "nlu_disambiguation_hint",
]

console = Console()
logger = logging.getLogger("intent-enhancer")


class NluEntity(BaseModel):
    key: str
    value: str

    @field_validator("key", "value")
    @classmethod
    def non_empty(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("value must be non-empty")
        return value


class NluRowOutput(BaseModel):
    nlu_intent: str = Field(description="Normalized snake_case high-level user goal.")
    nlu_entities: list[NluEntity] = Field(description="Meaningful NLU entity key/value pairs.")
    nlu_examples: str = Field(description="Compact pipe-separated examples/synonyms from source text.")
    nlu_disambiguation_hint: str = Field(description="Short hint for separating this intent from similar rows.")

    @field_validator("nlu_intent", "nlu_examples", "nlu_disambiguation_hint")
    @classmethod
    def non_empty_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("value must be non-empty")
        return value

    @field_validator("nlu_entities", mode="before")
    @classmethod
    def non_empty_entities(cls, value: list[NluEntity] | dict[str, str]) -> list[NluEntity] | dict[str, str]:
        if isinstance(value, dict):
            value = [NluEntity(key=key, value=item) for key, item in value.items()]
        if not value:
            raise ValueError("nlu_entities must be a non-empty object")
        return value


class CritiqueUpdate(BaseModel):
    row_number: int = Field(description="1-based source CSV row number to update.")
    change_type: Literal[
        "semantic_mismatch",
        "routing_collision",
        "normalization_consistency",
        "duplicate_split",
        "material_entity_gap",
    ]
    issue: str
    nlu_intent: str
    nlu_entities: list[NluEntity]
    nlu_examples: str
    nlu_disambiguation_hint: str


class GlobalCritiqueOutput(BaseModel):
    summary: str
    is_converged: bool = Field(description="True when no material critique updates remain.")
    systemic_patterns: list[str] = Field(default_factory=list)
    locked_decisions: list[str] = Field(default_factory=list)
    issues: list[str] = Field(default_factory=list)
    updates: list[CritiqueUpdate] = Field(default_factory=list)


def configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[RichHandler(console=console, show_path=False, rich_tracebacks=True)],
    )


def load_source_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    logger.info("Loaded %s rows from %s", len(df), path)
    return df


def row_payload(row_number: int, row: pd.Series) -> dict[str, Any]:
    return {
        "row_number": row_number,
        "source_row": {key: row.get(key, "") for key in row.index},
    }


def row_prompt(row_number: int, row: pd.Series) -> str:
    return json.dumps(row_payload(row_number, row), ensure_ascii=False)


def generation_instructions() -> str:
    return """You are creating Rasa/Dialogflow-style NLU columns for Indian banking app intents.

Use only the provided old row data. Prioritize intent, title, and label over noisy tags or description.

Return:
- nlu_intent: snake_case high-level user goal. Keep it specific enough to avoid unrelated rows sharing one intent.
- nlu_entities: compact key/value pairs with useful parameters such as action, product, feature, card_type,
  document_type, payment_type, loan_type, deposit_type, account_type, channel, status,
  transaction_status, limit_type, biller_type, service_type, investment_mode, investment_goal,
  fund_house, fund_category, insurance_type, or profile_attribute.
- nlu_examples: pipe-separated examples/synonyms derived from tags, title, and label.
- nlu_disambiguation_hint: one short plain-English sentence explaining how to separate this row from similar intents.

Do not invent user goals that conflict with the old intent/title/label. Treat CHANGE/UPDATE as update,
TRANSFER as transfer, settlement as settle, and generic bill payment as bill payment unless the title/label
explicitly says credit card."""


async def generate_row_nlu(
    client: AsyncOpenAI,
    model: str,
    row_number: int,
    row: pd.Series,
    semaphore: asyncio.Semaphore,
    retries: int,
) -> tuple[int, NluRowOutput]:
    async with semaphore:
        last_error: Exception | None = None
        for attempt in range(1, retries + 1):
            try:
                response = await client.responses.parse(
                    model=model,
                    instructions=generation_instructions(),
                    input=row_prompt(row_number, row),
                    text_format=NluRowOutput,
                    reasoning={"effort": "low"},
                )
                return row_number, response.output_parsed
            except Exception as exc:  # noqa: BLE001 - CLI should log API/schema failures and retry.
                last_error = exc
                logger.warning("Row %s failed on attempt %s/%s: %s", row_number, attempt, retries, exc)
                await asyncio.sleep(min(2**attempt, 20))
        raise RuntimeError(f"Row {row_number} failed after {retries} attempts") from last_error


async def run_first_pass(
    client: AsyncOpenAI,
    df: pd.DataFrame,
    model: str,
    concurrency: int,
    retries: int,
    run_dir: Path,
) -> list[NluRowOutput]:
    checkpoint_path = run_dir / "first_pass_rows.jsonl"
    completed: dict[int, NluRowOutput] = {}

    if checkpoint_path.exists():
        with checkpoint_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                record = json.loads(line)
                completed[int(record["row_number"])] = NluRowOutput.model_validate(record["nlu"])
        logger.info("Loaded %s first-pass checkpoint rows", len(completed))

    semaphore = asyncio.Semaphore(concurrency)
    tasks = [
        generate_row_nlu(client, model, index + 1, row, semaphore, retries)
        for index, row in df.iterrows()
        if index + 1 not in completed
    ]

    if tasks:
        logger.info("Running first pass for %s rows with concurrency=%s", len(tasks), concurrency)
        with checkpoint_path.open("a", encoding="utf-8") as handle:
            for task in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="First pass"):
                row_number, nlu = await task
                completed[row_number] = nlu
                handle.write(json.dumps({"row_number": row_number, "nlu": nlu.model_dump()}, ensure_ascii=False) + "\n")
                handle.flush()

    return [completed[row_number] for row_number in range(1, len(df) + 1)]


def nlu_to_columns(rows: list[NluRowOutput]) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "nlu_intent": row.nlu_intent,
                "nlu_entities": json.dumps(entities_to_dict(row.nlu_entities), sort_keys=True, ensure_ascii=False),
                "nlu_examples": row.nlu_examples,
                "nlu_disambiguation_hint": row.nlu_disambiguation_hint,
            }
            for row in rows
        ]
    )


def entities_to_dict(entities: list[NluEntity]) -> dict[str, str]:
    return {entity.key.strip(): entity.value.strip() for entity in entities if entity.key.strip() and entity.value.strip()}


def combined_context(source_df: pd.DataFrame, output_df: pd.DataFrame) -> str:
    columns = list(source_df.columns) + NLU_COLUMNS
    combined = pd.concat([source_df.reset_index(drop=True), output_df[NLU_COLUMNS].reset_index(drop=True)], axis=1)
    combined.insert(0, "row_number", range(1, len(combined) + 1))
    return combined[["row_number", *columns]].to_csv(index=False, quoting=csv.QUOTE_MINIMAL)


def critique_instructions() -> str:
    return """You are globally reviewing generated NLU columns for a banking intents CSV.

Compare each row's old columns against the generated nlu_intent, nlu_entities, nlu_examples,
and nlu_disambiguation_hint. This is a correction pass, not a style improvement pass.

Return updates only for material issues that can cause wrong routing or bad training data:
- semantic_mismatch: nlu_intent or entities contradict intent/title/label/deeplink.
- routing_collision: examples/entities would confuse a row with a different banking flow.
- normalization_consistency: inconsistent entity values for the same product/feature can split routing.
- duplicate_split: unrelated rows share an nlu_intent.
- material_entity_gap: a missing entity is required to distinguish similar intents.

Do not return cosmetic renames, preference-only changes, or "could be more precise" refinements.

Systemic sweep rule:
If you identify a normalization pattern, scan the entire supplied CSV and return every affected row in this
same iteration. Examples: mutual_funds -> mutual_fund, sgb -> sovereign_gold_bond, generic bill_payment vs
credit_card_bill. Do not defer other rows with the same pattern to later iterations.

Convergence rules:
- Previous accepted updates and locked decisions are authoritative unless a row still has a material contradiction.
- Do not reopen or contradict a locked normalization decision.
- Do not repeat prior issues or suggestions.
- If no material issues remain, set is_converged=true and return no updates.
- If updates are returned, set is_converged=false.
- Aim to converge within 2-3 critique/update iterations."""


def critique_prompt(
    source_df: pd.DataFrame,
    output_df: pd.DataFrame,
    previous_summaries: list[str],
    applied_updates: list[dict[str, Any]],
    systemic_patterns: list[str],
    locked_decisions: list[str],
) -> str:
    payload = {
        "previous_critique_summaries": previous_summaries,
        "previous_applied_updates": applied_updates,
        "previous_systemic_patterns": systemic_patterns,
        "previous_locked_decisions": locked_decisions,
        "csv_context": combined_context(source_df, output_df),
    }
    return json.dumps(payload, ensure_ascii=False)


async def run_critique_iteration(
    client: AsyncOpenAI,
    source_df: pd.DataFrame,
    output_df: pd.DataFrame,
    model: str,
    iteration: int,
    previous_summaries: list[str],
    applied_updates: list[dict[str, Any]],
    systemic_patterns: list[str],
    locked_decisions: list[str],
    run_dir: Path,
) -> GlobalCritiqueOutput:
    logger.info("Running critique iteration %s", iteration)
    response = await client.responses.parse(
        model=model,
        instructions=critique_instructions(),
        input=critique_prompt(
            source_df,
            output_df,
            previous_summaries,
            applied_updates,
            systemic_patterns,
            locked_decisions,
        ),
        text_format=GlobalCritiqueOutput,
        reasoning={"effort": "medium"},
    )
    critique = response.output_parsed
    (run_dir / f"critique_iteration_{iteration}.json").write_text(
        critique.model_dump_json(indent=2),
        encoding="utf-8",
    )
    return critique


def apply_updates(output_df: pd.DataFrame, updates: list[CritiqueUpdate]) -> list[dict[str, Any]]:
    applied: list[dict[str, Any]] = []
    for update in updates:
        index = update.row_number - 1
        if index < 0 or index >= len(output_df):
            logger.warning("Skipping update for invalid row_number=%s", update.row_number)
            continue
        output_df.at[index, "nlu_intent"] = update.nlu_intent.strip()
        output_df.at[index, "nlu_entities"] = json.dumps(entities_to_dict(update.nlu_entities), sort_keys=True, ensure_ascii=False)
        output_df.at[index, "nlu_examples"] = update.nlu_examples.strip()
        output_df.at[index, "nlu_disambiguation_hint"] = update.nlu_disambiguation_hint.strip()
        applied.append(update.model_dump())
    return applied


def validate_output(source_df: pd.DataFrame, output_df: pd.DataFrame) -> None:
    if len(source_df) != len(output_df):
        raise ValueError(f"Row count mismatch: source={len(source_df)} output={len(output_df)}")

    source_columns = list(source_df.columns)
    if list(output_df.columns[: len(source_columns)]) != source_columns:
        raise ValueError("Source columns are not preserved in the same order")

    appended = list(output_df.columns[len(source_columns) :])
    if appended != NLU_COLUMNS:
        raise ValueError(f"Unexpected appended columns: {appended}")

    for column in ["nlu_intent", "nlu_disambiguation_hint"]:
        empty = output_df[column].fillna("").astype(str).str.strip().eq("").sum()
        if empty:
            raise ValueError(f"{column} has {empty} empty rows")

    for row_number, value in enumerate(output_df["nlu_entities"], start=1):
        parsed = json.loads(value)
        if not isinstance(parsed, dict) or not parsed:
            raise ValueError(f"nlu_entities at row {row_number} is not a non-empty JSON object")


def show_duplicate_report(output_df: pd.DataFrame) -> None:
    duplicates = output_df["nlu_intent"].value_counts()
    duplicates = duplicates[duplicates > 1]
    if duplicates.empty:
        console.print("[green]No duplicate nlu_intent groups found.[/green]")
        return

    table = Table(title="Duplicate nlu_intent groups")
    table.add_column("nlu_intent")
    table.add_column("count", justify="right")
    table.add_column("source intents")
    for nlu_intent, count in duplicates.items():
        intents = sorted(output_df.loc[output_df["nlu_intent"] == nlu_intent, "intent"].astype(str).unique())
        table.add_row(str(nlu_intent), str(count), ", ".join(intents))
    console.print(table)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def update_run_metadata(run_dir: Path, data: dict[str, Any]) -> None:
    path = run_dir / "run_metadata.json"
    current = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    if "started_at" not in current:
        current["started_at"] = utc_now()
    else:
        current["last_resumed_at"] = utc_now()
    current.update(data)
    path.write_text(json.dumps(current, indent=2, ensure_ascii=False), encoding="utf-8")


def critique_iteration_number(path: Path) -> int:
    match = re.search(r"critique_iteration_(\d+)\.json$", path.name)
    return int(match.group(1)) if match else 0


def latest_critique_csv(run_dir: Path) -> tuple[int, Path | None]:
    latest_iteration = 0
    latest_path: Path | None = None
    for path in run_dir.glob("after_critique_iteration_*.csv"):
        match = re.search(r"after_critique_iteration_(\d+)\.csv$", path.name)
        if match and int(match.group(1)) > latest_iteration:
            latest_iteration = int(match.group(1))
            latest_path = path
    return latest_iteration, latest_path


def load_prior_critique_context(run_dir: Path) -> tuple[list[str], list[dict[str, Any]], list[str], list[str]]:
    summaries: list[str] = []
    updates: list[dict[str, Any]] = []
    systemic_patterns: list[str] = []
    locked_decisions: list[str] = []

    for path in sorted(run_dir.glob("critique_iteration_*.json"), key=critique_iteration_number):
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("summary"):
            summaries.append(str(data["summary"]))
        updates.extend(data.get("updates", []))
        systemic_patterns.extend(str(item) for item in data.get("systemic_patterns", []))
        locked_decisions.extend(str(item) for item in data.get("locked_decisions", []))

    return summaries, updates, list(dict.fromkeys(systemic_patterns)), list(dict.fromkeys(locked_decisions))


def load_resume_state(run_dir: Path) -> tuple[pd.DataFrame | None, int]:
    latest_iteration, latest_path = latest_critique_csv(run_dir)
    if latest_path:
        logger.info("Resuming from %s", latest_path)
        return pd.read_csv(latest_path, dtype=str, keep_default_na=False), latest_iteration + 1

    first_pass_path = run_dir / "first_pass.csv"
    if first_pass_path.exists():
        logger.info("Resuming from %s", first_pass_path)
        return pd.read_csv(first_pass_path, dtype=str, keep_default_na=False), 1

    return None, 1


def inspect_run(run_dir: Path) -> None:
    output_df, next_iteration = load_resume_state(run_dir)
    checkpoint_path = run_dir / "first_pass_rows.jsonl"
    checkpoint_count = 0
    if checkpoint_path.exists():
        with checkpoint_path.open("r", encoding="utf-8") as handle:
            checkpoint_count = sum(1 for _ in handle)

    table = Table(title=f"Run state: {run_dir.name}")
    table.add_column("item")
    table.add_column("value")
    table.add_row("run_dir", str(run_dir))
    table.add_row("first_pass_rows", str(checkpoint_count))
    table.add_row("has_first_pass_csv", str((run_dir / "first_pass.csv").exists()))
    table.add_row("latest_output_rows", str(0 if output_df is None else len(output_df)))
    table.add_row("next_critique_iteration", str(next_iteration))
    console.print(table)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate Optimus raw intents v2 NLU columns with OpenAI.")
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--model", default="gpt-5.2")
    parser.add_argument("--concurrency", type=int, default=10)
    parser.add_argument("--critique-iterations", type=int, default=3)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--run-id", help="UUID or existing run folder name to resume.")
    parser.add_argument("--inspect-run", action="store_true", help="Show resume state for --run-id without API calls.")
    return parser.parse_args()


async def async_main() -> None:
    args = parse_args()
    configure_logging()
    load_dotenv(ROOT / ".env")

    run_id = args.run_id or uuid.uuid4().hex
    run_dir = RUNS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    if args.inspect_run:
        inspect_run(run_dir)
        return

    source_df = load_source_csv(args.input)
    update_run_metadata(
        run_dir,
        {
            "run_id": run_id,
            "input": str(args.input),
            "output": str(args.output),
            "model": args.model,
            "concurrency": args.concurrency,
            "critique_iterations": args.critique_iterations,
        },
    )
    client = AsyncOpenAI()

    output_df, start_iteration = load_resume_state(run_dir)
    if output_df is None:
        console.rule("[bold]First pass")
        nlu_rows = await run_first_pass(client, source_df, args.model, args.concurrency, args.retries, run_dir)
        nlu_df = nlu_to_columns(nlu_rows)
        output_df = pd.concat([source_df.reset_index(drop=True), nlu_df], axis=1)
        output_df.to_csv(run_dir / "first_pass.csv", index=False)
    else:
        validate_output(source_df, output_df)

    previous_summaries, all_applied_updates, systemic_patterns, locked_decisions = load_prior_critique_context(run_dir)

    console.rule("[bold]Global critique")
    end_iteration = start_iteration + args.critique_iterations - 1
    for iteration in range(start_iteration, end_iteration + 1):
        critique = await run_critique_iteration(
            client,
            source_df,
            output_df,
            args.model,
            iteration,
            previous_summaries,
            all_applied_updates,
            systemic_patterns,
            locked_decisions,
            run_dir,
        )
        previous_summaries.append(critique.summary)
        systemic_patterns.extend(item for item in critique.systemic_patterns if item not in systemic_patterns)
        locked_decisions.extend(item for item in critique.locked_decisions if item not in locked_decisions)
        applied = apply_updates(output_df, critique.updates)
        all_applied_updates.extend(applied)
        output_df.to_csv(run_dir / f"after_critique_iteration_{iteration}.csv", index=False)
        logger.info("Critique iteration %s: %s updates applied", iteration, len(applied))
        if critique.is_converged or not applied:
            break

    console.rule("[bold]Validation")
    validate_output(source_df, output_df)
    output_df.to_csv(args.output, index=False)
    show_duplicate_report(output_df)
    logger.info("Wrote %s rows and %s columns to %s", len(output_df), len(output_df.columns), args.output)
    logger.info("Run artifacts: %s", run_dir)


def main() -> None:
    asyncio.run(async_main())


if __name__ == "__main__":
    main()
