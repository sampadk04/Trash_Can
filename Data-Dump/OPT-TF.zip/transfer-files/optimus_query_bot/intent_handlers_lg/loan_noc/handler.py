from typing import Any

from app.services.optimus_query_bot.intent_handlers_lg.loan_noc.graph import (
    build_graph,
    initialize_noc_state,
)
from app.services.optimus_query_bot.intent_handlers_lg.shared.state import yes


class LoanNocGraphHandler:
    def __init__(self):
        self.state = initialize_noc_state()
        self.graph = build_graph()

    def _update_state_from_request(self, additional_data: dict, journey_state: dict):
        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

        if "noc_loan" in additional_data:
            self.state["noc_loan"] = additional_data.get("noc_loan").lower().strip()
        if "noc_address" in additional_data:
            self.state["noc_address"] = additional_data.get("noc_address")
        if "status" in additional_data:
            self.state["status"] = additional_data.get("status")
        if "service_request_no" in additional_data:
            self.state["service_request_no"] = additional_data.get("service_request_no")

    async def handle(self, user_query: str, journey_data: dict[str, Any], journey_state: dict[str, Any]):
        result = await self.graph.ainvoke({**self.state, "user_query": user_query})
        result.pop("user_query", None)
        self.state = result
        return self.state

    def get_intent_data(self):
        journey_id = "LOAN_NOC"
        status = self.state.get("status")
        if status and str(status).lower().strip() == "success":
            return {"intent_type": "Execution", "intent": f"{journey_id}.SHOW_FINAL_STATUS"}
        if yes(self.state.get("raise_noc_request")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.CREATE_NOC_REQUEST"}
        if yes(self.state.get("show_address")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.CONFIRM_ADDRESS"}
        if yes(self.state.get("show_redirection")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.SHOW_REDIRECTION"}
        if yes(self.state.get("fetch_loan_list")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.SELECT_NOC_LOAN"}
        return {"intent_type": "Clarification", "intent": journey_id}
