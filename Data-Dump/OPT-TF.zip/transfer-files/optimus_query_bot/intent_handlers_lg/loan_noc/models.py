from typing import Any, Literal

from pydantic import BaseModel, Field


class LoanNocGraphState(BaseModel):
    journey: str = Field(default="LOAN_NOC", description="Current loan NOC journey identifier.")
    bot_response: str = Field(default="", description="Customer-facing response for the current turn.")
    noc_loan: Any = Field(default=None, description="Selected loan for NOC request.")
    noc_address: Any = Field(default=None, description="Address to which the NOC should be sent.")
    status: Any = Field(default=None, description="NOC request execution status, success or failure.")
    service_request_no: Any = Field(default=None, description="Service request number returned after request creation.")
    fetch_loan_list: str = Field(default="no", description="Whether the UI should show loan list.")
    show_address: str = Field(default="no", description="Whether the UI should show address confirmation.")
    raise_noc_request: str = Field(default="no", description="Whether the backend should create the NOC request.")
    show_redirection: str = Field(default="no", description="Whether the UI should show redirection.")
    abort: str = Field(default="no", description="Whether this journey is aborted.")
    user_query: str = Field(default="", description="Latest user message.")


class LoanNocConfirmationOutput(BaseModel):
    confirmation: Literal["yes", "no"] = Field(
        description="Whether the user explicitly confirms the displayed address."
    )
