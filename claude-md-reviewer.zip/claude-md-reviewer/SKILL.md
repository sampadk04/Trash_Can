---
name: claude-md-reviewer
description: >
  Review and improve CLAUDE.md (or AGENTS.md) files for coding agents.
  TRIGGER when: user asks to "review CLAUDE.md", "improve CLAUDE.md",
  "optimize CLAUDE.md", "check my CLAUDE.md", "enhance CLAUDE.md",
  "audit CLAUDE.md", "review AGENTS.md", "improve AGENTS.md",
  or mentions making their agent instructions better.
  NOT for: writing skills, slash commands, hooks, or general documentation.
allowed-tools: Read, Edit, Write, Glob, Grep
---

# CLAUDE.md Reviewer

Review and enhance `CLAUDE.md` (or `AGENTS.md`) files based on proven best practices for coding agent onboarding.

## When to Use This Skill

- User wants to review, audit, or improve their `CLAUDE.md` or `AGENTS.md`
- User wants to restructure agent instructions for better compliance
- User asks why the agent keeps ignoring their `CLAUDE.md` instructions
- User wants help writing a new `CLAUDE.md` from scratch

## Review Process

Follow this process when reviewing a `CLAUDE.md` file:

### Step 1: Read and Analyze

1. Read the target `CLAUDE.md` (or `AGENTS.md`) file
2. Count the number of discrete instructions in the file
3. Measure the file length in lines
4. Identify each section's purpose

### Step 2: Score Against Checklist

Evaluate the file against each criterion in [references/review-checklist.md](references/review-checklist.md). For each item, assign:
- PASS: Meets the criterion
- WARN: Partially meets or could be improved
- FAIL: Violates the criterion

### Step 3: Present the Review

Present findings in this format:

```
## CLAUDE.md Review Summary

| Metric | Value | Target |
|--------|-------|--------|
| Total lines | X | < 300 (ideally < 100) |
| Instruction count | X | < 100 (fewer is better) |
| Has WHY section | Yes/No | Yes |
| Has WHAT section | Yes/No | Yes |
| Has HOW section | Yes/No | Yes |
| Uses progressive disclosure | Yes/No | Yes |

## Checklist Results

| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | ... | PASS/WARN/FAIL | ... |

## Top Recommendations
1. ...
2. ...
3. ...
```

### Step 4: Offer to Fix

After presenting the review, offer to:
1. Rewrite the file applying all recommendations
2. Extract task-specific content into `agent_docs/` files with progressive disclosure
3. Remove linter/formatter instructions and suggest hooks instead

## Key Principles

Read [references/best-practices.md](references/best-practices.md) for the full rationale behind each principle.

| Principle | Rule of Thumb |
|-----------|---------------|
| Less is more | < 100 instructions total; < 300 lines |
| Universal applicability | Every line should matter for every task |
| Progressive disclosure | Point to docs, don't inline them |
| No linting instructions | Use hooks/formatters, not LLM instructions |
| WHY-WHAT-HOW | Cover purpose, stack/structure, and workflow |
| Pointers over copies | Use `file:line` refs, not code snippets |
| Hand-crafted | Never auto-generate; every line is high-leverage |

## Common Anti-Patterns to Flag

1. **Code style rules inline** - Move to linter config + hook
2. **Database schema instructions** - Move to `agent_docs/database_schema.md`
3. **Exhaustive command lists** - Keep only the 2-3 most common; point to docs for rest
4. **Copy-pasted code examples** - Replace with `file:line` references
5. **Task-specific workflows** - Move to separate docs or slash commands
6. **Redundant instructions** - Remove anything the agent can infer from codebase
7. **Auto-generated content** - Flag `/init` output for manual curation

## Progressive Disclosure Template

When extracting content, suggest this structure:

```
agent_docs/
  |- building_the_project.md
  |- running_tests.md
  |- code_conventions.md
  |- service_architecture.md
```

Then in `CLAUDE.md`, add a section like:

```markdown
## Additional Context

Read the relevant file(s) before starting work:

| File | When to Read |
|------|-------------|
| agent_docs/building_the_project.md | Building, compiling, or packaging |
| agent_docs/running_tests.md | Writing or running tests |
| agent_docs/code_conventions.md | Writing new code (not for quick fixes) |
| agent_docs/service_architecture.md | Cross-service changes |
```

## Reference Documentation

| Topic | File |
|-------|------|
| Best practices & rationale | [references/best-practices.md](references/best-practices.md) |
| Review checklist | [references/review-checklist.md](references/review-checklist.md) |
