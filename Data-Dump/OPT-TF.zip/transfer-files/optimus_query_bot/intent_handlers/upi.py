from openai import AsyncOpenAI
from httpx import AsyncClient
from dotenv import load_dotenv

# from app.clients.llm_gw import get_llm_gw_client
from app.services.optimus_query_bot.llm_usage import log_usage
from typing import Optional, Dict, Any
import json
import time

# gptcall=LLMGatewayClient()
import logging
logger = logging.getLogger(__name__)

load_dotenv()
openai_client = AsyncOpenAI(http_client=AsyncClient(verify=False))

async def gptcall(messages,FD_OUTPUT_SCHEMA):
    response = await openai_client.chat.completions.create(
        model="gpt-5.2",
        messages=messages,
        max_completion_tokens=1024,
        temperature=0.0,
        top_p=0.9,
        response_format=FD_OUTPUT_SCHEMA
    )
    
    response_dict = response.model_dump()
    return response_dict

# client = get_llm_gw_client()

# async def gptcall(messages,FD_OUTPUT_SCHEMA): 
#     payload = {
#         "model": "gpt-5.4",
#         "max_completion_tokens": 1024,
#         "temperature": 0.0,
#         "top_p": 0.9,
#         "messages": messages,
#         "response_format": FD_OUTPUT_SCHEMA
#     }


#     response = await client.invoke_model(payload)
#     log_usage(response, "optimus_query_bot.upi.gptcall")
#     return response

# ========================== Helper Function =======================
async def intent_identification(user_query: str, state: dict) -> dict:
    """
    Classifies user intent into one of:
      change_payee | change_amount | change_both | abort | other | none
    """
    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "intent_identification",
            "schema": {
                "type": "object",
                "properties": {
                    "intent": {
                        "type": "string",
                        "enum": [
                            "change_payee",
                            "change_amount",
                            "change_both",
                            "abort",
                            "other",
                            "none",
                        ],
                        "description": "Classify the user query into exactly one intent.",
                    }
                },
                "required": ["intent"],
                "additionalProperties": False,
            },
        },
    }

    messages = [
        {
            "role": "system",
            "content": """
## 🎯 ROLE
You are an **Intent Classification Engine** for a Bank UPI Payment Agent.

Your sole responsibility is to accurately identify the user's current intent based on:
- The **existing journey state** (information already captured)
- The **latest user query**

You must NOT perform calculations, provide advice, or generate conversational responses.

---

## 📥 INPUTS
1. **Existing State** — structured object with current UPI payment info
2. **User Query** — the most recent user message

---

## 📤 OUTPUT
Return EXACTLY one intent from: ['change_payee', 'change_amount', 'change_both', 'abort', 'other', 'none']

---

## 🧭 INTENT DEFINITIONS

### `change_payee`
- User wants to change, replace, or re-enter the payee name only
- Mentions a different payee name than what is in state
- **Contact not found in the list** — user says things like:
  "I don't see the contact", "name is not there", "not in the list",
  "can't find the person", "contact is missing", "I tried but still not there"
- User is retrying after a failed contact search, even without naming a new payee

### `change_amount`
- User wants to change, correct, or update the payment amount only
- Mentions a different amount than what is in state
- Asks if they can send more/less

### `change_both`
- User wants to change BOTH the payee name AND the amount together

### `abort`
- User clearly and explicitly wants to cancel, stop, or exit the UPI payment journey
- Examples: "Cancel", "Stop", "I don't want to continue", "Exit"

### `other`
- Query is about a completely different banking service unrelated to UPI payment
- Unrelated small-talk or clearly out-of-scope requests

### `none`
- Query is related to UPI payment but doesn't map to change/abort
- User is answering a prompt, providing missing info, or asking a general UPI question
- When in doubt, prefer `none`

---

## 🚨 CRITICAL RULES
- Return ONLY one allowed intent value
- Do NOT explain reasoning
- Do NOT infer beyond what is explicitly stated
- Prioritize precision — prefer `none` over guessing
            """,
        },
        {
            "role": "user",
            "content": f"user_query: {user_query}\nstate: {state}",
        },
    ]

    raw_response = await gptcall(messages, out_schema)
    final_output = raw_response["choices"][0]["message"]["content"]
    return json.loads(final_output)


async def extract_amount(user_query: str, existing_amount: Optional[float], expected_slot: str) -> dict:
    """
    Extracts payment amount from the user query.
    Returns: { bot_response, amount_to_be_paid }
    """
    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "extract_amount",
            "description": "Extract payment amount from user message",
            "schema": {
                "type": "object",
                "properties": {
                    "bot_response": {
                        "type": "string",
                        "description": "Customer-facing message. Ask for amount if missing; else short acknowledgement.",
                    },
                    "amount_to_be_paid": {
                        "type": ["number", "null"],
                        "description": "Numeric payment amount. Null if not provided or unclear.",
                    },
                },
                "required": ["bot_response", "amount_to_be_paid"],
                "additionalProperties": False,
            },
        },
    }

    messages = [
        {
            "role": "system",
            "content": f"""
## 🎯 Role
You are a **Banking AI Amount Extraction Agent** in a UPI payment flow.

## Context
- expected_slot: {expected_slot}
- existing_amount_to_be_paid: {existing_amount}

## Rules
1. If `existing_amount` is present and the user is NOT correcting it, preserve it.
2. Extract amount from user query ONLY if it is missing or user explicitly corrects it.
3. Do NOT infer, guess, or assume amounts.
4. Do NOT validate the amount (validation happens separately).
5. If amount is missing, ask for it concisely.
6. If amount is present, respond with a short neutral acknowledgement.
7. Always return output strictly in the JSON schema provided.
            """,
        },
        {
            "role": "user",
            "content": (
                f"user_query: {user_query}\n"
                f"existing_amount_to_be_paid: {existing_amount}"
            ),
        },
    ]

    raw_response = await gptcall(messages, out_schema)
    final_output = raw_response["choices"][0]["message"]["content"]
    return json.loads(final_output)


async def extract_payee_name(
    user_query: str,
    existing_payee_name: Optional[str],
    expected_slot: str,
    payee_not_found_count: int = 0,
) -> dict:
    """
    Extracts payee name from the user query.
    Uses payee_not_found_count to tailor guidance when user repeatedly can't find contact.
    Returns: { bot_response, payee_name }
    """
    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "extract_payee_name",
            "description": "Extract payee name from user message",
            "schema": {
                "type": "object",
                "properties": {
                    "bot_response": {
                        "type": "string",
                        "description": (
                            "Customer-facing message. Ask for payee name if missing. "
                            "If provided, instruct user to select from the contact list shown."
                        ),
                    },
                    "payee_name": {
                        "type": ["string", "null"],
                        "description": (
                            "Payee name as mentioned by user, transliterated to English if in any other script. "
                            "Null if not provided or unclear."
                        ),
                    },
                },
                "required": ["bot_response", "payee_name"],
                "additionalProperties": False,
            },
        },
    }

    messages = [
        {
            "role": "system",
            "content": f"""
## 🎯 Role
You are a **Banking AI Payee Name Extraction Agent** in a UPI payment flow.

## Context
- expected_slot: {expected_slot}
- existing_payee_name: {existing_payee_name}
- payee_not_found_count: {payee_not_found_count}
  (How many times the user has reported not finding their contact in the list.
   0 = first attempt, 1 = one failed search, 2+ = repeated failures)

## Slot Awareness Rule ⚠️
> **Check this before all extraction rules.**

- If `expected_slot` is **`amount`** and the user's message is **purely numeric** (e.g. `500`, `1000`, `₹250`):
  The amount has been captured but this node has received it in error. Set `payee_name` as `null` and `bot_response` to transition the user toward providing a name.
  > Example: *"Great! Could you share the name of the person you'd like to pay?"*

- If `expected_slot` is **`payee_name`** and the user's message is **purely numeric** (e.g. `500`, `1000`, `₹250`):
  The user likely carried over their amount response from the previous turn. Do **not** treat this as a payee name. Set `payee_name` as `null` and `bot_response` to re-prompt for the name.
  > Example: *"That looks like an amount — could you share the name of the person you'd like to pay?"*

## Extraction Rules
1. **Always extract whatever name the user provides** — even if it looks short, abbreviated, or informal (e.g. "raj", "mom", "uncle"). Never withhold or reject a name.
2. If `existing_payee_name` is present and the user message contains NO new name:
   - If the user wants to **retry the same search** (e.g. "try again", "search again", "couldn't find, try once more", "I don't see the name, search again") — return `existing_payee_name` as-is to re-initiate the search.
   - If the user explicitly wants to **use a different name** (e.g. "I'll try a different name", "let me search someone else", "forget it, pay someone else") — return `payee_name` as null.
   - If the intent is **ambiguous** (e.g. "I don't see the contact") — default to returning `existing_payee_name` as-is to retry rather than clearing it.
3. If the user provides a new name (different from existing), extract the new name.
4. If the name is in Devanagari/Hindi or any non-English script, transliterate to English letters.
5. Do NOT infer or guess names that aren't present in the user message.

## bot_response Rules — use payee_not_found_count to shape guidance tone only:

### If payee_not_found_count == 0 (first attempt — no prior failure):
- Confirm you're searching for the extracted name. Keep it brief and positive.
- No warnings needed. Example: "Got it! Searching for [name] in your contacts. Please select the correct one from the list."

### If payee_not_found_count == 1 (one prior failed search — gentle nudge):
- Acknowledge the contact wasn't found last time.
- Gently remind them the name must match how it is saved in their mobile contacts.
- Still proceed with the name just given. Example: "Searching for [name] again. If it doesn't appear, check that the spelling matches exactly as saved in your contacts."

### If payee_not_found_count >= 2 (repeated failures — graceful deferral):
- Acknowledge the continued difficulty.
- Suggest the contact may not be UPI-registered yet, or there may be a temporary sync issue.
- Still attempt with the provided name but set expectations.
- Ask if they'd like to try a different name or cancel. Example: "Trying [name] once more. If they still don't appear, they may not be registered on UPI right now — you can try after some time or pay a different contact."

## Always:
- Return output strictly in the JSON schema provided.
- Keep the tone professional, empathetic, and concise.
            """,
        },
        {
            "role": "user",
            "content": (
                f"user_query: {user_query}\n"
                f"existing_payee_name: {existing_payee_name}"
            ),
        },
    ]

    raw_response = await gptcall(messages, out_schema)
    final_output = raw_response["choices"][0]["message"]["content"]
    return json.loads(final_output)


def validate_upi_amount(amount: float, current_balance: float) -> dict:
    """
    Validates the UPI payment amount against business rules.
    Rules:
      - Must be a positive number
      - Must not exceed current balance
    """
    if amount is None or not isinstance(amount, (int, float)):
        return {
            "amount_to_be_paid": None,
            "bot_response": "Please enter a valid numeric amount to proceed.",
        }

    if amount <= 0:
        return {
            "amount_to_be_paid": None,
            "bot_response": "The payment amount must be greater than zero. Please enter a valid amount.",
        }

    if amount > current_balance:
        return {
            "amount_to_be_paid": None,
            "bot_response": (
                f"Insufficient funds. Your current balance is ₹{current_balance:,.2f}. "
                "Please enter an amount within your available balance."
            ),
        }

    return {
        "amount_to_be_paid": amount,
        "bot_response": "Amount noted.",
    }


def build_final_confirmation(
    payee_name: str,
    registered_payee_details: Dict[str, Any],
    amount_to_be_paid: float,
) -> dict:
    """
    Builds the hardcoded final payment confirmation summary.
    No LLM involved.
    """
    upi_id = (
        registered_payee_details.get("upi_id", "N/A")
        if isinstance(registered_payee_details, dict)
        else str(registered_payee_details)
    )
    bank_name = (
        registered_payee_details.get("bank_name", "")
        if isinstance(registered_payee_details, dict)
        else ""
    )
    mobile = (
        registered_payee_details.get("mobile", "")
        if isinstance(registered_payee_details, dict)
        else ""
    )

    lines = [
        "### 💸 UPI Payment Confirmation\n",
        f"- **Payee Name:** {payee_name}",
    ]
    if mobile:
        lines.append(f"- **Mobile:** {mobile}")
    lines.append(f"- **UPI ID:** {upi_id}")
    if bank_name:
        lines.append(f"- **Bank:** {bank_name}")
    lines.append(f"- **Amount:** ₹{amount_to_be_paid:,.2f}")
    lines.append(
        "\n  Please review the above details carefully and **confirm** to proceed with the payment."
    )

    return {
        "request_to_proceed": "yes",
        "bot_response": "\n".join(lines),
    }


# ========================== State Initialization ==========================


import time
from typing import Dict, Any


def initialize_state() -> Dict[str, Any]:
    return {
        "journey": "UPI_PAYMENT",
        "bot_response": "",
        "expected_slot": None,          # tracks which slot the bot is currently collecting
        "payee_name": None,
        "amount_to_be_paid": None,
        "registered_payee_details": None,
        "account_details": None,
        "show_contact_list": "no",
        "fetch_account_details": "no",
        "request_to_proceed": "no",
        "abort": "no",
        "widget_response": "no",
        "off_topic_count": 0,
        "payee_not_found_count": 0,     # how many times user couldn't find payee in contact list
    }

# ==================== main UPI handler ====================================







class UPIHandler:
    def __init__(self):
        self.state = initialize_state()

    # ------------------------------------------------------------------
    # Internal state sync from external data (widget / journey updates)
    # ------------------------------------------------------------------
    def _update_state_from_request(self, additional_data: dict, journey_state: dict):
        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

        if "registered_payee_details" in additional_data:
            self.state["registered_payee_details"] = additional_data.get("registered_payee_details")

        if "account_details" in additional_data:
            self.state["account_details"] = additional_data.get("account_details")

        if "widget_response" in additional_data:
            self.state["widget_response"] = additional_data.get("widget_response").lower().strip()

    # ------------------------------------------------------------------
    # Core orchestrator
    # ------------------------------------------------------------------
    async def upi_orchestrator(self, user_query: str, state: dict, journey_data: dict) -> dict:
        start_time = time.time()

        # Reset per-turn UI trigger flags
        state["show_contact_list"] = "no"
        state["request_to_proceed"] = "no"
        state["fetch_account_details"] = "no"

        current_balance = journey_data.get("primary_balance", 20000)

        # ==============================================================
        # STEP 1 — Intent Classification
        # Skip when the turn is a widget response (UI selection event)
        # ==============================================================
        if state["widget_response"] == "no":
            intent_result = await intent_identification(user_query, state)
            intent = intent_result.get("intent", "none")
        else:
            # Widget response carries structured data, not free text
            intent = "none"

        print(f"[UPI] intent={intent}")

        # --------------------------------------------------------------
        # Abort
        # --------------------------------------------------------------
        if intent == "abort":
            state.update(
                {
                    "abort": "yes",
                    "expected_slot": None,
                    "bot_response": (
                        "Your UPI payment journey has been cancelled. "
                        "Feel free to start a new transaction whenever you're ready."
                    ),
                }
            )
            return state

        # --------------------------------------------------------------
        # Off-topic / other domain
        # --------------------------------------------------------------
        if intent == "other":
            state["off_topic_count"] += 1
            if state["off_topic_count"] > 1:
                state.update(
                    {
                        "abort": "yes",
                        "expected_slot": None,
                        "bot_response": (
                            "It seems you have a different query. "
                            "Your UPI payment journey has been terminated. "
                            "Please reach out to us again for assistance."
                        ),
                    }
                )
                return state

            state["bot_response"] = (
                "I can only assist with your current UPI payment. "
                "Would you like to continue or cancel this transaction?"
            )
            return state

        # Reset off-topic counter on any relevant interaction
        state["off_topic_count"] = 0

        # ==============================================================
        # STEP 2 — Amount Node
        # Trigger: amount is missing OR user wants to change amount/both
        # ==============================================================
        needs_amount = (
            state["amount_to_be_paid"] is None
            or intent in ("change_amount", "change_both")
        )

        if needs_amount:
            state["expected_slot"] = "amount"
            print("[UPI] Entering amount extraction node")

            extraction = await extract_amount(
                user_query=user_query,
                existing_amount=state["amount_to_be_paid"],
                expected_slot=state["expected_slot"],
            )

            extracted_amount = extraction.get("amount_to_be_paid")
            state["bot_response"] = extraction["bot_response"]

            if extracted_amount is None:
                # Still waiting for the user to provide amount
                return state

            # Validate the extracted amount
            validation = validate_upi_amount(
                amount=extracted_amount,
                current_balance=current_balance,
            )

            if validation["amount_to_be_paid"] is None:
                # Validation failed — keep expected_slot on amount
                state["bot_response"] = validation["bot_response"]
                return state

            # Amount accepted — persist and clear slot
            state["amount_to_be_paid"] = validation["amount_to_be_paid"]

            # If intent was change_amount only, do NOT invalidate payee state
            # If intent was change_both, fall through to payee node below
            if intent == "change_amount":
                state["expected_slot"] = None
                # Re-enter next relevant node (payee or confirmation)
                # Fall through naturally — payee node will decide

        # ==============================================================
        # STEP 3 — Payee Name Node
        # Trigger: registered_payee_details is None OR intent touches payee
        # ==============================================================
        needs_payee = (
            state["registered_payee_details"] is None
            or intent in ("change_payee", "change_both")
        )

        if needs_payee:
            # -----------------------------------------------------------------
            # Sub-case A: Widget response received (user selected from dropdown)
            # -----------------------------------------------------------------
            if state["widget_response"] == "yes":
                if state["registered_payee_details"]:
                    # Successful selection — reset failure counter and advance
                    state["expected_slot"] = None
                    state["payee_not_found_count"] = 0
                    state["widget_response"] = "no"
                    # Fall through to account / confirmation nodes below
                else:
                    # Widget fired but no UPI ID returned for selected contact
                    state.update(
                        {
                            "expected_slot": "payee_name",
                            "widget_response": "no",
                            "show_contact_list": "yes",
                            "bot_response": (
                                "We couldn't find a UPI ID linked to the selected contact. "
                                "Please try selecting a different contact, or verify that "
                                "this person has a registered UPI ID on their number."
                            ),
                        }
                    )

                    return state

            else:
                # -----------------------------------------------------------------
                # Sub-case B: Free-text — user reported contact not found OR is
                #             providing a new/corrected payee name
                # -----------------------------------------------------------------

                print("[UPI] Entering payee name extraction node")

                # When intent is change_payee/change_both:
                #   - Clear existing name and registered details (stale)
                #   - Increment the not-found counter ONLY when the user already
                #     had a name (i.e., they searched and didn't find it)
                if intent in ("change_payee", "change_both"):
                    state["expected_slot"] = "payee_name"
                    if state["payee_name"]:          # had a name → failed search
                        state["payee_not_found_count"] += 1
                    # state["payee_name"] = None
                    state["registered_payee_details"] = None

                extraction = await extract_payee_name(
                    user_query=user_query,
                    existing_payee_name=state["payee_name"],
                    expected_slot=state["expected_slot"],
                    payee_not_found_count=state["payee_not_found_count"],
                )

                extracted_name = extraction.get("payee_name")
                state["bot_response"] = extraction["bot_response"]

                if not extracted_name:
                    # LLM couldn't extract a name — guidance message already set
                    return state

                # New name provided — always invalidate previously selected UPI details
                state["registered_payee_details"] = None
                state["payee_name"] = extracted_name

                # Show the contact list for the user to pick the matching contact
                state.update(
                    {
                        "show_contact_list": "yes",
                        # "bot_response": (
                        #     f"Searching for **{extracted_name}** in your contacts. "
                        #     "Please select the correct contact from the list below.\n\n"
                        #     "💡 Make sure the name matches exactly as saved in your mobile "
                        #     "contacts — even a small spelling difference in name  "
                        #     "may prevent the contact from appearing."
                        # ),
                    }
                )
                return state

        # ==============================================================
        # STEP 4 — Account Selection Node
        # ==============================================================
        # if not state["account_details"]:
        #     state.update(
        #         {
        #             "expected_slot": "account",
        #             "fetch_account_details": "yes",
        #             "bot_response": "Please select the account you'd like to pay from.",
        #         }
        #     )
        #     return state

        # ==============================================================
        # STEP 5 — Final Confirmation (hardcoded, no LLM)
        # ==============================================================
        state["expected_slot"] = None
        confirmation = build_final_confirmation(
            payee_name=state["payee_name"],
            registered_payee_details=state["registered_payee_details"],
            amount_to_be_paid=state["amount_to_be_paid"],
        )

        state.update(
            {
                "request_to_proceed": confirmation["request_to_proceed"],
                "bot_response": confirmation["bot_response"],
            }
        )

        print(f"[UPI] Orchestrator completed in {time.time() - start_time:.2f}s")
        return state

    # ------------------------------------------------------------------
    # Public handle method
    # ------------------------------------------------------------------
    async def handle(self, user_query: str, journey_data: dict, journey_state: dict = None) -> dict:
        """
        Main entry point per user turn.

        Parameters
        ----------
        user_query      : latest message from the user
        journey_data    : session-level data (e.g. primary_balance)
        additional_data : widget / API response data injected by the platform
                          (registered_payee_details, account_details, widget_response flag)
        """

        state = self.state.copy()
        self.state = await self.upi_orchestrator(user_query, state, journey_data)

        # Always reset widget flag after processing
        self.state["widget_response"] = "no"

        return self.state


    def get_intent_data(self):

        journey_id="PAY_TO_MOBILE"
        if self.state.get("request_to_proceed").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.RAISE_FINAL_CONFIRMATION",
                "additional_data": {
                    "amount_to_be_paid": self.state['amount_to_be_paid']
                }
            }

        if self.state.get("fetch_account_details").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SHOW_ACCOUNTS"
            }

        if self.state.get("show_contact_list").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SHOW_CONTACT_LIST",
                "additional_data": {
                    "payee_name": self.state['payee_name']
                }
            }

        if self.state.get("abort").lower().strip() == "yes":
            return {
                "intent_type": "",
                "intent": ""
            }
        return {
            "intent_type": "Clarification",
            "intent": journey_id
        }
