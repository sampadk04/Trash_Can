from typing import Any

from langgraph.graph import END, START, StateGraph

from app.services.optimus_query_bot.intent_handlers_lg.pay_credit_card_bill.models import (
    CreditCardGraphState,
    CreditCardHelpOutput,
)
from app.services.optimus_query_bot.intent_handlers_lg.pay_credit_card_bill.prompts import (
    CREDIT_CARD_HELP_SYSTEM_PROMPT,
)
from app.services.optimus_query_bot.intent_handlers_lg.shared.llm import ainvoke_structured


def initialize_cc_payment_state() -> dict[str, Any]:
    return {
        "journey": "CC_PAYMENT",
        "bot_response": "",
        "fetch_card_details": "no",
        "card_details": None,
        "fetch_payment_amount": "no",
        "payment_amount": None,
        "fetch_account_details": "no",
        "account_details": None,
        "raise_final_confirmation": "no",
        "abort": "no",
        "off_topic_count": 0,
        "show_redirection": "no",
        "count": 0,
        "widget_response": "no",
    }


async def get_help(user_query: str) -> dict[str, Any]:
    response = await ainvoke_structured(
        [
            ("system", CREDIT_CARD_HELP_SYSTEM_PROMPT),
            ("human", user_query),
        ],
        CreditCardHelpOutput,
    )
    return response.model_dump()


async def credit_card_orchestrator(state: CreditCardGraphState) -> dict[str, Any]:
    data = state.model_dump()

    data["fetch_card_details"] = "no"
    data["fetch_payment_amount"] = "no"
    data["fetch_account_details"] = "no"
    data["raise_final_confirmation"] = "no"
    data["count"] += 1

    if data["count"] == 1 or data["widget_response"] == "yes":
        data["widget_response"] = "no"

        if not data["card_details"]:
            data["fetch_card_details"] = "yes"
            data["bot_response"] = "Please select the credit card you want to pay for."
            return data

        if not data["payment_amount"]:
            data["fetch_payment_amount"] = "yes"
            data["bot_response"] = "Please select the payment amount."
            return data

        if not data["account_details"]:
            data["fetch_account_details"] = "yes"
            data["bot_response"] = "Please select the bank account for payment."
            return data

        data["raise_final_confirmation"] = "yes"
        data["bot_response"] = (
            f"Please review and confirm your credit card bill payment:\n"
            f"- Credit Card: {data['card_details']}\n"
            f"- Payment Amount: {data['payment_amount']}\n"
            f"- Bank Account: {data['account_details']}"
        )
        return data

    response = await get_help(data["user_query"])
    intent = response["intent"]

    if intent == "widget_issue":
        data["bot_response"] = response["bot_response"]
        data["show_redirection"] = "yes"
        return data

    if intent == "abort":
        data["abort"] = "yes"
        data["bot_response"] = "Credit card bill payment journey has been terminated."
        return data

    if intent == "other":
        data["off_topic_count"] += 1
        if data["off_topic_count"] >= 2:
            data["abort"] = "yes"
            data["bot_response"] = (
                "We are unable to proceed due to unrelated inputs. "
                "Please start the credit card bill payment again."
            )
            return data

        data["bot_response"] = response["bot_response"]
        return data

    return data


def build_graph():
    builder = StateGraph(CreditCardGraphState)
    builder.add_node("orchestrate_credit_card_payment", credit_card_orchestrator)
    builder.add_edge(START, "orchestrate_credit_card_payment")
    builder.add_edge("orchestrate_credit_card_payment", END)
    return builder.compile()
