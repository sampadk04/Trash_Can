from typing import Any

from langgraph.graph import END, START, StateGraph

from app.services.optimus_query_bot.intent_handlers_lg.loan_noc.models import (
    LoanNocConfirmationOutput,
    LoanNocGraphState,
)
from app.services.optimus_query_bot.intent_handlers_lg.loan_noc.prompts import (
    LOAN_NOC_CONFIRMATION_SYSTEM_PROMPT,
)
from app.services.optimus_query_bot.intent_handlers_lg.shared.llm import ainvoke_structured


def initialize_noc_state() -> dict[str, Any]:
    return {
        "journey": "LOAN_NOC",
        "bot_response": "",
        "noc_loan": None,
        "noc_address": None,
        "status": None,
        "service_request_no": None,
        "fetch_loan_list": "no",
        "show_address": "no",
        "raise_noc_request": "no",
        "abort": "no",
    }


async def check_confirmation(user_query: str) -> dict[str, Any]:
    response = await ainvoke_structured(
        [
            ("system", LOAN_NOC_CONFIRMATION_SYSTEM_PROMPT),
            ("human", f"user_query: {user_query}"),
        ],
        LoanNocConfirmationOutput,
    )
    return response.model_dump()


async def loan_noc_orchestrator(state: LoanNocGraphState) -> dict[str, Any]:
    data = state.model_dump()

    data["fetch_loan_list"] = "no"
    data["show_address"] = "no"
    data["raise_noc_request"] = "no"
    data["show_redirection"] = "no"
    data["bot_response"] = ""

    if not data.get("noc_loan"):
        data["bot_response"] = "Please select the loan for which you want to raise the NOC request."
        data["fetch_loan_list"] = "yes"
        return data

    if not data.get("noc_address"):
        data["bot_response"] = (
            f"Please confirm the address shown below. "
            f"The NOC for loan {data['noc_loan']} will be sent to this address."
        )
        data["show_address"] = "yes"
        return data

    if data.get("noc_address") and not data.get("status"):
        confirmation_response = await check_confirmation(data["user_query"])

        if confirmation_response.get("confirmation") == "yes":
            data["raise_noc_request"] = "yes"
            return data

        if confirmation_response.get("confirmation") == "no":
            data["bot_response"] = (
                "Sorry we could not proceed without address confirmation, if you want to update the address please follow below redirection else try again"
            )
            data["show_redirection"] = "yes"
            return data

    if data.get("status") == "success":
        data["bot_response"] = (
            f"Your NOC request has been placed successfully with request number "
            f"{data.get('service_request_no')}. "
            f"It will be delivered to the confirmed address within 2 weeks."
        )
        return data

    if data.get("status") == "failure":
        data["bot_response"] = "We could not process your NOC request at the moment. Please try again later."
        return data

    return data


def build_graph():
    builder = StateGraph(LoanNocGraphState)
    builder.add_node("orchestrate_loan_noc", loan_noc_orchestrator)
    builder.add_edge(START, "orchestrate_loan_noc")
    builder.add_edge("orchestrate_loan_noc", END)
    return builder.compile()
