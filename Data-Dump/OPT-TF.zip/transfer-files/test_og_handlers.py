# TEST THE INTENT HANDLERS IN CLI CHAT
"uv run test_og_handlers.py"
# %%
# IMPORTS
import asyncio
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel

from app.services.optimus_query_bot.intent_handlers.credit_card import CreditCardHandler
from app.services.optimus_query_bot.intent_handlers.upi import UPIHandler
from app.services.optimus_query_bot.intent_handlers.loan_noc import LoanNocHandler
from app.services.optimus_query_bot.intent_handlers.email_update import EmailChangeHandler
from app.services.optimus_query_bot.intent_handlers.fixed_deposit import FixedDepositHandler

# %%
# TEST CONFIGs
# ==============================================================================
HANDLER_CLASS = FixedDepositHandler
# UPIHandler | CreditCardHandler | LoanNocHandler | EmailChangeHandler | FixedDepositHandler
SCENARIO_FILE = "fixed_deposit.json"
# upi.json | credit_card.json | loan_noc.json | email_update.json | fixed_deposit.json
SCENARIO_NAME = "tenure_entered_matched"
# Scenario name defined inside the JSON file
# ==============================================================================

DATA_DIR = Path(__file__).parent / "data/handlers-testing"
console = Console()

# %%
# CLI CHAT WRAPPERS
async def run_chat(
    handler_class: Any,
    scenario: dict[str, Any]
) -> None:
    # Extract data from the scenario configuration
    journey_data = deepcopy(scenario.get("journey_data", {}))
    journey_state = deepcopy(scenario.get("journey_state", {}))
    pending_additional_data = deepcopy(scenario.get("additional_data", {}))

    console.print(Panel(
        f"[bold cyan]Scenario:[/bold cyan] {scenario.get('name')}\n"
        f"[dim]{scenario.get('description')}[/dim]\n\n"
        f"[bold green]Initial Journey State:[/bold green] {journey_state}\n"
        f"[bold green]Initial Journey Data:[/bold green] {journey_data}",
        title=f"[bold]Session Started: {handler_class.__name__}[/bold]",
        border_style="green"
    ))

    first_turn = True

    while True:
        # 1. Determine if we are auto-applying widget payload/additional_data on first turn
        if first_turn and pending_additional_data:
            console.print(f"[yellow]Automatically applying scenario additional_data on first turn:[/yellow]\n{pending_additional_data}")
            user_query = ""
            current_add_data = pending_additional_data
            first_turn = False
        else:
            # 2. Get user message
            try:
                user_query = console.input("\n[bold green]user>[/bold green] ").strip()
            except (EOFError, KeyboardInterrupt):
                return

            if not user_query:
                continue

            if user_query in {"/quit", "/exit"}:
                return

            if user_query == "/state":
                console.print(Panel(
                    json.dumps(journey_state, indent=2),
                    title="[bold blue]Current Journey State[/bold blue]",
                    border_style="blue"
                ))
                continue

            current_add_data = {}
            first_turn = False

        # 3. Instantiate handler and invoke using standard RuleEngine sequence
        handler_instance = handler_class()
        handler_instance._update_state_from_request(current_add_data, journey_state)
        
        try:
            result = await handler_instance.handle(
                user_query=user_query,
                journey_data=journey_data,
                journey_state=journey_state,
            )
            intent_data = handler_instance.get_intent_data()
        except Exception as e:
            console.print(f"[bold red]Error executing handler:[/bold red] {e}", style="red")
            return

        # 4. Display results
        console.print(Panel(
            result.get("bot_response", ""),
            title="[bold yellow]Bot Response[/bold yellow]",
            border_style="yellow"
        ))

        # Show returned intent details
        console.print(f"[bold blue]Returned Intent:[/bold blue] {intent_data.get('intent')} "
                      f"(Type: {intent_data.get('intent_type')})")
        if intent_data.get("additional_data"):
            console.print(f"[dim blue]Intent Additional Data: {intent_data.get('additional_data')}[/dim blue]")

        # 5. Save updated state (excluding bot_response, exactly like production RuleEngine)
        journey_state = {k: v for k, v in result.items() if k != "bot_response"}
        
        # Check for abort/termination
        abort_val = journey_state.get("abort")
        if abort_val and str(abort_val).lower().strip() == "yes":
            console.print("\n[bold red]Journey Aborted / Completed.[/bold red]")
            return


async def main():
    console.print("[bold cyan]Intent Handler CLI Tester[/bold cyan]\n")
    
    # Load scenarios from JSON file
    json_path = DATA_DIR / SCENARIO_FILE
    if not json_path.exists():
        console.print(f"[red]Scenarios file not found at: {json_path}[/red]")
        exit(1)

    try:
        data = json.loads(json_path.read_text())
        scenarios = data.get("scenarios", [])
    except Exception as e:
        console.print(f"[red]Error parsing scenarios file {json_path}: {e}[/red]")
        exit(1)

    # Find the configured scenario
    selected_scenario = None
    for sc in scenarios:
        if sc.get("name") == SCENARIO_NAME:
            selected_scenario = sc
            break

    if not selected_scenario:
        if scenarios:
            selected_scenario = scenarios[0]
            console.print(f"[yellow]Scenario '{SCENARIO_NAME}' not found.")
            exit(1)
        else:
            console.print(f"[red]No scenarios found in {json_path.name}.[/red]")
            exit(1)

    console.print(f"[green]Starting session with handler {HANDLER_CLASS.__name__} using scenario: {selected_scenario.get('name')}[/green]")
    console.print("[dim]Commands in session: /state to view state, /quit to exit session[/dim]\n")

    await run_chat(
            handler_class=HANDLER_CLASS,
            scenario=selected_scenario
        )
    console.print("\n[dim]Session ended.[/dim]")

# %%
# UNCOMMENT TO RUN IN SCRIPT MODE
if __name__ == "__main__":
    asyncio.run(main())

# %%
# UNCOMMENT TO RUN IN NOTEBOOK MODE
# await main()
# %%
