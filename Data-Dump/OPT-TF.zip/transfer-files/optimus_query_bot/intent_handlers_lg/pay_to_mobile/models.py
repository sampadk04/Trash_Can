from typing import Any, Literal

from pydantic import BaseModel, Field


class UpiGraphState(BaseModel):
    journey: str = Field(default="UPI_PAYMENT", description="Current UPI payment journey identifier.")
    bot_response: str = Field(default="", description="Customer-facing response for the current turn.")
    expected_slot: Any = Field(default=None, description="Slot currently being collected from the user.")
    payee_name: Any = Field(default=None, description="Payee name extracted from user text.")
    amount_to_be_paid: Any = Field(default=None, description="Validated UPI payment amount.")
    registered_payee_details: Any = Field(default=None, description="UPI details selected from contact widget.")
    account_details: Any = Field(default=None, description="Selected debit account details.")
    show_contact_list: str = Field(default="no", description="Whether UI should show contact list.")
    fetch_account_details: str = Field(default="no", description="Whether UI should show account selector.")
    request_to_proceed: str = Field(default="no", description="Whether UI should raise final confirmation.")
    abort: str = Field(default="no", description="Whether this journey is aborted.")
    widget_response: str = Field(default="no", description="Whether current turn came from widget response.")
    off_topic_count: int = Field(default=0, description="Count of unrelated free-text turns.")
    payee_not_found_count: int = Field(default=0, description="Number of failed contact searches reported.")
    user_query: str = Field(default="", description="Latest user message.")
    primary_balance: float = Field(default=20000, description="Available primary account balance.")


class UpiIntentOutput(BaseModel):
    intent: Literal["change_payee", "change_amount", "change_both", "abort", "other", "none"] = Field(
        description="Classify the user query into exactly one UPI journey intent."
    )


class UpiAmountOutput(BaseModel):
    bot_response: str = Field(description="Customer-facing message for amount collection.")
    amount_to_be_paid: float | None = Field(description="Numeric payment amount, or null if missing or unclear.")


class UpiPayeeOutput(BaseModel):
    bot_response: str = Field(description="Customer-facing message for payee-name collection.")
    payee_name: str | None = Field(description="Payee name from user message, transliterated to English if needed.")
