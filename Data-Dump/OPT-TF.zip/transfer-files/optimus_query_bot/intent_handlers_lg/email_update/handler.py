from typing import Any

from app.services.optimus_query_bot.intent_handlers_lg.email_update.graph import (
    build_graph,
    initialize_state,
)
from app.services.optimus_query_bot.intent_handlers_lg.shared.state import yes


class EmailChangeGraphHandler:
    def __init__(self):
        self.state = initialize_state()
        self.graph = build_graph()

    def _update_state_from_request(self, additional_data: dict, journey_state: dict):
        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

        if "is_eligible" in additional_data:
            self.state["is_eligible"] = additional_data.get("is_eligible").lower().strip()
            self.state["eligibility_checked"] = "yes"
        if "current_email" in additional_data:
            self.state["current_email"] = additional_data.get("current_email")
        if "new_email" in additional_data:
            self.state["new_email"] = additional_data.get("new_email")
        if "status" in additional_data:
            self.state["status"] = additional_data.get("status")
        if "service_request_no" in additional_data:
            self.state["service_request_no"] = additional_data.get("service_request_no")

    async def handle(self, user_query: str, journey_data: dict[str, Any], journey_state: dict[str, Any]):
        result = await self.graph.ainvoke({**self.state, "user_query": user_query})
        result.pop("user_query", None)
        self.state = result
        return self.state

    def get_intent_data(self):
        journey_id = "EMAIL_UPDATE"
        if str(self.state.get("status") or "").lower().strip() == "success":
            return {"intent_type": "Execution", "intent": f"{journey_id}.SHOW_FINAL_STATUS"}
        if yes(self.state.get("email_mfa")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.MFA_EMAIL"}
        if yes(self.state.get("get_new_email")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.VALIDATE_EMAIL"}
        if yes(self.state.get("change_email_eligibility")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.CHANGE_EMAIL_ELIGIBILITY"}
        return {"intent_type": "Clarification", "intent": journey_id}
