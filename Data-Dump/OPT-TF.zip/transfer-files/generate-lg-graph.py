# CODE TO GENERATE LANGGRAPH HANDLER DIAGRAMS
# %%
# IMPORTS
from pathlib import Path
from app.services.optimus_query_bot.intent_handlers_lg.pay_to_mobile.graph import build_graph as build_pay_to_mobile_graph

# HELPER FUNCTION TO VISUALIZE THE GRAPH
def visualize_pay_to_mobile_graph(output_path: str | Path = "data/lg-handler-graphs/pay_to_mobile_graph.png") -> Path:
    graph = build_pay_to_mobile_graph()
    png_bytes = graph.get_graph().draw_mermaid_png()

    graph_png_path = Path(output_path)
    graph_png_path.parent.mkdir(parents=True, exist_ok=True)
    graph_png_path.write_bytes(png_bytes)
    return graph_png_path

# %%
# DRAW PAY TO MOBILE HANDLER
output_path = visualize_pay_to_mobile_graph()

# %%
