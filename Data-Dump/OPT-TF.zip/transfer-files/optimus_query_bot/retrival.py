import json
import re
import time
import logging
import numpy as np
import os
import string
import redis
from redisvl.index import SearchIndex
from redisvl.query import VectorQuery
from redisvl.query import HybridQuery
import redisvl.query as FilterQuery
from redisvl.query.filter import Text, Tag, Text, Num
from redis.commands.search.aggregation import AggregateRequest, Desc
from redisvl.redis.utils import convert_bytes, make_dict
from typing import Tuple, Dict, List
import boto3
import botocore

from app.instrumentation.tracing.tracer import traced
from app.utils.vector_utils import get_fin_embedding
from app.utils.redis_client import get_redis_client
from app.utils.text_utils import remove_punctuation, filter_stopwords

def tokenize_and_clean_query(user_query: str) -> str:
    words = user_query.lower().split()
    words_filtered = filter_stopwords(words)
    return "|".join(words_filtered)

def remove_punctuation(text: str) -> str:
    from string import punctuation
    return text.translate(str.maketrans('', '', punctuation))
DIM_SIZE = 1024

class FAQRetrieval:
    def __init__(self):
        self.r = get_redis_client(False)
        self.index_name = "OptimusQueryBot"
        self.DIM_SIZE = 1024
        self.index = self._initialize_index()

    def tokenize_and_clean_query(self, user_query: str) -> str:
        words = user_query.lower().split()
        words_filtered = filter_stopwords(words)
        return "|".join(words_filtered)

    async def make_vector_query(self, user_query: str, num_results: int):
        vector = await get_fin_embedding(user_query)
        return vector, VectorQuery(
            vector=vector,
            vector_field_name="faq_embeddings",
            return_fields=[
                    "title",
                    "description",
                    "line_of_business",
                    "intent",
                    "label",
                    "intent_type",
                    "deeplink",
            ],
            num_results=num_results,
        )

    def _initialize_index(self):
        schema = {
                    "index": {
                        "name": "OptimusQueryBot",
                        "prefix": "OptimusQueryBot",
                    },
                    "fields": [
                        {"name": "id", "type": "text"},
                        {"name": "tags", "type": "text"},
                        {"name": "title", "type": "text"},
                        {"name": "description", "type": "text"},
                        {"name": "intent", "type": "text"},
                        {"name": "label", "type": "text"},
                        {"name": "deeplink", "type": "text"},
                        {"name": "intent_priority", "type": "numeric"},
                        {"name": "intent_type", "type": "text"},
                        {"name": "line_of_business", "type": "text"},
                        {"name": "faqs", "type": "text"},
                        {"name": "faqsemb", "type": "text"},
                        {
                            "name": "exact_tags",
                            "type": "tag",
                            "attrs": {
                                "separator": "|"
                            }
                        },
                        {
                            "name": "faq_embeddings",
                            "type": "vector",
                            "attrs": {
                                "dims": DIM_SIZE,
                                "distance_metric": "cosine",
                                "algorithm": "flat",
                                "datatype": "float32"
                            }
                        },
                    ]
                }
        index = SearchIndex.from_dict(schema)
        index.set_client(self.r)
        return index



    @traced()
    def bm25_search(self, query_text: str, limit: int = 250):
        clean_query = query_text.translate(
            query_text.maketrans('', '', string.punctuation)
        )
        text_query = Text("faqs") % self.tokenize_and_clean_query(clean_query)
        req = (
            AggregateRequest(str(text_query))
            .scorer("BM25")
            .add_scores()
            .load(
                "title",
                "description",
                "line_of_business",
                "intent",
                "label",
                "deeplink",
                "intent_priority",
                "intent_type",
            )
            .sort_by(Desc("@__score"), max=limit)
            .dialect(4)
        )
        res = self.index.aggregate(req)
        
        return [make_dict(row) for row in convert_bytes(res.rows)]

    @traced()
    async def cosine_similarity_search(self, query_text: str, limit: int = 250):
        vector, vector_query = await self.make_vector_query(query_text, limit)
         
        req = (
            AggregateRequest(vector_query.query_string())  # ✅ FIX
            .load(
                "title",
                "description",
                "line_of_business",
                "intent",
                "label",
                "deeplink",
                "intent_priority",
                "intent_type",
            )
            # Lower vector_distance = better
            .apply(cosine_similarity="1 - @vector_distance")
            .sort_by(Desc("@cosine_similarity"), max=limit)
            .dialect(4)
        )

        vector_bytes = np.array(vector, dtype=np.float32).tobytes()

        res = self.index.aggregate(
            req,
            query_params={"vector": vector_bytes}
        )

        return [make_dict(row) for row in convert_bytes(res.rows)]
    @traced()
    def exact_search(self, query_text: str):
        """
        Deterministic exact intent matching using TAG field.
        Returns [] if:
        - query is long
        - no match
        - multiple matches (ambiguous)
        """

        query_norm = " ".join(query_text.lower().strip().split())
        tokens = query_norm.split()

        # 🔒 Guardrail 1: only short queries
        if len(tokens) > 3:
            return []

        # Escape spaces for TAG query
        escaped_query = query_norm.replace(" ", "\\ ")

        tag_query = f'@exact_tags:{{{escaped_query}}}'

        req = (
            AggregateRequest(tag_query)
            .load(
                "title",
                "description",
                "line_of_business",
                "intent",
                "label",
                "deeplink",
                "intent_type",
            )
            .dialect(4)
        )

        res = self.index.aggregate(req)
        rows = [make_dict(row) for row in convert_bytes(res.rows)]
        
        # 🔒 Guardrail 2: single intent only
        if len(rows) == 1:
            return rows

        return []