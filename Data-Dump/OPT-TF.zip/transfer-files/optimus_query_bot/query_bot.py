from time import time

from app.instrumentation.tracing.tracer import traced
from app.services.optimus_query_bot.retrival import FAQRetrieval
from app.services.optimus_query_bot.prompt import get_querybot_prompt, get_greeting_payload
from app.clients.llm_gw import get_llm_gw_client
import json
from typing import Dict, List, Any
import os
from app.services.optimus_query_bot.state_manager import StateManager
from app.services.optimus_query_bot.spellcorrector import SpellCorrector
from app.services.optimus_query_bot.helpers import weighted_score_fusion_new, get_hybrid_weights
from app.services.optimus_query_bot.rule_engine import RuleEngine
from app.services.optimus_query_bot.llm_usage import log_usage
import logging
from typing import List, Dict, Tuple

logger = logging.getLogger(__name__)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
spell_corrector_path = os.path.join(SCRIPT_DIR, "spell_corrector.txt")
banking_terms_dictionary = os.path.join(SCRIPT_DIR, "banking-terms-dictionary.json")

SC=SpellCorrector(symspell_dict_path=spell_corrector_path,
                             custom_map_path=banking_terms_dictionary)

class QueryBotService: 
    def __init__(self):
        self.retriever=FAQRetrieval()
        self.state_manager = StateManager()
        self.rule_engine = RuleEngine()

    @traced()
    async def generate_response(self, user_query: str, journey_data,conversation_history): 
        correct_query=SC.correct_query(user_query)['corrected_query']
        # customer_profile = journey_data
        
        exact_res=self.retriever.exact_search(user_query)
        customer_profile = journey_data.get("customer_profile", "liability|asset|creditcard")
        if exact_res:
            logger.info("returing exact response")
            response_json = self.check_intent_eligibility(customer_profile, exact_res[0])
            return response_json
        
# ======================= #add gemini model call =====================
        payload= get_greeting_payload(correct_query, conversation_history)
        client = get_llm_gw_client()
        # client = get_llm_gw_client("gemini")
        result = await client.generate_response(payload)
        log_usage(result, "optimus_query_bot.generate_response.gemini_greeting")
        # greeting_response = result["candidates"][0]["content"]["parts"][0]["text"]
        greeting_text=result['choices'][0]['message']['content']
        # greeting_text = result["candidates"][0]["content"]["parts"][0]["text"]
        try:
            greeting_response = json.loads(greeting_text)
        except (TypeError, json.JSONDecodeError) as exc:
            logger.error("Failed to parse greeting response: %s", greeting_text, exc_info=exc)
            raise

        # greeting_response=Parsed Response:
        #         {
        #         "query_type": "GREETING",
        #         "route": "self",
        #         "is_continuation": false,
        #         "rewritten_query": "Hello",
        #         "guardrail": "pass",
        #         "guardrail_reason": null,
        #         "self_response": "Hello Onkar! How can I assist you with your banking today?"
        #         }
# =======================end ==============

        # 
        print('greeting_response-',greeting_response)
        if greeting_response.get("route") == "self":
            return  {
                                "Response": greeting_response.get("self_response", ""),
                                "Intent Lists": []
                            }
        if greeting_response.get("is_continuation"):
            correct_query = greeting_response.get("rewritten_query", correct_query)
        bm25=self.retriever.bm25_search(correct_query)
        cosine=await self.retriever.cosine_similarity_search(correct_query)
        b_weights,c_weights=get_hybrid_weights(correct_query)
        combined=weighted_score_fusion_new(bm25,cosine,(b_weights,c_weights),manual_weight_coeff=0.05)
        filtered_combined = [
                    {
                        "title": item["title"],
                        "description": item["description"],
                        "line_of_business":item['line_of_business'],
                        "intent": item["intent"],
                        "label": item["label"],
                        "intent_type": item["intent_type"],
                        "deeplink": item["deeplink"]
                    }
                    for item in combined
        ]
        print("filtered_combined", filtered_combined)
        eligible,non_eligible=self.split_intents(customer_profile,filtered_combined[:10])
        # logger.info("eligible,non_eligible", eligible,non_eligible)
        print("eligible,non_eligible", eligible,non_eligible)
                    
        request_prompt = get_querybot_prompt()
        messages = [
            {
                "role": "system",
                "content": request_prompt
            },
            {
                "role": "user",
                "content": f"Eligible_intents:{eligible}\nNon Eligibile intents:{non_eligible}\n\nUser Question:\n{user_query}"
            }
        ]


        client = get_llm_gw_client()
        payload = {
            "model": "gpt-5.4",
            "max_completion_tokens": 1024,
            "temperature": 0.0,
            "top_p": 0.9,
            "messages": messages
        }
        result = await client.invoke_model(payload)
        log_usage(result, "optimus_query_bot.generate_response")
        # logger.info("result", result)
        data = json.loads(result['choices'][0]['message']['content'])
        
        # logger.info("Successfully invoked model", data)
        intent_list = self.resolve_intents(data['Intent Lists'], eligible)
        data['Intent Lists'] = intent_list
        print("final generated response ", data)
        return data
    
    async def initialize_journey(self, payload: Dict[str, Any], ai_session_id: str) -> str:
        return await self.state_manager.initialize_journey(payload, ai_session_id)
    
    async def get_journey_data(self, ai_session_id: str) -> Dict[str, Any]:
        return await self.state_manager.get_journey_data(ai_session_id)
    
    async def update_journey_field(self, ai_session_id: str, field: str, value: Any) -> None:
        await self.state_manager.update_journey_field(ai_session_id, field, value)
    
    async def delete_journey(self, session_id: str) -> None:
        await self.state_manager.delete_journey(session_id)
    
    async def clean_conversation_history(self, session_id: str) -> None:
        await self.state_manager.clean_conversation_history(session_id)

    @traced()
    async def intent_handler(self, ai_session_id: str, intent_id: str, intent_type: str, user_query: str, additional_data: dict) -> Dict[str, Any]:
        journey_data = await self.state_manager.get_journey_data(ai_session_id)
        response = await self.rule_engine.process_intent(
            intent_type=intent_type,
            user_query=user_query,
            journey_data=journey_data,
            intent_id=intent_id,
            additional_data=additional_data
        )
        return response
    
    async def add_conversation_turn(self,ai_session_id:str ,intent_id: str, user_query: str, bot_response: str) -> None:
        await self.state_manager.add_conversation_turn(ai_session_id, intent_id, user_query, bot_response)
    
    async def get_conversation_history(self, intent_id: str, limit: int = 1) -> List[Dict[str, Any]]:
        return await self.state_manager.get_conversation_history(intent_id, limit)
    
    def _get_query_enhancement_prompt(self):        
        system_message = """You are an orchestration layer for a banking conversational AI.

            You will receive:
            1. A historical conversation between a bank agent and a user, provided as a structured dictionary.
            2. A new user query that continues the conversation.
            
            Your task:
            - Generate a single, coherent user query that seamlessly merges the new user query with only the **relevant and necessary** context from the historical conversation.
            - Preserve the **exact intent and wording of the latest user query** as the primary focus.
            - Include historical details **only if they are required** to correctly interpret or answer the new query.
            - Exclude redundant, outdated, or irrelevant historical information.
            
            Important Handling Rule:
            - The downstream bot response may be returned in **HTML format containing HTML tags**.
            - **Do not treat HTML content as an error or malformed output**.
            - Generate the combined query assuming HTML-formatted responses are valid and expected.
            
            Constraints:
            - The final query must be concise, clear, and directly usable by a downstream agent bot.
            - Do not summarize the entire conversation; selectively inject context only where it adds value.
            - Do not introduce new assumptions, interpretations, or answers.
            - Output **only** the final combined query and nothing else.
            """    
        return system_message    
    
    async def updated_user_query(self, journey_name: str, user_query_dict,user_query):
        messages = [
                    {
                        "role": "system",
                        "content": self._get_query_enhancement_prompt()
                    },
                    {
                        "role": "user",
                        "content": f"""
                Historical Conversation (dictionary format):
                {user_query_dict}
                
                Latest User Query:
                {user_query}
                """
                    }
                ]

        client = get_llm_gw_client()
        payload = {
            "model": "gpt-5.4",
            "max_completion_tokens": 1024,
            "temperature": 0.0,
            "top_p": 0.9,
            "messages": messages
        }

        result = await client.update_query(payload)
        log_usage(result, "optimus_query_bot.updated_user_query")
       
        return result['choices'][0]['message']['content']
    
    
    
    
    async def get_journey_state(self, intent_id: str, journey_name: str) -> Dict[str, Any]:
        return await self.state_manager.get_journey_state(intent_id, journey_name)
    
    def update_journey_state(self, intent_id: str, journey_name: str, state_dict: Dict[str, Any]) -> None:
        self.state_manager.update_journey_state(intent_id, journey_name, state_dict)
          
    def get_non_eligibility_reason(self, lob_key: str) -> str:
        """
        Returns non-eligibility reason message based on line_of_business key.
        """

        # Normalize key (lowercase + sorted for consistent matching)
        normalized = "|".join(sorted(part.strip().lower() for part in lob_key.split("|")))

        REASONS = {
            "liability": (
                "It looks like you don’t currently have an Account relationship "
                "with IDFC FIRST Bank. This service is available for Account customers only."
            ),
            "creditcard": (
                "It looks like you don’t currently have a Credit Card relationship "
                "with IDFC FIRST Bank. This service is available for Credit Card customers only."
            ),
            "asset": (
                "It looks like you don’t currently have a Loan relationship "
                "with IDFC FIRST Bank. This service is available for Loan customers only."
            ),
            "asset|liability": (
                "It looks like you don’t currently have an Account or Loan relationship "
                "with IDFC FIRST Bank. This service is available for Account or Loan customers only."
            ),
        }

        return REASONS.get(
            normalized,
            "It looks like you don’t have the required relationship with IDFC FIRST Bank for this service."
        )

    
    def check_intent_eligibility(self, customer_profile: str, intent: dict):
        customer_lobs = set(customer_profile.lower().strip().split("_"))
        intent_lobs = set(intent["line_of_business"].lower().strip().split("|"))

        is_eligible = bool(customer_lobs & intent_lobs)

        if  is_eligible:
            response_json = {
                                "Response": intent['description'],
                                "Intent Lists": [
                                    {
                                        "intent": intent['intent'],
                                        "label": intent['label'],
                                        "intent_type": intent['intent_type'],
                                        "deeplink": intent['deeplink']
                                    }
                                ]
                            }
        else:
            response_json = {
                                "Response": self.get_non_eligibility_reason(intent["line_of_business"]),
                                "Intent Lists": []
                            }

        return response_json

    def resolve_intents(self, selected_ids, eligible_intents):
        """
        selected_ids: List[int] returned by LLM
        eligible_intents: List[dict] (eligible intent objects)

        Returns final intent list based on rules.
        """

        # 1️⃣ If no IDs returned
        if not selected_ids:
            return []

        selected_ids=list(set(selected_ids))

        # Create lookup from eligible intents
        eligible_map = {intent["id"]: intent for intent in eligible_intents}

        # 2️⃣ Filter matching eligible intents
        matched = [eligible_map[i] for i in selected_ids if i in eligible_map]

        if matched:
            return matched

        # 3️⃣ IDs exist but none valid → return first two eligible intents
        return eligible_intents[:2]
    
    

    def split_intents(
        self,
        customer_profile: str,
        intent_list: List[Dict]
    ) -> Tuple[List[Dict], List[Dict]]:
        """
        Splits intents into eligible and non-eligible lists,
        assigns unique IDs,
        and adds missing eligibility info for non-eligible intents.
        """

        customer_lobs = {
            part.strip().lower()
            for part in customer_profile.split("_")
            if part.strip()
        }

        eligible_intents = []
        non_eligible_intents = []

        for intent in intent_list:
            lob_string = intent.get("line_of_business", "")

            # Normalize intent LOB (OR logic)
            intent_lobs = {
                part.strip().lower()
                for part in lob_string.split("|")
                if part.strip()
            }

            intent_copy = intent.copy()

            if customer_lobs.intersection(intent_lobs):
                eligible_intents.append(intent_copy)
            else:
                # Add missing profile info
                intent_copy["non_eligible_reason"] = self.get_non_eligibility_reason(lob_string)
                non_eligible_intents.append(intent_copy)

        # Assign globally unique IDs
        current_id = 1

        for intent in eligible_intents:
            intent["id"] = current_id
            current_id += 1

        for intent in non_eligible_intents:
            intent["id"] = current_id
            current_id += 1

        return eligible_intents, non_eligible_intents
    
_query_bot_service = None

def get_query_bot_service() -> QueryBotService:
    global _query_bot_service
    if _query_bot_service is None:
        _query_bot_service = QueryBotService()
    return _query_bot_service
