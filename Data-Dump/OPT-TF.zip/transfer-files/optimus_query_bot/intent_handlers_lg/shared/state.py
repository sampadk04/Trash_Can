from typing import Any


def merge_known_state(default_state: dict[str, Any], journey_state: dict[str, Any] | None) -> dict[str, Any]:
    """Merge known keys from journey_state into default_state."""
    state = default_state.copy()
    if journey_state:
        for key, value in journey_state.items():
            if key in state:
                state[key] = value
    return state


def yes(value: Any) -> bool:
    """Return True if value is the string "yes"."""
    return str(value or "").lower().strip() == "yes"
