from typing import Any, Literal

from pydantic import BaseModel, Field


class CreditCardGraphState(BaseModel):
    journey: str = Field(default="CC_PAYMENT", description="Current credit card payment journey identifier.")
    bot_response: str = Field(default="", description="Customer-facing response for the current turn.")
    fetch_card_details: str = Field(default="no", description="Whether the UI should show credit card choices.")
    card_details: Any = Field(default=None, description="Selected credit card details from the widget.")
    fetch_payment_amount: str = Field(default="no", description="Whether the UI should show payment amount choices.")
    payment_amount: Any = Field(default=None, description="Selected payment amount from the widget.")
    fetch_account_details: str = Field(default="no", description="Whether the UI should show source account choices.")
    account_details: Any = Field(default=None, description="Selected bank account details from the widget.")
    raise_final_confirmation: str = Field(default="no", description="Whether the UI should raise final confirmation.")
    abort: str = Field(default="no", description="Whether this journey is aborted or complete.")
    off_topic_count: int = Field(default=0, description="Count of unrelated free-text turns.")
    show_redirection: str = Field(default="no", description="Whether the UI should show a redirection option.")
    count: int = Field(default=0, description="Number of turns processed by this handler.")
    widget_response: str = Field(default="no", description="Whether the current turn came from a widget response.")
    user_query: str = Field(default="", description="Latest user message.")


class CreditCardHelpOutput(BaseModel):
    bot_response: str = Field(description="Customer-facing guidance for the current typed input.")
    intent: Literal["widget_issue", "abort", "other"] = Field(
        description="Classify the user query as widget_issue, abort, or other."
    )
