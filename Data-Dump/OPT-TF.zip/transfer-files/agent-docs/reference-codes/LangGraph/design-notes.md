# Designing Systems with LangGraph

## Build From the Workflow

Before coding, answer:

1. What enters the system?
2. What decisions are needed?
3. What external data/actions are needed?
4. What output should be returned?
5. Where can the system stop, retry, or ask for review?

Turn stable steps into action-named nodes: `classify_intent`, `search_docs`, `draft_answer`, `human_review`.

## Node Categories

- LLM nodes: classify, draft, evaluate, summarize.
- Data nodes: search docs, fetch records, retrieve history.
- Action nodes: create ticket, send email, write database rows.
- Human nodes: approval, edit, clarification, escalation.

## State Defaults

Store durable raw data:

- original input,
- decisions,
- retrieval results,
- drafts,
- tool/action results,
- final response.

Avoid storing formatted prompts. Build prompts inside nodes from current state.

## Common Patterns

```text
Prompt chain:
START -> generate -> check -> improve -> final -> END

Router:
START -> classify -> {retrieve | action | human_review | answer}

Parallel fan-out:
START -> {extract_facts, check_policy, search_docs} -> synthesize -> END

Orchestrator-worker:
START -> plan_sections -> Send(worker per section) -> reduce -> END

Evaluator-optimizer:
START -> draft -> evaluate -> {revise | END}
```

Add a max-iteration or remaining-step guard to loops.

## Minimal Build Order

1. Write the state schema.
2. Stub nodes with deterministic code.
3. Wire edges and conditional edges.
4. Compile and invoke tiny fixtures.
5. Add LangChain model/tool calls inside nodes.
6. Add checkpointing when memory, interrupts, or recovery are needed.
7. Add streaming after the workflow shape is stable.

## Practical Defaults

- `TypedDict` for state.
- `MessagesState` for conversational graphs.
- `ChatOpenAI` or `init_chat_model` for model calls.
- `with_structured_output` for routing/classification.
- conditional edges for routing.
- `Command` when a node both updates and routes.
- `create_agent` for a prebuilt vanilla agent loop.
- custom `StateGraph` for explicit workflow control.
