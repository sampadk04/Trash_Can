# Migration: Use `create_agent`

For a prebuilt vanilla agent loop, use LangChain:

```python
from langchain.agents import create_agent
```

Do not start new code with deprecated LangGraph prebuilt agents:

```python
from langgraph.prebuilt import create_react_agent
```

## Minimal Agent

```python
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI


def search_docs(query: str) -> str:
    """Search internal docs."""
    return "stub result"


agent = create_agent(
    model=ChatOpenAI(model="gpt-5-nano", temperature=0),
    tools=[search_docs],
    system_prompt="Answer using tools when needed.",
)

result = agent.invoke({
    "messages": [{"role": "user", "content": "Find the refund policy."}]
})
print(result["messages"][-1].content)
```

Structured response:

```python
from pydantic import BaseModel


class Answer(BaseModel):
    answer: str
    confidence: float


agent = create_agent(
    model="openai:gpt-5-nano",
    tools=[],
    response_format=Answer,
)

result = agent.invoke({"messages": [{"role": "user", "content": "Hi"}]})
print(result["structured_response"])
```

## Migration Notes

- `langgraph.prebuilt.create_react_agent` -> `langchain.agents.create_agent`.
- `prompt` -> `system_prompt`.
- Pass tools to `create_agent`; do not pre-bind them by default.
- Use `response_format` for structured final output.
- Use middleware for dynamic model selection and hooks.
- Use `TypedDict` when custom state is needed.

Use `create_agent` for a standard model/tools/model loop. Use `StateGraph` directly for custom branching, multiple LLM nodes, retrieval/generation/evaluation phases, human review, or durable workflow control.

## Source Links

- LangChain v1 migration guide: https://docs.langchain.com/oss/python/migrate/langchain-v1
- LangGraph v1 migration guide: https://docs.langchain.com/oss/python/migrate/langgraph-v1
- Agents: https://docs.langchain.com/oss/python/langchain/agents
