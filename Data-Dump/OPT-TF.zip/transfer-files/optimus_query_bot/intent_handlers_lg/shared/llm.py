from typing import Type, TypeVar

from dotenv import load_dotenv
from httpx import AsyncClient, Client
from langchain_core.messages import BaseMessage
from langchain_openai import ChatOpenAI
from pydantic import BaseModel


load_dotenv()

StructuredModel = TypeVar("StructuredModel", bound=BaseModel)


def build_chat_openai(reasoning_effort: str = "low") -> ChatOpenAI:
    http_client = Client(verify=False)
    async_http_client = AsyncClient(verify=False)
    return ChatOpenAI(
        model="gpt-5.2",
        use_responses_api=True,
        reasoning={"effort": reasoning_effort},
        temperature=None,
        max_retries=2,
        http_client=http_client,
        http_async_client=async_http_client,
    )


def build_structured_chat_openai() -> ChatOpenAI:
    http_client = Client(verify=False)
    async_http_client = AsyncClient(verify=False)
    return ChatOpenAI(
        model="gpt-5.2",
        temperature=0.0,
        max_retries=2,
        http_client=http_client,
        http_async_client=async_http_client,
    )


async def ainvoke_structured(
    messages: list[BaseMessage | tuple[str, str] | dict[str, str]],
    output_model: Type[StructuredModel],
    reasoning_effort: str = "low",
) -> StructuredModel:
    llm = build_structured_chat_openai()
    structured_llm = llm.with_structured_output(output_model, method="json_schema")
    return await structured_llm.ainvoke(messages)
