import traceback
from typing import Dict, Any, Optional

from app.instrumentation.tracing.tracer import traced
from app.services.optimus_query_bot.intent_handlers.fixed_deposit import FixedDepositHandler
from app.services.optimus_query_bot.intent_handlers.credit_card import CreditCardHandler
from app.services.optimus_query_bot.intent_handlers.upi import UPIHandler
from app.services.optimus_query_bot.intent_handlers.email_update import EmailChangeHandler
from app.services.optimus_query_bot.intent_handlers.loan_noc import LoanNocHandler
from app.services.optimus_query_bot.state_manager import StateManager
import logging
logger = logging.getLogger(__name__)
class RuleEngine:
    def __init__(self):
        self.state_manager = StateManager()
        self.handler_classes = {
            "OPEN_FD": FixedDepositHandler,
            "PAY_CREDIT_CARD_BILL": CreditCardHandler,
            "PAY_TO_MOBILE": UPIHandler,
            "LOAN_NOC": LoanNocHandler,
            "EMAIL_UPDATE": EmailChangeHandler,
        }
        
        self.INTENT_REQUIRED_KEYS = {
            "OPEN_FD": ["primary_balance","fixed_deposit_plans"],
            "PAY_CREDIT_CARD_BILL": ["primary_balance"],
            "PAY_TO_MOBILE": ["primary_balance"],
        }

    def validate_journey_data(self, intent_type: str, journey_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        print("journey_data primary balance", journey_data.get("primary_balance"))
        missing = [k for k in self.INTENT_REQUIRED_KEYS.get(intent_type, []) if journey_data.get(k) is None]
        if missing:
            return {
                "status": "incomplete",
                "missing_data": missing,
                "bot_response": "We're unable to process your request at the moment. Please try again or contact support if the issue persists."
            }
        return None


    @traced()
    async def process_intent(
        self, 
        intent_type: str, 
        user_query: str, 
        journey_data: Dict[str, Any],
        intent_id: str,
        additional_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        handler_cls = self.handler_classes.get(intent_type)
        
        if not handler_cls:
            return {
                "status": "error",
                "message": f"Unknown intent type: {intent_type}",
                "bot_response": "I'm sorry, I don't understand that request."
            }
        
        validation_error = self.validate_journey_data(intent_type, journey_data)
        if validation_error:
            return validation_error

        handler = handler_cls()
        
        try:
            journey_name = journey_data.get("journey_name", "")
            journey_state = await self.state_manager.get_journey_state(intent_id, journey_name) if journey_name else {}
            _addn_data = additional_data if additional_data is not None else {}
            handler._update_state_from_request(_addn_data, journey_state)

            # logger.info("journey_state", handler.state)

            response = await handler.handle(
                user_query=user_query,
                journey_data=journey_data,
                journey_state=journey_state,
            )
            intent_data = handler.get_intent_data()
            
            # print("response from llm ", response)
            
            state_to_save = {k: v for k, v in response.items() if k != "bot_response"}
            # logger.info("state_to_save", state_to_save)
            
            await self.state_manager.update_journey_state(intent_id, journey_name, state_to_save)

            return {
                "bot_response": response.get("bot_response", ""),
                "intent_list": [{
                    "intent": intent_data.get("intent", ""),
                    "label": intent_data.get("intent", ""),
                    "intent_type": intent_data.get("intent_type", ""),
                }],
                "abort": state_to_save["abort"].lower(),
                "additional_data": state_to_save
            }
        except Exception as e:
            
            # logger.info(f"Error processing intent {intent_type}: {str(e)}")
            error_trace = traceback.format_exc()
            logger.info("error_trace", error_trace)
            return {
                "status": "error",
                "message": str(e),
                "bot_response": "Something went wrong while processing your request."
            }
