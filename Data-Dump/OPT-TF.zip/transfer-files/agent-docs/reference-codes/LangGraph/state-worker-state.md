# State and Worker State Management

State should contain durable raw data that later nodes need. Build prompts and other scratch values inside nodes.

## Good State Shape

```python
from typing_extensions import TypedDict


class SupportState(TypedDict):
    email_content: str
    sender_email: str
    classification: dict | None
    search_results: list[str]
    draft_response: str | None
    final_response: str | None
```

Avoid storing full prompt strings in state. Prompts change often and can be rebuilt from raw fields.

## Shared State vs Local Variables

```python
def retrieve(state: SupportState) -> dict:
    query = build_query(state["classification"], state["email_content"])
    raw_docs = search_index(query)
    normalized_docs = [doc.page_content for doc in raw_docs]
    return {"search_results": normalized_docs}
```

Only return data that must survive beyond the node.

## Private/Internal Channels

```python
from typing_extensions import TypedDict
from langgraph.graph import END, START, StateGraph


class InputState(TypedDict):
    user_request: str


class OutputState(TypedDict):
    final_answer: str


class InternalState(InputState, OutputState):
    route: str
    retrieved_docs: list[str]


def classify(state: InputState) -> dict:
    return {"route": "retrieve"}


def retrieve(state: InternalState) -> dict:
    return {"retrieved_docs": ["doc chunk"]}


def answer(state: InternalState) -> dict:
    return {"final_answer": "\n".join(state["retrieved_docs"])}


builder = StateGraph(
    InternalState,
    input_schema=InputState,
    output_schema=OutputState,
)
builder.add_node("classify", classify)
builder.add_node("retrieve", retrieve)
builder.add_node("answer", answer)
builder.add_edge(START, "classify")
builder.add_edge("classify", "retrieve")
builder.add_edge("retrieve", "answer")
builder.add_edge("answer", END)
graph = builder.compile()
```

The caller sees only `user_request` input and `final_answer` output.

## Parallel Writes

```python
import operator
from typing import Annotated


class ResearchState(TypedDict):
    topic: str
    findings: Annotated[list[str], operator.add]


def worker(state: ResearchState) -> dict:
    return {"findings": ["one finding"]}
```

Any key written by multiple parallel nodes needs a reducer.

## Practical Rule

Start with one `TypedDict`. Split into input/output/internal schemas only when you need a stable public interface, hidden working channels, clean outputs, or parallel reducer channels.

## Source Links

- Graph API overview: https://docs.langchain.com/oss/python/langgraph/graph-api
- Use the Graph API: https://docs.langchain.com/oss/python/langgraph/use-graph-api
