from typing import Any, Literal

from pydantic import BaseModel, Field


class EmailUpdateGraphState(BaseModel):
    journey: str = Field(default="CHANGE_EMAIL", description="Current email update journey identifier.")
    bot_response: str = Field(default="", description="Customer-facing response for the current turn.")
    change_email_eligibility: str = Field(default="no", description="Whether eligibility check should be triggered.")
    eligibility_checked: str = Field(default="no", description="Whether eligibility has already been checked.")
    is_eligible: Any = Field(default=None, description="Eligibility value returned by the platform.")
    email_mfa: str = Field(default="no", description="Whether email MFA should be triggered.")
    get_new_email: str = Field(default="no", description="Whether UI should collect and validate the new email.")
    new_email: Any = Field(default=None, description="New email address entered by the user.")
    current_email: Any = Field(default=None, description="Current registered email address.")
    service_request_no: Any = Field(default=None, description="Service request number for successful email update.")
    confirmation_raised: str = Field(default="no", description="Whether final confirmation has been shown.")
    status: str = Field(default="none", description="Email update execution status.")
    abort: str = Field(default="no", description="Whether this journey is aborted or complete.")
    off_topic_count: int = Field(default=0, description="Count of unrelated turns.")
    user_query: str = Field(default="", description="Latest user message.")


class EmailConfirmationOutput(BaseModel):
    confirmation: Literal["yes", "no", "ambiguous"] = Field(
        description="Classify whether the user confirms, rejects, or gives an unclear response."
    )
