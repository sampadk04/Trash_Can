from openai import AsyncOpenAI
from httpx import AsyncClient
from dotenv import load_dotenv

# from app.clients.llm_gw import get_llm_gw_client
from app.services.optimus_query_bot.llm_usage import log_usage
from typing import Optional, Dict, Any
import json
import time

load_dotenv()
openai_client = AsyncOpenAI(http_client=AsyncClient(verify=False))

async def gptcall(messages,FD_OUTPUT_SCHEMA):
    response = await openai_client.chat.completions.create(
        model="gpt-5.2",
        messages=messages,
        max_completion_tokens=1024,
        temperature=0.0,
        top_p=0.9,
        response_format=FD_OUTPUT_SCHEMA
    )
    
    response_dict = response.model_dump()
    return response_dict

# gptcall=LLMGatewayClient()

# client = get_llm_gw_client()

# async def gptcall(messages,FD_OUTPUT_SCHEMA): 
#     payload = {
#         "model": "gpt-5.4",
#         "max_completion_tokens": 1024,
#         "temperature": 0.0,
#         "top_p": 0.9,
#         "messages": messages,
#         "response_format": FD_OUTPUT_SCHEMA
#     }


#     response = await client.invoke_model(payload)
#     log_usage(response, "optimus_query_bot.loan_noc.gptcall")
#     return response

# ========================= Helper functions =======================================
async def check_confirmation(user_query):
    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "check_confirmation",
            "schema": {
                "type": "object",
                "properties": {
                    "confirmation": {
                        "type": "string",
                        "enum": ["yes", "no"],
                        "description": "Whether the user confirms the displayed address"
                    }
                },
                "required": ["confirmation"],
                "additionalProperties": False
            }
        }
    }

    messages = [
        {
            "role": "system",
            "content": """
### Role
You are a banking address confirmation classifier.

### Context
The user was shown an address and asked to confirm:
"The NOC will be sent to the address shown above. Please confirm."

### Task
Classify the user's response into:
- "yes" → user clearly confirms the address
- "no" → user rejects, wants to change, questions, or gives an unclear response

### Classification Rules (Strict)

Return "yes" ONLY if the user explicitly confirms.
Examples:
- "yes"
- "confirm"
- "this is correct"
- "looks fine"
- "okay proceed"
- "send it here"

Return "no" for ALL other cases, including:
- Address rejection:
  - "this is not my address"
  - "wrong address"
  - "I want to change my address"
- Requests or questions:
  - "can I update it?"
  - "where did you get this?"
- Hesitation or ambiguity:
  - "not sure"
  - "maybe later"
  - silence or unrelated text

### Safety Rule
If confirmation is NOT explicit, return "no".

### Output Rules
- Output ONLY valid JSON
- Do NOT explain reasoning
- Do NOT ask questions

### Output Format
{
  "confirmation": "yes | no"
}
"""
        },
        {
            "role": "user",
            "content": f"user_query: {user_query}"
        }
    ]

    raw_response = await gptcall(messages, out_schema)
    final_output = raw_response["choices"][0]["message"]["content"]
    return json.loads(final_output)




# ================================ orchastrator function =================================================

def initialize_noc_state() -> Dict[str, Any]:
    return {
        "journey": "LOAN_NOC",
        "bot_response": "",

        # core data
        "noc_loan": None,
        "noc_address": None,
        "status": None,  # success | failure | None
        "service_request_no": None,

        # UI / control flags
        "fetch_loan_list": "no",
        "show_address": "no",
        "raise_noc_request": "no",

        # abort
        "abort": "no",
    }

class LoanNocHandler:
    def __init__(self):
        self.state = initialize_noc_state()

    def _update_state_from_request(self, additional_data:dict, journey_state: dict):
        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

        if "noc_loan" in additional_data:
            self.state["noc_loan"] = additional_data.get("noc_loan").lower().strip()

        if 'noc_address' in additional_data:
            self.state['noc_address']=additional_data.get("noc_address")

        if "status" in additional_data:
            self.state["status"] = additional_data.get("status")

        if "service_request_no" in additional_data:
            self.state["service_request_no"] = additional_data.get("service_request_no")

    async def loan_noc_orchestrator(self,user_query: str, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Orchestrates Loan NOC flow.
        """

        # ================= Reset UI flags =================
        state["fetch_loan_list"] = "no"
        state["show_address"] = "no"
        state["raise_noc_request"] = "no"
        state['show_redirection']='no'
        state["bot_response"] = ""


        # ================= Loan selection =================
        if not state.get("noc_loan"):
            state["bot_response"] = (
                "Please select the loan for which you want to raise the NOC request."
            )
            state["fetch_loan_list"] = "yes"
            return state

        # ================= Address confirmation =================
        if not state.get("noc_address"):
            state["bot_response"] = (
                f"Please confirm the address shown below. "
                f"The NOC for loan {state['noc_loan']} will be sent to this address."
            )
            state["show_address"] = "yes"
            return state

        # ================= User confirmation =================
        if state.get("noc_address") and not state.get("status"):
            confirmation_response = await check_confirmation(user_query)

            if confirmation_response.get("confirmation") == "yes":
                state["raise_noc_request"] = "yes"
                return state

            if confirmation_response.get("confirmation") == "no":
                state["bot_response"] = (
                    "Sorry we could not proceed without address confirmation, if you want to update the address please follow below redirection else try again"
                )
                state['show_redirection']='yes'
                return state

        # ================= Success =================
        if state.get("status") == "success":
            state["bot_response"] = (
                f"Your NOC request has been placed successfully with request number "
                f"{state.get('service_request_no')}. "
                f"It will be delivered to the confirmed address within 2 weeks."
            )
            return state

        # ================= Failure =================
        if state.get("status") == "failure":
            state["bot_response"] = (
                "We could not process your NOC request at the moment. "
                "Please try again later."
            )
            return state
        return state


    async def handle(self, user_query, journey_data, journey_state):
        state = self.state

        updated_state = await self.loan_noc_orchestrator(
            user_query=user_query,
            state=state,
        )
        self.state=updated_state
        return updated_state


    def get_intent_data(self):

        journey_id="LOAN_NOC"
        if self.state.get("status"):
            if self.state.get("status").lower().strip() == "success":
                return {
                    "intent_type": "Execution",
                    "intent": f"{journey_id}.SHOW_FINAL_STATUS"
                }

        if self.state.get("raise_noc_request").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.CREATE_NOC_REQUEST"
            }
        
        if self.state.get("show_address").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.CONFIRM_ADDRESS"
            }

        if self.state.get("show_redirection").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SHOW_REDIRECTION"
            }

        if self.state.get("fetch_loan_list").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SELECT_NOC_LOAN"
            }
        return {
            "intent_type": "Clarification",
            "intent": journey_id
        }
