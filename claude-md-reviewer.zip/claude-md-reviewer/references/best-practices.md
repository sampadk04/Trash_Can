# CLAUDE.md Best Practices

Based on context engineering research and real-world experience from HumanLayer and the broader coding agent community.

## Why CLAUDE.md Matters

`CLAUDE.md` is injected into **every single conversation** with the coding agent. It is the highest-leverage configuration point in the entire harness:

- A bad line of code = one bad line
- A bad line in an implementation plan = many bad lines of code
- A bad line in CLAUDE.md = bad outcomes across **every task, every session**

Because of this leverage, every line in the file deserves careful thought.

## The Relevance Filter

Claude Code wraps `CLAUDE.md` contents with a system reminder that tells the model to **ignore content it deems irrelevant** to the current task. This means:

- The more non-universal content you include, the more likely the model ignores ALL of it
- Instructions that only apply to specific tasks dilute the ones that apply everywhere
- Focused, universally-applicable content gets followed more reliably

## Principle 1: Less Instructions Is More

Research findings on LLM instruction-following:

- Frontier thinking models reliably follow ~150-200 instructions
- Claude Code's system prompt already contains ~50 instructions
- That leaves ~100-150 instructions before degradation sets in
- As instruction count increases, compliance drops **uniformly** (not just for new instructions)
- Smaller models degrade exponentially; larger models degrade linearly

**Implication**: Your CLAUDE.md should contain the minimum number of instructions needed. Every unnecessary instruction degrades compliance with ALL instructions.

## Principle 2: Universal Applicability

Since the file loads in every session, every line should be relevant to every task. Ask yourself: "Would this matter if I'm doing a quick bug fix? A major refactor? Writing tests? Reviewing code?"

If the answer is "only sometimes," it belongs in a separate file that gets loaded on demand.

**Bad examples** (task-specific):
- How to structure database migrations
- Steps for deploying to production
- Code review guidelines
- API design conventions

**Good examples** (universal):
- Project purpose and architecture overview
- Package manager and runtime (bun vs node, etc.)
- How to run tests and type checks
- Key directories and what they contain

## Principle 3: Progressive Disclosure

Instead of stuffing everything into CLAUDE.md, keep task-specific docs in separate files and add a pointer table:

```markdown
## Additional Context

Read the relevant file(s) before starting work:

| File | When to Read |
|------|-------------|
| agent_docs/testing.md | Writing or modifying tests |
| agent_docs/deployment.md | Deployment-related changes |
| agent_docs/architecture.md | Cross-service or structural changes |
```

Key rules for reference documents:
- **Prefer pointers to copies**: Use `file:line` references instead of code snippets (snippets go stale)
- **Self-descriptive names**: The agent should be able to judge relevance from the filename alone
- **Keep them focused**: One topic per file

## Principle 4: Don't Use LLMs as Linters

Code style instructions in CLAUDE.md:
- Add many low-value instructions that degrade overall compliance
- Are slower and more expensive than deterministic tools
- Are unnecessary - LLMs are in-context learners that follow existing patterns

**Better alternatives:**
- Configure a linter/formatter (Biome, ESLint, Prettier, Black, Ruff)
- Set up a Claude Code `Stop` hook that runs the formatter and presents errors
- Create a slash command for post-implementation formatting review
- Use `pre-commit` hooks for automatic formatting

## Principle 5: Hand-Craft Your CLAUDE.md

Don't use `/init` or auto-generation. The file is too high-leverage to leave to automation. Reasons:

- Auto-generated files tend to be verbose and include non-universal content
- They often include redundant information the agent can discover itself
- Every unnecessary line costs compliance across all instructions
- The file should reflect YOUR team's specific workflow and priorities

## Principle 6: The WHY-WHAT-HOW Framework

A good CLAUDE.md covers three dimensions:

### WHY (Purpose)
- What is this project? What problem does it solve?
- Who uses it? What are the key business constraints?

### WHAT (Structure)
- Tech stack and key dependencies
- Project structure / directory map (especially for monorepos)
- What the major components are and what they do

### HOW (Workflow)
- Package manager and runtime commands
- How to build, test, and verify changes
- Any non-obvious workflows (e.g., "always run X before Y")

## Length Guidelines

| Quality | Lines | Instructions |
|---------|-------|-------------|
| Excellent | < 60 | < 30 |
| Good | < 100 | < 50 |
| Acceptable | < 300 | < 100 |
| Too long | 300+ | 100+ |

Note: HumanLayer's own root CLAUDE.md is under 60 lines.

## LLM Attention Patterns

Research shows LLMs bias toward instructions at:
1. The very beginning of the prompt (system message + CLAUDE.md)
2. The very end (most recent user messages)

Instructions in the middle of a long CLAUDE.md get less attention. This means:
- Put the most critical instructions first
- Keep the file short so there's less "middle" to lose attention in
- Front-load universal instructions, defer task-specific ones to separate files
