from typing import Any

from app.services.optimus_query_bot.intent_handlers_lg.open_fd.graph import build_graph, initialize_state
from app.services.optimus_query_bot.intent_handlers_lg.shared.state import yes


class FixedDepositGraphHandler:
    def __init__(self):
        self.state = initialize_state()
        self.graph = build_graph()

    def _update_state_from_request(self, additional_data: dict, journey_state: dict):
        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

    async def handle(self, user_query: str, journey_data: dict[str, Any], journey_state: dict[str, Any]):
        result = await self.graph.ainvoke(
            {
                **self.state,
                "user_query": user_query,
                "primary_balance": journey_data.get("primary_balance", 0),
                "fixed_deposit_plans": journey_data.get("fixed_deposit_plans", []),
            }
        )
        result.pop("user_query", None)
        result.pop("primary_balance", None)
        result.pop("fixed_deposit_plans", None)
        self.state = result
        return self.state

    def get_tenure_info(self, days):
        years = days // 365
        remaining_days = days % 365
        return {"years": years, "days": remaining_days}

    def get_intent_data(self):
        journey_id = "OPEN_FD"
        if yes(self.state.get("raise_final_confirmation")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.RAISE_FINAL_CONFIRMATION"}
        if yes(self.state.get("change_default")):
            return {"intent_type": "Redirection", "intent": journey_id}
        if str(self.state.get("show_interest_rate_chart") or "").lower().strip() == "true":
            return {"intent_type": "Clarification", "intent": f"{journey_id}.SHOW_PLANS"}
        if yes(self.state.get("abort")):
            return {"intent_type": "", "intent": ""}
        return {"intent_type": "Clarification", "intent": journey_id}
