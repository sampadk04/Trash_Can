# CLAUDE.md Review Checklist

Use this checklist to systematically evaluate a `CLAUDE.md` (or `AGENTS.md`) file.

## Metrics to Measure

Before starting the checklist, gather these numbers:

| Metric | How to Measure |
|--------|---------------|
| Total lines | `wc -l CLAUDE.md` |
| Instruction count | Count discrete imperative statements (do X, don't Y, always Z, never W) |
| Code snippet lines | Count lines inside code fences |
| Section count | Count H2/H3 headings |

## Checklist

### Structure & Coverage

| # | Criterion | What to Check |
|---|-----------|---------------|
| 1 | **Has WHY section** | Does the file explain the project's purpose, who uses it, and why it exists? |
| 2 | **Has WHAT section** | Does the file describe the tech stack, key dependencies, and project structure? |
| 3 | **Has HOW section** | Does the file explain how to build, test, and verify changes? |
| 4 | **Critical commands present** | Are the 2-3 most essential commands included (build, test, typecheck)? |
| 5 | **Directory map (if needed)** | For monorepos or complex projects, is there a brief directory overview? |

### Conciseness

| # | Criterion | What to Check |
|---|-----------|---------------|
| 6 | **Under 300 lines** | Is the total file length under 300 lines? (Under 100 is excellent) |
| 7 | **Under 100 instructions** | Are there fewer than 100 discrete instructions? (Under 50 is excellent) |
| 8 | **No redundant instructions** | Are there instructions the agent could infer from reading the codebase? |
| 9 | **No verbose explanations** | Are explanations kept to 1-2 sentences max? |
| 10 | **No auto-generated boilerplate** | Does the file look hand-crafted rather than `/init`-generated? |

### Universal Applicability

| # | Criterion | What to Check |
|---|-----------|---------------|
| 11 | **Every line is universal** | Would every instruction matter for ANY task in this repo? |
| 12 | **No task-specific workflows** | Are deployment, migration, or review-specific instructions absent? |
| 13 | **No conditional instructions** | Are there "if you're doing X, then Y" patterns that should be extracted? |
| 14 | **No role-specific content** | Are there instructions only relevant to certain team members? |

### Progressive Disclosure

| # | Criterion | What to Check |
|---|-----------|---------------|
| 15 | **Task-specific content extracted** | Is non-universal content in separate files (e.g., `agent_docs/`)? |
| 16 | **Pointer table present** | If separate docs exist, does CLAUDE.md have a table pointing to them? |
| 17 | **Pointers over copies** | Are code examples replaced with `file:line` references where possible? |
| 18 | **Self-descriptive filenames** | Can the agent judge relevance from filenames alone? |

### Anti-Patterns

| # | Criterion | What to Check |
|---|-----------|---------------|
| 19 | **No code style rules** | Are formatting/style guidelines absent? (Use linters instead) |
| 20 | **No inline code snippets** | Are there code blocks that will go stale? Replace with file references |
| 21 | **No exhaustive command lists** | Are there long lists of every possible command? Keep only top 2-3 |
| 22 | **No copy-pasted docs** | Is there content copied from READMEs or other docs? Link instead |
| 23 | **No "hotfix" instructions** | Are there narrow behavioral corrections appended to the bottom? |
| 24 | **No negative-only rules** | Are instructions phrased as what TO do, not just what NOT to do? |

### Ordering & Emphasis

| # | Criterion | What to Check |
|---|-----------|---------------|
| 25 | **Most critical info first** | Are the most important instructions near the top of the file? |
| 26 | **Logical section ordering** | Does the file flow: WHY -> WHAT -> HOW? |
| 27 | **No buried critical instructions** | Are important instructions lost in the middle of long sections? |

## Severity Guide

When scoring each criterion:

- **PASS**: Fully meets the criterion
- **WARN**: Partially meets or has room for improvement
- **FAIL**: Clearly violates the criterion; likely degrading agent performance

Focus recommendations on FAIL items first, then WARN items.
