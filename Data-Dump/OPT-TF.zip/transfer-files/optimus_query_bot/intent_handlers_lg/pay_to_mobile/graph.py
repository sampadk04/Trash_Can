from typing import Any

from langgraph.graph import END, START, StateGraph

from app.services.optimus_query_bot.intent_handlers_lg.pay_to_mobile.models import (
    UpiAmountOutput,
    UpiGraphState,
    UpiIntentOutput,
    UpiPayeeOutput,
)
from app.services.optimus_query_bot.intent_handlers_lg.pay_to_mobile.prompts import (
    UPI_AMOUNT_SYSTEM_PROMPT,
    UPI_INTENT_SYSTEM_PROMPT,
    UPI_PAYEE_SYSTEM_PROMPT,
)
from app.services.optimus_query_bot.intent_handlers_lg.shared.llm import ainvoke_structured


def initialize_state() -> dict[str, Any]:
    return {
        "journey": "UPI_PAYMENT",
        "bot_response": "",
        "expected_slot": None,
        "payee_name": None,
        "amount_to_be_paid": None,
        "registered_payee_details": None,
        "account_details": None,
        "show_contact_list": "no",
        "fetch_account_details": "no",
        "request_to_proceed": "no",
        "abort": "no",
        "widget_response": "no",
        "off_topic_count": 0,
        "payee_not_found_count": 0,
    }


async def intent_identification(user_query: str, state: dict[str, Any]) -> dict[str, Any]:
    response = await ainvoke_structured(
        [
            ("system", UPI_INTENT_SYSTEM_PROMPT),
            ("human", f"user_query: {user_query}\nstate: {state}"),
        ],
        UpiIntentOutput,
    )
    return response.model_dump()


async def extract_amount(user_query: str, existing_amount: float | None, expected_slot: str) -> dict[str, Any]:
    response = await ainvoke_structured(
        [
            ("system", UPI_AMOUNT_SYSTEM_PROMPT.format(expected_slot=expected_slot, existing_amount=existing_amount)),
            ("human", f"user_query: {user_query}\nexisting_amount_to_be_paid: {existing_amount}"),
        ],
        UpiAmountOutput,
    )
    return response.model_dump()


async def extract_payee_name(
    user_query: str,
    existing_payee_name: str | None,
    expected_slot: str | None,
    payee_not_found_count: int = 0,
) -> dict[str, Any]:
    response = await ainvoke_structured(
        [
            (
                "system",
                UPI_PAYEE_SYSTEM_PROMPT.format(
                    expected_slot=expected_slot,
                    existing_payee_name=existing_payee_name,
                    payee_not_found_count=payee_not_found_count,
                ),
            ),
            ("human", f"user_query: {user_query}\nexisting_payee_name: {existing_payee_name}"),
        ],
        UpiPayeeOutput,
    )
    return response.model_dump()


def validate_upi_amount(amount: float, current_balance: float) -> dict[str, Any]:
    if amount is None or not isinstance(amount, (int, float)):
        return {"amount_to_be_paid": None, "bot_response": "Please enter a valid numeric amount to proceed."}
    if amount <= 0:
        return {
            "amount_to_be_paid": None,
            "bot_response": "The payment amount must be greater than zero. Please enter a valid amount.",
        }
    if amount > current_balance:
        return {
            "amount_to_be_paid": None,
            "bot_response": (
                f"Insufficient funds. Your current balance is ₹{current_balance:,.2f}. "
                "Please enter an amount within your available balance."
            ),
        }
    return {"amount_to_be_paid": amount, "bot_response": "Amount noted."}


def build_final_confirmation(payee_name: str, registered_payee_details: dict[str, Any], amount_to_be_paid: float) -> dict[str, Any]:
    upi_id = (
        registered_payee_details.get("upi_id", "N/A")
        if isinstance(registered_payee_details, dict)
        else str(registered_payee_details)
    )
    bank_name = registered_payee_details.get("bank_name", "") if isinstance(registered_payee_details, dict) else ""
    mobile = registered_payee_details.get("mobile", "") if isinstance(registered_payee_details, dict) else ""

    lines = ["### 💸 UPI Payment Confirmation\n", f"- **Payee Name:** {payee_name}"]
    if mobile:
        lines.append(f"- **Mobile:** {mobile}")
    lines.append(f"- **UPI ID:** {upi_id}")
    if bank_name:
        lines.append(f"- **Bank:** {bank_name}")
    lines.append(f"- **Amount:** ₹{amount_to_be_paid:,.2f}")
    lines.append("\n  Please review the above details carefully and **confirm** to proceed with the payment.")

    return {"request_to_proceed": "yes", "bot_response": "\n".join(lines)}


async def upi_orchestrator(state: UpiGraphState) -> dict[str, Any]:
    data = state.model_dump()
    user_query = data["user_query"]

    data["show_contact_list"] = "no"
    data["request_to_proceed"] = "no"
    data["fetch_account_details"] = "no"
    current_balance = data.get("primary_balance", 20000)

    if data["widget_response"] == "no":
        intent = (await intent_identification(user_query, data)).get("intent", "none")
    else:
        intent = "none"

    if intent == "abort":
        data.update(
            {
                "abort": "yes",
                "expected_slot": None,
                "bot_response": (
                    "Your UPI payment journey has been cancelled. "
                    "Feel free to start a new transaction whenever you're ready."
                ),
            }
        )
        return data

    if intent == "other":
        data["off_topic_count"] += 1
        if data["off_topic_count"] > 1:
            data.update(
                {
                    "abort": "yes",
                    "expected_slot": None,
                    "bot_response": (
                        "It seems you have a different query. "
                        "Your UPI payment journey has been terminated. "
                        "Please reach out to us again for assistance."
                    ),
                }
            )
            return data
        data["bot_response"] = (
            "I can only assist with your current UPI payment. "
            "Would you like to continue or cancel this transaction?"
        )
        return data

    data["off_topic_count"] = 0
    needs_amount = data["amount_to_be_paid"] is None or intent in ("change_amount", "change_both")

    if needs_amount:
        data["expected_slot"] = "amount"
        extraction = await extract_amount(user_query, data["amount_to_be_paid"], data["expected_slot"])
        extracted_amount = extraction.get("amount_to_be_paid")
        data["bot_response"] = extraction["bot_response"]

        if extracted_amount is None:
            return data

        validation = validate_upi_amount(extracted_amount, current_balance)
        if validation["amount_to_be_paid"] is None:
            data["bot_response"] = validation["bot_response"]
            return data

        data["amount_to_be_paid"] = validation["amount_to_be_paid"]
        if intent == "change_amount":
            data["expected_slot"] = None

    needs_payee = data["registered_payee_details"] is None or intent in ("change_payee", "change_both")

    if needs_payee:
        if data["widget_response"] == "yes":
            if data["registered_payee_details"]:
                data["expected_slot"] = None
                data["payee_not_found_count"] = 0
                data["widget_response"] = "no"
            else:
                data.update(
                    {
                        "expected_slot": "payee_name",
                        "widget_response": "no",
                        "show_contact_list": "yes",
                        "bot_response": (
                            "We couldn't find a UPI ID linked to the selected contact. "
                            "Please try selecting a different contact, or verify that "
                            "this person has a registered UPI ID on their number."
                        ),
                    }
                )
                return data
        else:
            if intent in ("change_payee", "change_both"):
                data["expected_slot"] = "payee_name"
                if data["payee_name"]:
                    data["payee_not_found_count"] += 1
                data["registered_payee_details"] = None

            extraction = await extract_payee_name(
                user_query,
                data["payee_name"],
                data["expected_slot"],
                data["payee_not_found_count"],
            )
            extracted_name = extraction.get("payee_name")
            data["bot_response"] = extraction["bot_response"]

            if not extracted_name:
                return data

            data["registered_payee_details"] = None
            data["payee_name"] = extracted_name
            data["show_contact_list"] = "yes"
            return data

    data["expected_slot"] = None
    confirmation = build_final_confirmation(data["payee_name"], data["registered_payee_details"], data["amount_to_be_paid"])
    data.update({"request_to_proceed": confirmation["request_to_proceed"], "bot_response": confirmation["bot_response"]})
    return data


def build_graph():
    builder = StateGraph(UpiGraphState)
    builder.add_node("orchestrate_upi_payment", upi_orchestrator)
    builder.add_edge(START, "orchestrate_upi_payment")
    builder.add_edge("orchestrate_upi_payment", END)
    return builder.compile()
