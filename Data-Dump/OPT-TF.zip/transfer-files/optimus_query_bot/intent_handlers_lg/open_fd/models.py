from typing import Any, Literal

from pydantic import BaseModel, Field


class FixedDepositGraphState(BaseModel):
    journey: str = Field(default="OPEN_FD", description="Current fixed deposit journey identifier.")
    bot_response: str = Field(default="", description="Customer-facing response for the current turn.")
    fd_amount: Any = Field(default=None, description="Validated fixed deposit booking amount.")
    tenure: Any = Field(default=None, description="Selected FD tenure in days.")
    tenure_description: Any = Field(default=None, description="Human-readable tenure description for the selected plan.")
    interest_rate: Any = Field(default=None, description="Interest rate for selected FD plan.")
    show_interest_rate_chart: str = Field(default="false", description="Whether UI should show available FD schemes.")
    raise_final_confirmation: str = Field(default="no", description="Whether UI should raise final confirmation.")
    abort: str = Field(default="no", description="Whether this journey is aborted.")
    change_default: str = Field(default="no", description="Whether user should be redirected for default FD settings.")
    off_topic_count: int = Field(default=0, description="Count of unrelated free-text turns.")
    tenure_info: dict[str, Any] = Field(default_factory=dict, description="Tenure information for selected FD plan.")
    depositType: Any = Field(default=None, description="Deposit type for the selected FD plan.")
    isAutoRenewable: Any = Field(default=None, description="Auto-renewal flag for the selected FD plan.")
    interestPayoutMethod: Any = Field(default=None, description="Interest payout method for the selected FD plan.")
    productCode: Any = Field(default=None, description="Product code for the selected FD plan.")
    subProductCode: Any = Field(default=None, description="Sub-product code for the selected FD plan.")
    expected_slot: Any = Field(default=None, description="Current slot being collected, amount or tenure.")
    user_query: str = Field(default="", description="Latest user message.")
    primary_balance: int | float = Field(default=0, description="Available account balance.")
    fixed_deposit_plans: list[dict[str, Any]] = Field(default_factory=list, description="Available FD plans.")


class FdAmountOutput(BaseModel):
    bot_response: str = Field(description="Customer-facing message for amount extraction.")
    fd_amount: float | None = Field(description="Extracted FD amount, or null if missing.")


class FdTenureOutput(BaseModel):
    bot_response: str = Field(description="Customer-facing message for tenure selection.")
    tenure: float | None = Field(description="FD tenure in days, or null if missing.")
    show_interest_rate_chart: Literal["true", "false"] = Field(description="Whether to show the interest rate chart.")


class FdIntentOutput(BaseModel):
    intent: Literal[
        "change_amount",
        "change_tenure",
        "change_default",
        "abort",
        "other",
        "none",
        "change_amount_and_tenure",
    ] = Field(description="Classify the user query into one of the allowed FD intents.")
    reasoning: str = Field(description="One line explanation of why this intent was chosen. Mandatory.")
