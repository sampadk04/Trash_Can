# Structured Outputs

Use structured output for graph decisions and machine-readable node results.

## Direct Model Output

Best for router/classifier/evaluator nodes.

```python
from typing import Literal
from pydantic import BaseModel, Field


class RouteDecision(BaseModel):
    next_step: Literal["retrieve", "answer", "human_review"] = Field(
        description="Next graph node."
    )
    reason: str


router = model.with_structured_output(RouteDecision)


def classify(state: State) -> dict:
    decision = router.invoke(state["request"])
    return {"route": decision.next_step, "route_reason": decision.reason}
```

OpenAI-native JSON schema can be requested on individual model calls when supported:

```python
router = model.with_structured_output(RouteDecision, method="json_schema")
```

## Agent Structured Output

Use `response_format` when the prebuilt `create_agent` loop is enough.

```python
from pydantic import BaseModel, Field
from langchain.agents import create_agent


class ContactInfo(BaseModel):
    name: str = Field(description="Person name")
    email: str = Field(description="Email address")


agent = create_agent(
    model="openai:gpt-5-nano",
    tools=[],
    response_format=ContactInfo,
)

result = agent.invoke({
    "messages": [{"role": "user", "content": "Jane, jane@example.com"}]
})
print(result["structured_response"])
```

LangChain chooses provider-native structured output when available, otherwise tool-calling. Use explicit `ProviderStrategy` or `ToolStrategy` only when that choice matters.

## Where It Fits

Good uses:

- route selection,
- query rewriting,
- document relevance grading,
- planner output,
- extraction,
- quality/evaluation checks.

Avoid JSON-wrapping a final answer when a normal `AIMessage` is enough.

## Source Links

- Structured output: https://docs.langchain.com/oss/python/langchain/structured-output
- ChatOpenAI structured output: https://docs.langchain.com/oss/python/integrations/chat/openai
- Agents: https://docs.langchain.com/oss/python/langchain/agents
