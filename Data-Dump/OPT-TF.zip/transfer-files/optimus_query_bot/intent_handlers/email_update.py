from openai import AsyncOpenAI
from httpx import AsyncClient
from dotenv import load_dotenv

# from app.clients.llm_gw import get_llm_gw_client
from app.services.optimus_query_bot.llm_usage import log_usage
from typing import Optional, Dict, Any
import json
import time

load_dotenv()
openai_client = AsyncOpenAI(http_client=AsyncClient(verify=False))

async def gptcall(messages,FD_OUTPUT_SCHEMA):
    response = await openai_client.chat.completions.create(
        model="gpt-5.2",
        messages=messages,
        max_completion_tokens=1024,
        temperature=0.0,
        top_p=0.9,
        response_format=FD_OUTPUT_SCHEMA
    )
    
    response_dict = response.model_dump()
    return response_dict

# gptcall=LLMGatewayClient()

# client = get_llm_gw_client()

# async def gptcall(messages,FD_OUTPUT_SCHEMA):
#     payload = {
#         "model": "gpt-5.4",
#         "max_completion_tokens": 1024,
#         "temperature": 0.0,
#         "top_p": 0.9,
#         "messages": messages,
#         "response_format": FD_OUTPUT_SCHEMA
#     }


#     response = await client.invoke_model(payload)
#     log_usage(response, "optimus_query_bot.email_update.gptcall")
#     return response


# ========================= Helper functions =======================================

async def get_confirmation(user_query):
    out_schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "get_confirmation",
            "schema": {
                "type": "object",
                "properties": {

                    "confirmation": {
                        "type": "string",
                        "enum": ["yes","no","ambiguous"],
                        "description": "classify the user query in one of those intents"
                    },
                },

                "required": [
                    "confirmation",
                ],

                "additionalProperties": False
            }
        }
    }


    messages = [
        {
            "role": "system",
            "content": """ 
               ### Role
            You are a banking confirmation classifier.

            Your ONLY task is to determine whether the user has:
            - Confirmed
            - Rejected
            - Given an unclear response

            regarding **changing their registered email address**.

            ---

            ### Context
            The user was previously shown a confirmation message:
            "Your email address will be updated across your accounts. Please confirm if you want to proceed."

            ---

            ### Classification Rules (Very Important)

            Return:
            - "yes" → if the user clearly agrees or gives consent  
              Examples:
              - "yes"
              - "confirm"
              - "okay"
              - "go ahead"
              - "please update it"
              - "I agree"
              - "continue"

            - "no" → if the user clearly refuses or cancels  
              Examples:
              - "no"
              - "cancel"
              - "stop"
              - "don’t proceed"
              - "not now"
              - "I don’t want to change"

            - "ambiguous" → if the response is unclear, conditional, or unrelated  
              Examples:
              - "what if I change it later?"
              - "is this reversible?"
              - "change only credit card email"
              - emojis, short acknowledgements without consent

            ---

            ### Strict Rules
            - Do NOT infer intent
            - Do NOT ask follow-up questions
            - Do NOT explain reasoning
            - Output ONLY valid JSON
            - No extra text

            ---

            ### Output Format
            {
              "confirmation": "yes | no | ambiguous"
            }
            """
        },
        {
            "role": "user",
            "content": f"user_query:{user_query}"
        }
    ]
    raw_response=await gptcall(messages,out_schema)
    final_output = raw_response["choices"][0]["message"]["content"]

    response=json.loads(final_output)
    return response



# =================================  Orchestrator ====================

def initialize_state() -> Dict[str, Any]:
    return {
        "journey": "CHANGE_EMAIL",
        "bot_response": "",
        "change_email_eligibility": "no",
        "eligibility_checked": "no",
        "is_eligible": None,              # True / False
        "email_mfa": "no",
        "get_new_email":"no",
        "new_email": None,
        "current_email":None,
        "service_request_no": None,
        "confirmation_raised": "no",
        "status":'none',
        "abort": "no",
        "off_topic_count": 0,
    }

class EmailChangeHandler:
    def __init__(self):
        self.state = initialize_state()

    def _update_state_from_request(self, additional_data:dict, journey_state: dict):

        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

        if "is_eligible" in additional_data:
            self.state["is_eligible"] = additional_data.get("is_eligible").lower().strip()
            self.state["eligibility_checked"]='yes'
        if 'current_email' in additional_data:
            self.state['current_email']=additional_data.get("current_email")

        if "new_email" in additional_data:
            self.state["new_email"] = additional_data.get("new_email")

        if "status" in additional_data:
            self.state["status"] = additional_data.get("status")

        if "service_request_no" in additional_data:
            self.state["service_request_no"] = additional_data.get("service_request_no")

    async def handle(self, user_query, journey_data, journey_state):
        start_time = time.time()

        # Reset UI flags every turn
        self.state["change_email_eligibility"] = "no"
        self.state["get_new_email"] = "no"
        self.state["email_mfa"] = "no"

        # =====================================================
        # STEP 1: ELIGIBILITY CHECK
        # =====================================================
        if self.state["eligibility_checked"] == "no":
            self.state["change_email_eligibility"] = "yes"
            self.state["bot_response"] = (
                "Checking whether your account is eligible for email address change."
            )
            return self.state

        # =====================================================
        # STEP 2: NOT ELIGIBLE
        # =====================================================
        if self.state["is_eligible"]=='no':

            self.state["bot_response"] = (
                "You are currently not eligible to change your registered email address."
            )
            return self.state

        # =====================================================
        # STEP 3: COLLECT NEW EMAIL
        # =====================================================
        if self.state["is_eligible"] =='yes' and not self.state["new_email"]:
            self.state['get_new_email']='yes'
            self.state["bot_response"] = (
                f"You are eligible to change your email address."
                f"Your current email ID is **{self.state['current_email']}**\n"
                f"Please enter your new email address."
            )
            return self.state

        # =====================================================
        # STEP 4: CONFIRMATION
        # =====================================================
        if self.state["new_email"] and self.state["confirmation_raised"] == "no":
            self.state.update(
                {
                    "confirmation_raised": "yes",
                    "bot_response": (
                        "Your email address will be updated across the following accounts:\n"
                        "- **Savings Account**\n"
                        "- **Credit Card**\n"
                        "- **Loan Account (if applicable)\n"
                        "Please confirm if you want to proceed."
                    )
                }
            )
            return self.state

        # =====================================================
        # STEP 5: HANDLE CONFIRMATION RESPONSE
        # =====================================================
        if self.state["new_email"] and self.state["confirmation_raised"] == "yes" and self.state["status"]=='none':
            confirmation_response = await get_confirmation(user_query)

            if confirmation_response.get("confirmation") == "yes":
                self.state["email_mfa"] = "yes"
                self.state["bot_response"] = (
                    "Please complete the verification to proceed with changing your email address."
                )
                return self.state

            if confirmation_response.get("confirmation") == "no":
                self.state.update(
                    {
                        "abort": "yes",
                        "bot_response": (
                            "No problem. The email change request has been cancelled. "
                            "You can try again anytime."
                        )
                    }
                )
                return self.state

            # Ambiguous confirmation
            self.state["bot_response"] = (
                "Please confirm whether you want to proceed with changing your email address."
            )
            return self.state

        # =====================================================
        # STEP 6: SUCCESS/FAILURE
        # =====================================================

        if self.state['status']=='success':
            self.state['abort']='yes'
            self.state["bot_response"] = (
                "Your email address has been changed successfully.\n"
                f"Service Request Number: **{self.state['service_request_no']}**\n"
            )
            return self.state
        elif self.state['status']=='failure':
            self.state['abort']='yes'
            self.state["bot_response"] = (
                "We could not process your request please try again later"
            )
            return self.state


        return self.state

    def get_intent_data(self):

        journey_id="EMAIL_UPDATE"
        if self.state.get("status").lower().strip() == "success":
            return {
                "intent_type": "Execution",
                "intent": f"{journey_id}.SHOW_FINAL_STATUS"
            }

        if self.state.get("email_mfa").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.MFA_EMAIL"
            }

        if self.state.get("get_new_email").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.VALIDATE_EMAIL"
            }

        if self.state.get("change_email_eligibility").lower().strip() == "yes":
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.CHANGE_EMAIL_ELIGIBILITY"
            }
        return {
            "intent_type": "Clarification",
            "intent": journey_id
        }
