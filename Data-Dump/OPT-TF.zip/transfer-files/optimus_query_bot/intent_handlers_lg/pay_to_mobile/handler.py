from typing import Any

from app.services.optimus_query_bot.intent_handlers_lg.pay_to_mobile.graph import build_graph, initialize_state
from app.services.optimus_query_bot.intent_handlers_lg.shared.state import yes


class UpiGraphHandler:
    def __init__(self):
        self.state = initialize_state()
        self.graph = build_graph()

    def _update_state_from_request(self, additional_data: dict, journey_state: dict):
        if journey_state:
            for key, value in journey_state.items():
                if key in self.state:
                    self.state[key] = value

        if "registered_payee_details" in additional_data:
            self.state["registered_payee_details"] = additional_data.get("registered_payee_details")
        if "account_details" in additional_data:
            self.state["account_details"] = additional_data.get("account_details")
        if "widget_response" in additional_data:
            self.state["widget_response"] = additional_data.get("widget_response").lower().strip()

    async def handle(self, user_query: str, journey_data: dict[str, Any], journey_state: dict[str, Any] | None = None):
        primary_balance = journey_data.get("primary_balance", 20000)
        result = await self.graph.ainvoke({**self.state, "user_query": user_query, "primary_balance": primary_balance})
        result.pop("user_query", None)
        result.pop("primary_balance", None)
        self.state = result
        self.state["widget_response"] = "no"
        return self.state

    def get_intent_data(self):
        journey_id = "PAY_TO_MOBILE"
        if yes(self.state.get("request_to_proceed")):
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.RAISE_FINAL_CONFIRMATION",
                "additional_data": {"amount_to_be_paid": self.state["amount_to_be_paid"]},
            }
        if yes(self.state.get("fetch_account_details")):
            return {"intent_type": "Clarification", "intent": f"{journey_id}.SHOW_ACCOUNTS"}
        if yes(self.state.get("show_contact_list")):
            return {
                "intent_type": "Clarification",
                "intent": f"{journey_id}.SHOW_CONTACT_LIST",
                "additional_data": {"payee_name": self.state["payee_name"]},
            }
        if yes(self.state.get("abort")):
            return {"intent_type": "", "intent": ""}
        return {"intent_type": "Clarification", "intent": journey_id}
