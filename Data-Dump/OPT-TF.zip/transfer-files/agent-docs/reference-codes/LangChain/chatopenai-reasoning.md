# ChatOpenAI and Reasoning

Use `ChatOpenAI` when you need OpenAI-specific options beyond provider-neutral `init_chat_model`.

## Setup and Calls

```bash
pip install -U langchain-openai
export OPENAI_API_KEY="..."
```

```python
from httpx import AsyncClient, Client
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv


load_dotenv()


def build_chat_openai(reasoning_effort: str = "low") -> ChatOpenAI:
    http_client = Client(verify=False)
    async_http_client = AsyncClient(verify=False)
    return ChatOpenAI(
        model="gpt-5.2",
        use_responses_api=True,
        reasoning={"effort": reasoning_effort},
        temperature=None,
        max_retries=2,
        http_client=http_client,
        http_async_client=async_http_client,
    )


llm = build_chat_openai()

print(llm.invoke("Explain LangGraph in one sentence.").content)
```

Messages, tools, and structured output use the same LangChain APIs:

```python
llm.invoke([
    ("system", "You are concise."),
    ("human", "What is a LangGraph reducer?"),
])

llm_with_tools = llm.bind_tools([lookup_policy])
classifier = llm.with_structured_output(Classification)
```

## Responses API

`ChatOpenAI` can route through OpenAI's Responses API automatically for Responses-specific features, or explicitly:

```python
llm = build_chat_openai()
```

Manage conversation history through LangGraph state by default. Use `previous_response_id` only when you intentionally want Responses API continuation.

## Reasoning

```python
reasoning_llm = build_chat_openai(reasoning_effort="medium")

response = reasoning_llm.invoke("What is 3^3?")
print(response.text)
```

Reasoning summaries are summaries, not raw hidden reasoning. Setting `reasoning` uses the Responses API path.

Practical defaults:

- low effort for cheap routers/classifiers,
- higher effort for planners/evaluators,
- `temperature=None` when using GPT-5 reasoning through the Responses API,
- keep credentials and client objects out of graph state.

## Source Links

- ChatOpenAI integration: https://docs.langchain.com/oss/python/integrations/chat/openai
- Models: https://docs.langchain.com/oss/python/langchain/models
- OpenAI package guide from `chub`: `langchain/openai --lang py`
