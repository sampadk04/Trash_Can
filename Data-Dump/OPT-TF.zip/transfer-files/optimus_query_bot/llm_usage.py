import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _extract_usage(response: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    usage = response.get("usage")
    if not usage:
        usage = response.get("data", {}).get("usage")
    if not usage:
        usage = response.get("metadata", {}).get("usage")
    return usage


def log_usage(response: Dict[str, Any], context: str) -> None:
    usage = _extract_usage(response)
    if not usage:
        return
    logger.info(
        "LLM token usage for %s: prompt=%s completion=%s total=%s",
        context,
        usage.get("prompt_tokens"),
        usage.get("completion_tokens"),
        usage.get("total_tokens"),
    )
