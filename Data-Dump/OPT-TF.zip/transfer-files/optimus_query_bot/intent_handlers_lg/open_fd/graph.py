from typing import Any

from langgraph.graph import END, START, StateGraph

from app.services.optimus_query_bot.intent_handlers_lg.open_fd.models import (
    FdAmountOutput,
    FdIntentOutput,
    FdTenureOutput,
    FixedDepositGraphState,
)
from app.services.optimus_query_bot.intent_handlers_lg.open_fd.prompts import (
    FD_AMOUNT_SYSTEM_PROMPT,
    FD_INTENT_SYSTEM_PROMPT,
    FD_TENURE_SYSTEM_PROMPT,
)
from app.services.optimus_query_bot.intent_handlers_lg.shared.llm import ainvoke_structured


def initialize_state() -> dict[str, Any]:
    return {
        "journey": "OPEN_FD",
        "bot_response": "",
        "fd_amount": None,
        "tenure": None,
        "tenure_description": None,
        "interest_rate": None,
        "show_interest_rate_chart": "false",
        "raise_final_confirmation": "no",
        "abort": "no",
        "change_default": "no",
        "off_topic_count": 0,
        "tenure_info": {},
        "expected_slot": None,
    }


async def update_amount(user_query: str) -> dict[str, Any]:
    response = await ainvoke_structured(
        [
            ("system", FD_AMOUNT_SYSTEM_PROMPT),
            ("human", user_query),
        ],
        FdAmountOutput,
    )
    return response.model_dump()


def normalize_tenure(tenure_part: dict) -> int:
    if not tenure_part:
        return 0
    tenure_part = {k.lower(): v for k, v in tenure_part.items()}
    years = tenure_part.get("years", 0) or 0
    months = tenure_part.get("months", 0) or 0
    days_ = tenure_part.get("days", 0) or 0
    return (years * 365) + (months * 30) + days_


def select_fd_plan(days: int, plans: list):
    matching_plans = []
    for plan in plans:
        tenure = plan.get("tenure", {})
        min_days = normalize_tenure(tenure.get("min", {}))
        max_days = normalize_tenure(tenure.get("max", {}))
        if min_days <= days <= max_days:
            matching_plans.append((plan, min_days, max_days))

    if not matching_plans:
        return None

    matching_plans.sort(key=lambda x: (-x[0].get("rate_of_interest", 0), (x[2] - x[1])))
    best_plan, min_days, _ = matching_plans[0]
    years = days // 365
    remaining_days = days % 365
    return {
        "interest_rate": best_plan.get("rate_of_interest"),
        "depositType": best_plan.get("deposit_type"),
        "isAutoRenewable": best_plan.get("is_renewable"),
        "interestPayoutMethod": best_plan.get("interest_payout_method"),
        "productCode": best_plan.get("product_code"),
        "subProductCode": best_plan.get("sub_product_code"),
        "tenure_info": {"Years": years, "Months": 0, "Days": remaining_days},
    }


def duration_to_days(duration):
    years = 0
    months = 0
    days = 0
    for key, value in duration.items():
        v = value or 0
        k = key.lower()
        if k == "years":
            years = v
        elif k == "months":
            months = v
        elif k == "days":
            days = v
    return years * 365 + months * 30 + days


def extract_interest_ranges(plans):
    interest_rates = []
    for plan in plans:
        tenure = plan.get("tenure", {})
        min_duration = tenure.get("min", {})
        max_duration = tenure.get("max", {})
        min_days = duration_to_days(min_duration)
        max_days = duration_to_days(max_duration)
        interest_rates.append(
            {
                "tenure": plan.get("tenure_description", ""),
                "min_days": min_days,
                "max_days": max_days,
                "rate_percent": plan.get("rate_of_interest"),
            }
        )
    return {"interest_rates": interest_rates}


def validate_fd_amount(amount: int, current_balance: int, min_fd_limit: int = 1000, max_fd_limit: int = 30000000):
    if amount < min_fd_limit:
        return {
            "fd_amount": None,
            "bot_response": f"The minimum amount required to book a Fixed Deposit is ₹{min_fd_limit:,}.",
        }
    if amount > max_fd_limit:
        return {
            "fd_amount": None,
            "bot_response": f"The maximum amount allowed for a Fixed Deposit is ₹{max_fd_limit:,}.",
        }
    if amount > current_balance:
        return {"fd_amount": None, "bot_response": "You have insufficient funds to proceed with this deposit amount."}
    return {"fd_amount": amount, "bot_response": "Amount noted. Let’s proceed with the next step."}


async def update_tenure(user_query, rate_card, consumed_value, expected_slot):
    response = await ainvoke_structured(
        [
            ("system", FD_TENURE_SYSTEM_PROMPT),
            (
                "human",
                f"user_query:{user_query},\n rate_card:{rate_card},\n consumed_value:{consumed_value},\n expected_slot:{expected_slot}",
            ),
        ],
        FdTenureOutput,
    )
    return response.model_dump()


def raise_final_confirmation(
    user_query: str,
    booking_amount: int | None,
    tenure: int | None,
    interest_rate: float | None,
    auto_renewal: str = "Yes",
    nominee_details: str = "existing_nominee",
    payout_option: str = "on_maturity",
) -> dict[str, Any]:
    missing_fields = []
    if not booking_amount:
        missing_fields.append("deposit amount")
    if not tenure:
        missing_fields.append("tenure")
    if not interest_rate:
        missing_fields.append("interest rate")
    if missing_fields:
        return {
            "raise_final_confirmation": "no",
            "bot_response": (
                "To proceed with your Fixed Deposit booking, please provide the "
                + ", ".join(missing_fields)
                + "."
            ),
        }

    bot_response = (
        "### 📄 Fixed Deposit Booking Summary\n\n"
        f"- **Deposit Amount:** ₹{booking_amount:,}\n"
        f"- **Tenure:** {tenure} days\n"
        f"- **Interest Rate:** {interest_rate}% p.a.\n"
        f"- **Payout Option:** {payout_option.replace('_', ' ').title()}\n"
        f"- **Auto Renewal:** {auto_renewal}\n"
        f"- **Nominee Details:** Your existing nominee details will be used.\n  "
        f"Please review the above details carefully and confirm to proceed."
    )
    return {"raise_final_confirmation": "yes", "bot_response": bot_response}


async def intent_identification(user_query, state_dict, expected_slot):
    response = await ainvoke_structured(
        [
            ("system", FD_INTENT_SYSTEM_PROMPT),
            ("human", f"user_query:{user_query},\n state_dict:{state_dict}, \n Expected Slot:{expected_slot} "),
        ],
        FdIntentOutput,
    )
    return response.model_dump()


async def fd_orchestrator(state: FixedDepositGraphState) -> dict[str, Any]:
    data = state.model_dump()
    user_query = data["user_query"]
    fd_rate = data["fixed_deposit_plans"]
    current_balance = data["primary_balance"]

    intent = (await intent_identification(user_query, data, data["expected_slot"]))["intent"]
    data["raise_final_confirmation"] = "no"
    data["show_interest_rate_chart"] = "false"

    if intent == "abort":
        data.update(
            {
                "abort": "yes",
                "bot_response": (
                    "We appreciate your time with us. Your FD booking journey has now ended. "
                    "You are always welcome to visit again."
                ),
            }
        )
        return data

    if intent == "change_default":
        data.update({"change_default": "yes", "bot_response": "Kindly proceed with the below redirection"})
        return data

    if intent == "other":
        data["off_topic_count"] += 1
        if data["off_topic_count"] > 1:
            return {
                **data,
                "abort": "yes",
                "bot_response": (
                    "We appreciate your time with us. Your FD booking journey has now ended. "
                    "You are always welcome to visit again."
                ),
            }
        data["bot_response"] = "We are in the middle of an FD booking journey. Let us know if you want to abort."
        return data

    consumed_value = None
    if not data["fd_amount"] or intent in ["change_amount", "change_amount_and_tenure"]:
        data["expected_slot"] = None
        extraction_response = await update_amount(user_query)
        data["bot_response"] = extraction_response["bot_response"]
        extracted_amount = extraction_response["fd_amount"]
        if not extracted_amount:
            data["expected_slot"] = "amount"
            return data

        validation_response = validate_fd_amount(extracted_amount, current_balance)
        data["bot_response"] = validation_response["bot_response"]
        if not validation_response["fd_amount"]:
            data["expected_slot"] = "amount"
            return data

        data["fd_amount"] = validation_response["fd_amount"]
        consumed_value = {"amount": data["fd_amount"]}

    if not data["tenure"] or intent in ["change_tenure", "change_amount_and_tenure"]:
        formatted_fd_rate = extract_interest_ranges(fd_rate)
        response = await update_tenure(user_query, formatted_fd_rate, consumed_value, data["expected_slot"])
        data.update({"bot_response": response["bot_response"], "show_interest_rate_chart": response["show_interest_rate_chart"]})
        if not response["tenure"]:
            data["expected_slot"] = "tenure"
            data["tenure"] = None
            return data

        best_plan = select_fd_plan(response["tenure"], fd_rate)
        if not best_plan:
            data.update(
                {
                    "bot_response": (
                        "Sorry, we don’t have an FD plan available for the selected tenure. "
                        "Please choose a tenure from the options below."
                    ),
                    "show_interest_rate_chart": "true",
                    "expected_slot": "tenure",
                    "tenure": None,
                }
            )
            return data

        data = {**data, **best_plan}
        data["tenure"] = response["tenure"]

    data["expected_slot"] = None
    response = raise_final_confirmation(
        user_query,
        booking_amount=data["fd_amount"],
        tenure=data["tenure"],
        interest_rate=data["interest_rate"],
    )
    data.update(
        {
            "raise_final_confirmation": response["raise_final_confirmation"].lower(),
            "bot_response": response["bot_response"],
            "show_interest_rate_chart": "false",
        }
    )
    return data


def build_graph():
    builder = StateGraph(FixedDepositGraphState)
    builder.add_node("orchestrate_fixed_deposit", fd_orchestrator)
    builder.add_edge(START, "orchestrate_fixed_deposit")
    builder.add_edge("orchestrate_fixed_deposit", END)
    return builder.compile()
